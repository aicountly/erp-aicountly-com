<?php
namespace App\Models\Admin;
use CodeIgniter\Model;
use App\Libraries\externaldb;
use App\Libraries\UUIDtables;
use App\Models\CommonModel;
class BranchesModel extends Model	{
    public function __construct() {
       parent::__construct();        
       $this->externaldb    = new externaldb();	
	   $this->CommonModel   = new CommonModel();	
	   $this->session       = \Config\Services::session();
	   $this->company_id    = $this->session->get('ses_company_id');	 
	   $this->aicountly_db  = $this->externaldb->aicountly_db();	
    } 
 
  public function SavedGSTINSList($branch_id=''){
	  $gstinmastr_tbl = $this->company_id.'_gstinmastr_'.$this->session->get('ses_comp_fy_id');
	  if($branch_id=='')
	  $data           = $this->db->table($gstinmastr_tbl)->get()->getResultArray();
      else 
	   $data           = $this->db->table($gstinmastr_tbl)->where("gstin_inactivedate IS NULL")->where('bo_id',$branch_id)->get()->getResultArray();	  
   
	  $response       = array();
	  if($data){
	    foreach($data as $row){
		  $response[] = array("gstinmastr_id"=>$row['gstinmastr_id'],'gstin_number' => $row['comp_gstin'], 'gstin_type' => $row['comp_gstin_type'], 'wef_date' => date('Y-m-d',strtotime($row['gstin_wefdate'])));
	     }
	  }
	  return $response;
  }
 
   public function validate_new_branch_gstin($company_id, $gstin_number,$gstin_type,$wef_date,$data='')
    {  
     	$hobomaster_tbl = $this->company_id.'_hobomaster_'.$this->session->get('ses_comp_fy_id');  
        $account_master_tbl = $this->company_id.'_acctmaster_'.$this->session->get('ses_comp_fy_id');	
		$gstinmastr_tbl = $this->company_id.'_gstinmastr_'.$this->session->get('ses_comp_fy_id');
      if($gstin_number){	   
       if($this->session->get('ses_company_id')!=''){
		$fy_start = date('Y-m-d',strtotime($this->session->get('ses_company_fy_beginning')));
		$fy_end    = date('Y-03-31', strtotime($fy_start. ' + 1 year'));
	  } 
	 else{
	   $fy_start  =  date('Y-04-31');
	   $fy_end     =  date('Y-03-01');
	  } 
	  if($data){
	  	
        $table = $this->db->table($hobomaster_tbl)->where('cmp_id', $this->company_id)->where('LOWER(bo_name)', strtolower(trim($data['bo_name'])))
                                            	      ->orWhere('LOWER(bo_alias)', strtolower(trim($data['bo_name'])))
                                            	       ->get()->getRowArray(); 
                                            	  
        if($table){
            return json_encode(['status' => false, 'message' => 'Branch name must be unique']);
        }
        
        $table = $this->db->table($hobomaster_tbl)->where('cmp_id', $this->company_id)->where('LOWER(bo_name)', strtolower(trim($data['bo_alias'])))
                                            	      ->orWhere('LOWER(bo_alias)', strtolower(trim($data['bo_alias'])))
                                            	      ->get()->getRowArray();
                                            	   
        if($table){
            return json_encode(['status' => false, 'message' => 'Branch alias must be unique']);
        }
        
		
		// check same bo name exisst in account master if exists deny to add 
		
		 $acctable = $this->db->table($account_master_tbl)->where('LOWER(acc_name)', strtolower(trim($data['bo_name'])))
                                            	      ->orWhere('LOWER(acc_name_alias)', strtolower(trim($data['bo_name'])))
                                            	       ->get()->getRowArray(); 
                                            	  
        if($acctable){
            return json_encode(['status' => false, 'message' => 'Account name must be unique']);
        }
        
        $acctable = $this->db->table($account_master_tbl)->where('LOWER(acc_name)', strtolower(trim($data['bo_alias'])))
                                            	      ->orWhere('LOWER(acc_name_alias)', strtolower(trim($data['bo_alias'])))
                                            	      ->get()->getRowArray();
                                            	   
        if($acctable){
            return json_encode(['status' => false, 'message' => 'Account alias must be unique']);
        }
		}
		
  
        // Check if the same GSTIN exists 
        $query = $this->db->table($gstinmastr_tbl)           
            ->where('comp_gstin', $gstin_number)
            ->get();
        if ($query->getNumRows() > 0) {
			 return json_encode(['status' => false, 'message' => "GSTIN: ".$gstin_number." is already used."]);
         }
		 
	    //**Check if a Regular GSTIN already exists in the same company & FY**
		$query = $this->db->table($gstinmastr_tbl)
			->where('comp_id', $company_id)
			->where('comp_gstin_type','1')
			->where('gstin_wefdate >=', $fy_start)
			->where('gstin_wefdate <=', $fy_end)
			->get();

		if ($query->getNumRows() > 0 && $gstin_type == '2') {
			return json_encode(["status" => false, "message" => "A 'Regular' GSTIN is already added for this Financial Year ($fy_start - $fy_end). You cannot add a 'Composition' GSTIN."]);
		}

		//**Check if a Composition GSTIN already exists in the same company & FY**
		$query = $this->db->table($gstinmastr_tbl)
			->where('comp_id', $company_id)
			->where('comp_gstin_type', '2')
			->where('gstin_wefdate >=', $fy_start)
			->where('gstin_wefdate <=', $fy_end)
			->get();

		if ($query->getNumRows() > 0 && $gstin_type == '1') {
			return json_encode(["status" => false, "message" => "A 'Composition' GSTIN is already added for this Financial Year ($fy_start - $fy_end). You cannot add a 'Regular' GSTIN."]);
		}
		
    
     }

    // If all checks pass, return true
    return json_encode(['status' => true, 'message' =>'']);
   }

   public function validate_addmore_branch_gstin($company_id, $gstin_number,$gstin_type,$wef_date,$branch_id)
    {   $hobomaster_tbl = 'hobomaster';  
        $account_master_tbl = 'acctmaster';	
		$gstinmastr_tbl = 'hobogstinm';
		$gstindetail_tbl = 'hobogstdet';
		
      if($gstin_number){	   
       if($this->session->get('ses_company_id')!=''){
		$fy_start = date('Y-m-d',strtotime($this->session->get('ses_company_fy_beginning')));
		$fy_end    = date('Y-03-31', strtotime($fy_start. ' + 1 year'));
	  } 
	 else{
	   $fy_start  =  date('Y-04-31');
	   $fy_end     =  date('Y-03-01');
	  } 
	  
        // Check if the same GSTIN exists overall 
        $query = $this->db->table($gstinmastr_tbl)  
					->where('cmp_id', $company_id)
					->where('hobo_gstin', $gstin_number)
					->get();
        if ($query->getNumRows() > 0) {
			 return json_encode(['status' => false, 'message' => "GSTIN: ".$gstin_number." should be unique."]);
         }
		 
	//**Prevent Duplicate GSTIN in the Same Branch**
    $query = $this->db->table($gstinmastr_tbl)
        ->where('hobo_id', $branch_id)
		 ->where('cmp_id', $company_id)
        ->where('hobo_gstin', $gstin_number)
        ->get();
    if ($query->getNumRows() > 0) {
        return json_encode(["status" => false, "message" => "This GSTIN is already used in the same branch."]);
    } 
	
	// **Ensure GSTIN is Not Used in Different Categories within the Same Branch or Across Branches**
    $query = $this->db->table($gstinmastr_tbl)
        ->where('hobo_gstin', $gstin_number)
		 ->where('cmp_id', $company_id)
        ->where('hobo_gstin_type !=', $gstin_type)
        ->get();
    if ($query->getNumRows() > 0) {
        return json_encode(["status" =>false, "message" => "The same GSTIN cannot be used in different categories across branches."]);
    }
	
		 
	 // **Ensure "Regular" & "Composition" GSTINs Are Not Mixed in the Same Branch**
    $query = $this->db->table($gstinmastr_tbl)
        ->where('cmp_id', $company_id)
		->where('hobo_id', $branch_id)
        ->whereIn('hobo_gstin_type', [1, 2])
        ->get();

      if ($query->getNumRows() > 0) {
         $existing_type = $query->getRow()->hobo_gstin_type;
          if (($existing_type == '1' && $gstin_type == '2') || ($existing_type == '2' && $gstin_type == '1')) {
            return json_encode(["status" => false, "message" => "You cannot mix 'Regular' and 'Composition' GSTIN types."]);
          }
      }
    
	
		// **Prevent Adding "Regular" or "Composition" GSTINs in the Same FY, Even if Outside WEF & Inactive Dates**
		$query = $this->db->table($gstinmastr_tbl . ' hgn') // 'hgn' is an alias for hobogstinn
				->select('hgn.hobo_gstin_id') // Select a column just for counting, it's efficient
				->join($gstindetail_tbl . ' hgd', 'hgn.hobo_gstin_id = hgd.hobo_gstin_id', 'inner') // Join with hobogstdet
				->where('hgn.cmp_id', $company_id)
				->where('hgd.cmp_id', $company_id)
				->whereIn('hgn.hobo_gstin_type', ['1', '2']) // Filter by Regular or Composition
				->where('hgd.hobo_gstin_wef_act >=', $fy_start) // Check effective date is within FY
				->where('hgd.hobo_gstin_wef_act <=', $fy_end)
				->groupStart() // Start a grouping for the active/inactive logic
					->where('hgd.hobo_gstin_inact_date IS NULL') // Condition 1: GSTIN is active (no inactive date)
					->orWhere('hgd.hobo_gstin_inact_date >', $fy_end)   // Condition 2: Or, it becomes inactive AFTER the current FY
				->groupEnd() // End the grouping
				->get();

			if ($query->getNumRows() > 0) {
				return json_encode([
					"status" => false, 
					"message" => "A 'Regular' or 'Composition' GSTIN already exists for this Financial Year ($fy_start - $fy_end)."
				]);
			}
		
    // **Check for other GSTIN types (Other than "Regular" or "Composition")** 
	$queryOtherGstin = $this->db->table("$gstinmastr_tbl hgn") // Alias hobogstinn as 'hgn'
		->join("$gstindetail_tbl hgd", "hgn.hobo_gstin_id = hgd.hobo_gstin_id", "inner") // Join with hobogstdet
		->where('hgn.cmp_id', $company_id)
		->whereNotIn('hgn.hobo_gstin_type', ['1', '2']) // Check types from the master table
		->where('hgd.hobo_gstin_wef_act >=', $fy_start) // Check dates from the detail table
		->where('hgd.hobo_gstin_wef_act <=', $fy_end)
		->groupStart()
			->where('hgd.hobo_gstin_inact_date IS NULL')      // GSTIN is still active
			->orWhere('hgd.hobo_gstin_inact_date >', $fy_end) // Or becomes inactive after this FY
		->groupEnd()
		->get();

	if ($queryOtherGstin->getNumRows() > 0) {
		return json_encode([
			"status" => false, 
			"message" => "Another GSTIN type already exists for this financial year. Mixing different GSTIN registration types is not allowed."
		]);
	}

     }

    // If all checks pass, return true
    return json_encode(['status' => true, 'message' =>'']);
   }
   
   
   public function validate_modify_branch_gstin($gstin_id, $gstin_number, $wef_date, $branch_id)
{   
    // Use the correct, fixed table name for your new schema
    $gstinmastr_tbl = 'hobogstinm';

    if ($gstin_number) {
        // --- Validation 1: Check if the GSTIN is a duplicate anywhere in the company, excluding the current record being edited ---
        $query = $this->db->table($gstinmastr_tbl)           
            ->where('hobo_gstin', $gstin_number)       // Use the correct column name 'hobo_gstin'
            ->where('hobo_gstin_id !=', $gstin_id)     // Use the correct primary key 'hobo_gstin_id'
            ->where('cmp_id', $this->company_id)       // It's good practice to scope this to the company
            ->get();
            
        if ($query->getNumRows() > 0) {
            return json_encode([
                'status' => false, 
                'message' => "GSTIN: " . $gstin_number . " already exists and must be unique."
            ]);
        }
         
        // --- Validation 2: Check if the GSTIN is a duplicate within the same branch, excluding the current record ---
        $query = $this->db->table($gstinmastr_tbl)
            ->where('hobo_id', $branch_id)            // Use the correct branch ID column 'hobo_id'
            ->where('hobo_gstin', $gstin_number)      // Use 'hobo_gstin'
            ->where('hobo_gstin_id !=', $gstin_id)    // Use 'hobo_gstin_id'
            ->get();
            
        if ($query->getNumRows() > 0) {
            return json_encode([
                "status" => false, 
                "message" => "This GSTIN is already assigned to this branch."
            ]);
        } 
    }

    // If all checks pass, return true
    return json_encode(['status' => true, 'message' => '']);
}
	
	function validate_gstin_inactive_date($gstin_id, $wef_date, $inactive_date)
{
    // Use empty() to check for '', null, or false. No validation needed if inactive date is not set.
    if (!empty($inactive_date)) {
        try {
            // Create DateTime objects for safe comparison.
            // setTime(0, 0) removes the time component to compare dates only.
            $wefDateObj = new \DateTime($wef_date);
            $wefDateObj->setTime(0, 0);

            $inactiveDateObj = new \DateTime($inactive_date);
            $inactiveDateObj->setTime(0, 0);

            $currentDateObj = new \DateTime('today'); // 'today' automatically sets time to 00:00:00

            // Check 1: Inactive date cannot be before the WEF date.
            if ($inactiveDateObj < $wefDateObj) {
                return json_encode([
                    "status" => false, 
                    "message" => "Inactive date cannot be before the 'With Effect From' date."
                ]);
            }

            // Check 2: Inactive date cannot be a future date.
            if ($inactiveDateObj > $currentDateObj) {
                return json_encode([
                    "status" => false, 
                    "message" => "Inactive date cannot be a future date."
                ]);
            }
            
        } catch (\Exception $e) {
            // This catches errors if the date strings are in an invalid format.
            return json_encode([
                "status" => false, 
                "message" => "Invalid date format provided. Please use YYYY-MM-DD."
            ]);
        }
    }

    // If no inactive date is provided, or if all checks pass, return true.
    return json_encode(["status" => true, "message" => '']);
}
	
	
	
	  function currency_dropdown(){		      
	        $comp_currency_tbl = $this->company_id.'_compcurrcy_'.$this->session->get('ses_comp_fy_id');
			$data =  $this->db->table($comp_currency_tbl)->orderBy('comp_currency_id')->get()->getResultArray();
			$final_result = array();
			$final_result['']  = 'Choose';
			 if($data){
			   foreach($data as $row){
				  $final_result[$row['curr_symbol']] = $row['curr_symbol'];			   
					}
				}
	        return $final_result;	
     }
     
    function GetGSTINExists($data){
	 $comp_gstin      = $data['comp_gstin'];
	 $gstinmastr_tbl  = $this->company_id.'_gstinmastr_'.$this->session->get('ses_comp_fy_id');
	 
	 if(isset($data['gstinmastr_id'])){
		$data            = $this->db->table($gstinmastr_tbl)->select('gstinmastr_id')
	                    ->where('comp_gstin',$comp_gstin)
						->where('gstinmastr_id !=',$data['gstinmastr_id'])
						->get()->getRowArray(); 
	 }
	 else{
	 $data            = $this->db->table($gstinmastr_tbl)->select('gstinmastr_id')
	                    ->where('comp_gstin',$comp_gstin)->get()->getRowArray();
	 }
						//echo $this->db->getlastquery();
	 if($data)
		 return ['status'=>false];
	 else
		 return ['status'=>true];
	}
  function change_gstin_status($bogstin_id,$gstinid,$data){
	  $gstinmastr_tbl     = $this->company_id.'_gstinmastr_'.$this->session->get('ses_comp_fy_id');	 
      $this->db->table($gstinmastr_tbl)
	   ->where('gstinmastr_id',$gstinid)
	   ->where('bo_id', $bogstin_id)
	   ->update($data);
	 
    return true;
  }	
	
  function GetGSTINTypeExists($gstintype,$data){
	 $gstinmastr_id      = $data['gstinmastr_id'];
	 $bo_id              = $data['bo_id'];	
	 $get_gsttin_info    = $data['get_gsttin_info'];
	 $gstinmastr_tbl     = $this->company_id.'_gstinmastr_'.$this->session->get('ses_comp_fy_id');
	 if(isset($data['gstinmastr_id']) && $data['gstinmastr_id']>0){
	 $data               = $this->db->table($gstinmastr_tbl)->select('gstinmastr_id')
	                       ->where('comp_gstin_type',$gstintype)
						   ->where('bo_id',$bo_id)
						   ->where('gstinmastr_id !=',$gstinmastr_id)->get()->getRowArray();
	 }
	 else{
	 if($get_gsttin_info['comp_gstin_type']==1 && $gstintype==2){		
     	 return ['status'=>false];
	 }
	 else if($get_gsttin_info['comp_gstin_type']==2 && $gstintype==1){		
     	 return ['status'=>false];
	 }
	 else{
	 $data               = $this->db->table($gstinmastr_tbl)->select('gstinmastr_id')
	                       ->where('comp_gstin_type',$gstintype)
						   ->whereNotIn('comp_gstin_type',[1,2])
						   ->where('bo_id',$bo_id)
						   ->get()->getRowArray();	
						   
	 if($data)
		 return ['status'=>false];
	  else
		 return ['status'=>true];					
	   }
	   
	   
	  return ['status'=>true];  
	 }
	 //echo $this->db->getlastquery();
	 
	}
	
   function get_bbb_groups_list()
    {        
		$groups = [16,22];
		$array = $this->get_sub_group_ids_list($groups);        
        return $array;
    }

    function get_cash_groups_list()
    {        
		$groups = [23];
		$array = $this->get_sub_group_ids_list($groups);        
        return $array;
    }
 
 
 function get_sub_group_ids_list($array){    
    	if(!empty($array)){
    		$tbl_name = $this->company_id.'_acctgroupn_'.$this->session->get('ses_comp_fy_id');
    		$data = $this->db->table($tbl_name)
    					->select('acc_grp_id')
    					->whereIn('under_main_grp_id', $array)
    					->get()->getResultArray();
    	
    	
	    	if($data){
	    		foreach($data as $key => $value) {
	    			array_push($array, $value['acc_grp_id']);
	    		}
	    	}
    	}
    	return $array;
    }
    
  function get_cc_groups_list()
    {      
		$p_groups = [7,11,13];
		$tbl_name = $this->company_id.'_acctgroupn_'.$this->session->get('ses_comp_fy_id');
		$data =  $this->db->table($tbl_name)
	   					 ->select('acc_grp_id')
	   					 ->whereIn('acc_grp_parent_id', $p_groups)
	   					 ->get()->getResultArray();
        $final = [];
        if($data){
        	$final = array_column($data, 'acc_grp_id');
        }
        
        return $final;
    
    }     
    
     function company_all_accounts(){
    
       $bbb_groups = $this->get_bbb_groups_list();
	   $cc_groups = $this->get_cc_groups_list();
	   $cash_groups = $this->get_cash_groups_list();
      
      $acctmaster_tbl = $this->company_id.'_acctmaster_'.$this->session->get('ses_comp_fy_id');
      $tablresult     =  $this->db->query("SELECT acc_name as label, acc_name as value, acc_id, acc_grp_id, acc_grp_parent_id FROM `".$acctmaster_tbl."` order by `acc_name`  ");
	  $data   = $tablresult->getResultArray();
	  $final_result = array();
	  foreach ($data as $key => $value) {
	   		$is_bbb = 0;
	       	if(in_array($value['acc_grp_id'], $bbb_groups)){
	           	$is_bbb = 1;
	       	}

	        $is_cc = 0;
	       	if(in_array($value['acc_grp_id'], $cc_groups) || in_array($value['acc_grp_parent_id'], [7,11,13])){
	          	$is_cc = 1;
	       	}

	       	$is_cash = 0;
	       	if(in_array($value['acc_grp_id'], $cash_groups)){
	          	$is_cash = 1;
	       	}
	       	
	     	$final_result[]    = array(
               			"label" => ucwords($value['label']),
               			'value' => $value['value'],
               			'id'    => $value['acc_id'],
               			'account_id'    => $value['acc_id'],
               			'acc_id'      =>$value['acc_id'],
						'is_sundry'  => '0',
						'is_acc'  => '1',
						'is_bbb'  => $is_bbb,
						'is_cc'	  => $is_cc,
						'is_cash'	  => $is_cash,
               	);	  	
	       	
	       	
	       	
	   	}
	   	
       return json_encode($final_result);
  }  
    
    function insert_acc_op_bal($data){
	    $accoppybal_tbl = $this->company_id.'_accoppybal_'.$this->session->get('ses_comp_fy_id');
	   	$this->db->table($accoppybal_tbl)->insert($data);	
       	// return  $this->db->insertID();

       	$bill_mst_tbl = $this->company_id.'_billmaster_'.$this->session->get('ses_comp_fy_id');
        $this->db->table($bill_mst_tbl)
        			->where('bills_ref_name', 'UNDEFINED')
        			->where('acc_id', $data['acc_id'])
        			->update(['bill_op_bal' => $data['acc_op_bal']]);	
	}

	function get_pnl_groups()
    {
        
		$p_groups = [6,7,8,9,10,11,12,13];
		$tbl_name = $this->company_id.'_acctgroupn_'.$this->session->get('ses_comp_fy_id');
		$data =  $this->db->table($tbl_name)
	   					 ->select('acc_grp_id')
	   					 ->whereIn('acc_grp_parent_id', $p_groups)
	   					 ->get()->getResultArray();
        $final = [];
        if($data){
        	$final = array_column($data, 'acc_grp_id');
        }
        
        return $final;
    
    }

    function check_op_change_pnl($account_id, $balance)
    {
    	 $get_account_info = $this->get_account_info($account_id);
		  if(in_array($get_account_info['acc_grp_parent_id'], [6,7,8,9,10,11,12,13])){
		  	if($balance != 0)
		  		return 0;
		  }

		  if(in_array($get_account_info['acc_grp_id'], $this->get_pnl_groups())){
		  	if($balance != 0)
		  		return 0;
		  }

		return 1;
    }
   
    function update_acc_op_bal($account_id,$data){
	  $accoppybal_tbl = $this->company_id.'_accoppybal_'.$this->session->get('ses_comp_fy_id');
	  $bill_mst_tbl = $this->company_id.'_billmaster_'.$this->session->get('ses_comp_fy_id');

	  $get_account_info = $this->get_account_info($account_id);
	  if(in_array($get_account_info['acc_grp_parent_id'], [6,7,8,9,10,11,12,13])){
	  	if($data['acc_op_bal'] != 0)
	  		return 0;
	  }

	  if(in_array($get_account_info['acc_grp_id'], $this->get_pnl_groups())){
	  	if($data['acc_op_bal'] != 0)
	  		return 0;
	  }


	  $accoppybal = $this->db->table($accoppybal_tbl)->where('acc_id',$account_id)->get()->getRowArray();
	  $old_acc_op_bal = $accoppybal['acc_op_bal'];

	  if(in_array($get_account_info['acc_grp_id'], $this->get_bbb_groups()))
	  {
		  if($data['acc_op_bal'] >= $old_acc_op_bal){

		  	$diff = parseAmount($data['acc_op_bal']) - parseAmount($old_acc_op_bal);

		  	$billmaster = $this->db->table($bill_mst_tbl)->where('bills_ref_name', 'UNDEFINED')->where('acc_id', $account_id)->get()->getRowArray();
		  	$undefined_balance = $billmaster['bill_op_bal'] + $diff;

		  	$this->db->table($bill_mst_tbl)->where('bills_ref_name', 'UNDEFINED')->where('acc_id', $account_id)->update(['bill_op_bal' => $undefined_balance]);

		  	$this->update_bill_ref_txn_balance($account_id, true);
		  }

		  if($data['acc_op_bal'] < $old_acc_op_bal){
		  	$this->db->table($bill_mst_tbl)->where('bills_ref_name', 'UNDEFINED')->where('acc_id', $account_id)->update(['bill_op_bal' => $data['acc_op_bal']]);

		  	$this->db->table($bill_mst_tbl)->where('bills_ref_name !=', 'UNDEFINED')->where('acc_id', $account_id)->update(['bill_op_bal' => 0]);
		  	
		  	$this->update_bill_ref_txn_balance($account_id);
		  }
	  }

	  	$this->db->table($accoppybal_tbl)->where('acc_id',$account_id)->update($data);	
	 }

	function get_bbb_groups()
    {
        
		$groups = [16,22];
		$array = $this->get_sub_group_ids($groups);
        
        return $array;
    }

	public function update_bill_ref_txn_balance($acc_id, $undefined = false)
	{
	 	$bill_mst_tbl = $this->company_id.'_billmaster_'.$this->session->get('ses_comp_fy_id');

	 	$builder = $this->db->table($bill_mst_tbl);
	 	$builder->where('acc_id', $acc_id);
	 	if($undefined)
	 		$builder->where('bills_ref_name', 'UNDEFINED');
	 	$result = $builder->get()->getResultArray();

	 	foreach ($result as $key => $value) {
	 		$this->update_bill_txn_balance($value['bills_ref_id']);
	 	}
	}

	public function update_bill_txn_balance($bills_ref_id)
    {
    	$bal = 0;
		$bill_mst_tbl = $this->company_id.'_billmaster_'.$this->session->get('ses_comp_fy_id');
        $data = $this->db->table($bill_mst_tbl)
        				->where('bills_ref_id', $bills_ref_id)
        				->get()->getRowArray();
        if($data)
        	$bal = $data['bill_op_bal'];

    	$bill_txn_tbl = $this->company_id.'_billstxnnn_'.$this->session->get('ses_comp_fy_id');
		$this->db->query('SET @bal = '.$bal.';');
		$this->db->query('UPDATE '.$bill_txn_tbl.' SET bills_txn_bal = CASE WHEN bills_txn_drcr = "C" THEN @bal:=@bal - bills_txn_amt WHEN bills_txn_drcr = "D" THEN @bal:=@bal + bills_txn_amt ELSE 0 END where bills_ref_id = '.$bills_ref_id.' order by bills_txn_date, bills_txn_id;');  
    }
   
    public function acc_opn_balance_info($acc_id){
       $accoppybal_tbl =$this->company_id.'_accoppybal_'.$this->session->get('ses_comp_fy_id');
       return $this->db->table($accoppybal_tbl)->where('acc_id', $acc_id)->get()->getRowArray();  
      }  
   
	
   function bill_sundry_op_balance($id)
    {
    	$bsdoppybal_tbl = $this->company_id.'_bsdoppybal_'.$this->session->get('ses_comp_fy_id');
	    $result = $this->db->table($bsdoppybal_tbl)->where('bill_sundry_id', $id)->get()->getRowArray();
	    return $result; 
    }
  
  function billsundry_info($billsundry_id){	 
       $billsundry_tbl = $this->company_id.'_billsundry_'.$this->session->get('ses_comp_fy_id');
       return $this->db->table($billsundry_tbl)->where('bill_sundry_id', $billsundry_id)->get()->getRowArray();   	   
   }
   
   
     function get_group_all_accounts($group_id,$company_id){
	    $account_master_tbl = $this->company_id.'_acctmaster_'.$this->session->get('ses_comp_fy_id');
	    
	    $builder = $this->db->table($account_master_tbl); 
		$builder->select(array('acc_id','acc_name','acc_op_bal','acc_grp_id'));
        $builder->where('comp_id', $company_id);		
		$builder->where('acc_grp_id', $group_id);
		$result = $builder->get()->getResultArray();
		$final_groups= array();
		if($result){
		    foreach($result as $row){
		             $account_txn_table = $this->company_id.'_accnttxnnn_'.$row['acc_id'].'_'.$this->session->get('ses_comp_fy_id');
					 $builder = $this->db->table($account_txn_table); 
					 $builder->orderBy('acc_txn_id','DESC');
                     $builder->limit(1);					
					 $builder->where('comp_id', $this->company_id);
					 $builder->where('acc_id', $row['acc_id']);                
					 $result = $builder->get()->getRowArray();					
				     if($result){		
					     $final_account_balance = $result['acc_bal'];
					     
						 } 	
					  else{
					      // fetch opening balance if added or not 
					      	$account_info       = $this->account_info($row['acc_id']);
					      	$account_balance    = $account_info['acc_op_bal'];
					        $account_balance_type    = $account_info['acc_op_drcr']; //cr/dr
					        if( $account_balance_type=='cr')
					           $final_account_balance='-'.$account_balance;
					        else
					          $final_account_balance = $account_balance;
					  
					     
				    	}
				    	
				     
				    $row['final_group_sum'] = $final_account_balance;
				    $final_groups[]=$row;	
					 }
		        
		    }
       
		
	    return $final_groups;
   }
    
	public function get_branch_info($bo_id){       
        $data = $this->db->table('hobomaster')->where('cmp_id', $this->company_id)->where('hobo_id', $bo_id)->get()->getRowArray();
        return $data;
     }
	      
    public function get_account_name($id){
        $account_master_tbl = $this->company_id.'_acctmaster_'.$this->session->get('ses_comp_fy_id');
        $data = $this->db->table($account_master_tbl)->select('acc_name')->where('acc_id', $id)->get()->getRowArray();
        $acc_name = $data['acc_name'] ?? '';
        return $acc_name;
     }

     public function get_account_info($id){
        $account_master_tbl = $this->company_id.'_acctmaster_'.$this->session->get('ses_comp_fy_id');
        $data = $this->db->table($account_master_tbl)->where('acc_id', $id)->get()->getRowArray();
        return $data;
     }

	 public function get_compadrs_info(){
		    return $this->db->table('cmpaddrmst')->where('cmp_id', $this->company_id)->get()->getResultArray();
	 }
	
	public function save_gstinmastr($data){
		if($data['hobo_gstin_type']!=''){
		$gstin_data   = [
						'hobo_id'              => (int)$data['hobo_id'],
						'cmp_id'               => (int)$data['cmp_id'],
						'hobo_gstin'           => $data['hobo_gstin'],
						'hobo_gstin_type'      => (int)$data['hobo_gstin_type'],
						'hobo_gstin_sub_type'  => (int)$data['hobo_gstin_sub_type'],
						'hobo_gstin_state_code'=> $data['hobo_gstin_state_code']
					    ];
        $this->db->table("hobogstinm")->insert($gstin_data);
		$hobo_gstin_id  = $this->db->insertID();
		
		if($data['hobo_gstin_legal_name']!='' && $data['hobo_gstin_trade_name']){
			
			$hobo_gstin_wef_dt   = trim($data['hobo_gstin_wef_act'])   === '' ? null : $data['hobo_gstin_wef_act'];   // YYYY-MM-DD
			$hobo_gstin_inact_dt = trim($data['hobo_gstin_inact_date']) === '' ? null : $data['hobo_gstin_inact_date']; // YYYY-MM-DD

		    $hobogstdet_data   = [
						'hobo_gstin_id'        => (int)$hobo_gstin_id,
						'hobo_id'              => (int)$data['hobo_id'],
						'cmp_id'               => (int)$data['cmp_id'],
						'hobo_gstin_jurisd_st' => $data['hobo_gstin_jurisd_st'],
						'hobo_gstin_jurisd_ct' => $data['hobo_gstin_jurisd_ct'],
						'hobo_gstin_legal_name'=> $data['hobo_gstin_legal_name'],
						'hobo_gstin_trade_name'=> $data['hobo_gstin_trade_name'],						
						'hobo_gstin_wef_act'   => $hobo_gstin_wef_dt,
						'hobo_gstin_inact_date'=> $hobo_gstin_inact_dt
					    ];
            $this->db->table("hobogstdet")->insert($hobogstdet_data);
			
		  }
		}
	  } 
	  
    public function add_account($data){	
       $hobomaster_data   = [
						'cmp_id'        => $this->company_id,
						'hobo_name'     => ucwords(clean($data['hobo_name'])), //remove special characters
						'hobo_alias'    => $data['hobo_alias'],
						'hobo_op_date'  => $data['hobo_op_date'],
						'hobo_cl_date'  => $data['hobo_cl_date'],
						'hobo_zone'     => $data['hobo_zone'],
					    ];
		$exists = $this->db->table("hobomaster")
		                ->where('cmp_id', $this->company_id)
    					->where('LOWER(hobo_name)',strtolower(clean($data['hobo_name'])))
    					->countAllResults();		
        if($exists>0)
		  return ['status' => false, 'bo_id' => 0,'message'=>'Branch already exists'];	
								
        $this->db->table("hobomaster")->insert($hobomaster_data);
        $hobo_id = $this->db->insertID();
		
		if($data['hobo_state']!='' && $data['hobo_pin_zip']!=''){
		$hoboadrs_data   = [
						'hobo_id'       => $hobo_id,
						'cmp_id'        => $this->company_id,
						'hobo_addr1'    => $data['hobo_addr1'],
						'hobo_addr2'    => $data['hobo_addr2'],
						'hobo_city'     => $data['hobo_city'],
						'hobo_state'    => $data['hobo_state'],
						'hobo_pin_zip'  => $data['hobo_pin_zip'],
						'hobo_country'  => $data['hobo_country'],
					    ];
        $this->db->table("hoboaddrmt")->insert($hoboadrs_data);
		}
		
		if($data['hobo_tan']){
		$hobotan_data   = [
						'hobo_id'           => $hobo_id,
						'cmp_id'            => $this->company_id,
						'hobo_tan'          => $data['hobo_tan'],
						'hobo_tan_jurisd'   => $data['hobo_tan_jurisd'],
						'hobo_tan_wef_act'  => $data['hobo_tan_wef_act'],
						'hobo_tan_inact_date'=> $data['hobo_tan_inact_date']						
					    ];
        $this->db->table("hobotanmst")->insert($hobotan_data);
		}
		
		
        return ['status' => true, 'bo_id' => $hobo_id];
    
    }

    function create_mst_base_id($id,$type)
    {
    	$uuid  = $this->session->get('comp_uuid');
  		$UUIDtables = new UUIDtables($uuid,$this->company_id,$this->session->get('ses_comp_fy_id'));
  		$mst_base_id = $UUIDtables->get_mst_base_id($id,$type);
  		return $mst_base_id;
    }

    function delete_comp_fy_mst_map($id,$type)
    {
    	$uuid  = $this->session->get('comp_uuid');
  		$UUIDtables = new UUIDtables($uuid,$this->company_id,$this->session->get('ses_comp_fy_id'));
  		$mst_base_id = $UUIDtables->delete_comp_fy_mst_map_by_id($id,$type);
    }
    
    function get_sub_group_ids($array){
    	$tbl_name = $this->company_id.'_acctgroupn_'.$this->session->get('ses_comp_fy_id');
    	$data = $this->db->table($tbl_name)
    					->select('acc_grp_id')
    					->whereIn('under_main_grp_id', $array)
    					->get()->getResultArray();

    	if($data){
    		foreach($data as $key => $value) {
    			array_push($array, $value['acc_grp_id']);
    		}
    	}
    	return $array;
    }
     
    function get_sundry_groups()
    {
        
		$groups = [16,22];
		$array = $this->get_sub_group_ids($groups);
        
        return $array;
    
    }
    
    
    function financialYearBeginningDate()
    {	
        $month = date('m');
        if($month > 4)
        {
            $y  = date('Y');          
            $fy_start = $y."-04-01-";
        }
        else
        {
            $y = date('Y', strtotime('-1 year'));          
            $fy_start = $y."-04-01-";
        }
        return $fy_start;
    }
      
	 public function remove_accounts($ids,$comp_id){
		$ses_comp_fy_id     =  $this->session->get('ses_comp_fy_id');
		$account_master_tbl = $this->company_id.'_acctmaster_'.$this->session->get('ses_comp_fy_id');  
		       
		$ids = explode(",",$ids);
        foreach($ids as $account_id){			
			$account_info       = $this->account_info($account_id);
			
			$accnt_name         =  $account_info['acc_name'];
			
		
			$account_name       =  url_title($accnt_name,'',true);
			$account_txn_table  =  $comp_id.'_'.strtolower($account_name).'_txn_'.$ses_comp_fy_id;
			$this->db->table($account_master_tbl)->where('acc_id',$account_id)->delete();
			
			try {
                $this->db->table($account_txn_table)->where('comp_id',$comp_id)->where('acc_id',$account_id)->delete();
            } catch (\Exception $e) {
                // exit($e->getMessage());
            }
			
            
		 }
		return TRUE;
	 } 
	 
	  public function remove_single_branches($bo_id){
		$this->db->table('hobomaster')->where('cmp_id',$this->company_id)->where('hobo_id',$bo_id)->delete();
		$this->db->table('hobotanmst')->where('cmp_id',$this->company_id)->where('hobo_id',$bo_id)->delete();
		$this->db->table('hobogstinm')->where('cmp_id',$this->company_id)->where('hobo_id',$bo_id)->delete();
		$this->db->table('hobogstdet')->where('cmp_id',$this->company_id)->where('hobo_id',$bo_id)->delete();
		$this->db->table('hoboaddrmt')->where('cmp_id',$this->company_id)->where('hobo_id',$bo_id)->delete();
		return TRUE;
	  }
	 
	
	 
	public function mark_branch_ho($bo_id)
		{
      // Mark the selected branch as HO
       $this->db->table('hobomaster')
             ->where('hobo_id', $bo_id)
             ->update(['mark_ho' => '1']);

      // Unmark all other branches
       $this->db->table('hobomaster')
             ->where('hobo_id !=', $bo_id)
             ->update(['mark_ho' => NULL]);
		}
	 
	 public function verify_gstin_vouchers_exists($bo_id,$gstinid){
	 $gstin_m_tbl   = 'hobogstinm';
    $gstin_d_tbl   = 'hobogstdet';
    $vch_tbl       = 'vchtxnconso';

    /* ============================
       FETCH GSTIN VALIDITY DATES
       ============================ */

    $gstin_response = $this->db->table($gstin_m_tbl . ' m')
        ->select('d.hobo_gstin_wef_act, d.hobo_gstin_inact_date')
        ->join($gstin_d_tbl . ' d', 'd.hobo_gstin_id = m.hobo_gstin_id', 'left')
        ->where('m.hobo_id', $bo_id)
        ->where('m.hobo_gstin_id', $gstinid)
        ->get()
        ->getRowArray();

    if (!$gstin_response) {
        // GSTIN not found → safe to proceed
        return false;
    }

    /* ============================
       RESOLVE DATE RANGE
       ============================ */

    $wefdate = (!empty($gstin_response['hobo_gstin_wef_act'])) 
                ? $gstin_response['hobo_gstin_wef_act'] 
                : date('Y-m-d');

    if (!empty($gstin_response['hobo_gstin_inact_date'])) {
        $inactivedate = $gstin_response['hobo_gstin_inact_date'];
    } else {
        // still active → till today
        $inactivedate = date('Y-m-d');
    }

    /* ============================
       CHECK IF ANY VOUCHER EXISTS
       IN THIS GSTIN PERIOD
       ============================ */

    $count = $this->db->table($vch_tbl)
        ->where('hobo_id', $bo_id)
        ->where('vch_date >=', $wefdate)
        ->where('vch_date <=', $inactivedate)
        ->countAllResults();

    if ($count > 0) {
        // GSTIN already used in vouchers during this period
        return true;
    }

    return false;
	}  
	
	 function check_branch_gstins_voucher($bo_id)
     {
		 $exists=0;
		 $all_gstins = $this->SavedGSTINSList($bo_id);
         if($all_gstins){
			 foreach($all_gstins as $row){
				 $gstinid = $row['gstinmastr_id'];
				 $verify_vouchers = $this->verify_gstin_vouchers_exists($bo_id,$gstinid);
				 if($verify_vouchers)
					$exists++; 
			 }			 
		 }
		 
		if($exists >0){
	         return 1;
	     }
	     return 0;
     }
	 
	 function check_account_with_voucher($id)
     {
         $voucher_tbl = $this->company_id.'_comptxnmst_'.$this->session->get('ses_comp_fy_id');
	     $data =  $this->db->table($voucher_tbl)->where('master_id', $id)->whereIn('master_id_type',['acc','aco'])->get()->getRowArray();
	     if(!empty($data)){
	         return 1;
	     }
	     return 0;
     }
	   
	 public function update_account($data,$bo_id,$accid){
	    $hobomaster_tbl = 'hobomaster';
		
	    $table = $this->db->table($hobomaster_tbl)->where('LOWER(hobo_name)', strtolower(trim($data['hobo_name'])))
	                                                   ->where('hobo_id !=',$bo_id)
                                                	   ->where('cmp_id ',$this->company_id)
                                                	   ->get()->getRowArray(); 
	    if($table){
	        return ['status' => false, 'message' => 'Name must be unique'];
	    }
	    
	    $table = $this->db->table($hobomaster_tbl)->where('LOWER(hobo_alias)', strtolower(trim($data['hobo_alias'])))
	                                                   ->where('hobo_id !=',$bo_id)
                                                	   ->where('cmp_id ',$this->company_id)
                                                	   ->get()->getRowArray();
	    if($table){
	        return ['status' => false, 'message' => 'Alias must be unique'];
	    }
	    
		$data_hobo_data= array("hobo_name"=>$data["hobo_name"],"hobo_alias"=>$data["hobo_alias"],"hobo_op_date"=>$data["hobo_op_date"],
		                       "hobo_cl_date"=>$data["hobo_cl_date"],"hobo_zone"=>$data["hobo_zone"]);		
	    $this->db->table($hobomaster_tbl)->where('cmp_id',$this->company_id)->where('hobo_id',$bo_id)->update($data_hobo_data);
		
		
		$exists = 	$this->db->table("hoboaddrmt")->where('cmp_id',$this->company_id)->where('hobo_id',$bo_id)->get()->getRowArray();
		if($exists){
		$adrs_update_data   = [
						'hobo_addr1'  => $data['hobo_addr1'],
						'hobo_addr2'  => $data['hobo_addr2'],
						'hobo_city'   => $data['hobo_city'],
						'hobo_state'  => $data['hobo_state'],
						'hobo_pin_zip'=> $data['hobo_pin_zip'],						
						'hobo_country'=> $data['hobo_country']						
					    ];						
		$this->db->table("hoboaddrmt")->where('cmp_id',$this->company_id)->where('hobo_id',$bo_id)->update($adrs_update_data);
		}
		else{
		    $adrs_insert_data   = [
		                'cmp_id'      => $this->company_id,
		                'hobo_id'     => $bo_id,
						'hobo_addr1'  => $data['hobo_addr1'],
						'hobo_addr2'  => $data['hobo_addr2'],
						'hobo_city'   => $data['hobo_city'],
						'hobo_state'  => $data['hobo_state'],
						'hobo_pin_zip'=> $data['hobo_pin_zip'],						
						'hobo_country'=> $data['hobo_country']						
					    ];						
		$this->db->table("hoboaddrmt")->insert($adrs_insert_data);
		}
		return ['status' => true, 'bo_id' => $bo_id];	
   } 
   public function update_tanmastern($data,$bo_id){
	 
	   $tan_update_data   = [
						'hobo_tan'  => $data['hobo_tan'],
						'hobo_tan_jurisd'  => $data['hobo_tan_jurisd'],
						'hobo_tan_wef_act'   => $data['hobo_tan_wef_act'],
						'hobo_tan_inact_date'  => $data['hobo_tan_inact_date']			
					    ];						
		$this->db->table("hobotanmst")->where('cmp_id',$this->company_id)->where('hobo_id',$bo_id)->update($tan_update_data);
		return ['status' => true];	
   } 

   public function update_vendor_code($data,$account_id){
   		$account_master_tbl = $this->company_id.'_acctmaster_'.$this->session->get('ses_comp_fy_id');
   		$this->db->table($account_master_tbl)->where('acc_id',$account_id)->update($data);
   }	
   
   public function CreateAccountTxnTable($tablename){
	    $table_query ='CREATE TABLE IF NOT EXISTS `'.$tablename.'` (`acc_txn_id` bigint NOT NULL AUTO_INCREMENT , `comp_id` BIGINT(10) NOT NULL ,`acc_txn_date` DATE  NULL , `acc_txn_amount` DECIMAL(18,2)  NULL ,`acc_txn_drcr` VARCHAR(10)  NULL , `comp_vch_series_no` VARCHAR(100) NULL,`acc_id` BIGINT(10) NOT NULL ,`txn_id` BIGINT(10) NOT NULL, `voucher_type_id` BIGINT(10) NOT NULL , `acc_bal` DECIMAL(18,2) NULL,`voucher_txn_id` BIGINT(10) NULL, `bo_id` BIGINT(10) NULL,`posted_on` DATETIME NOT NULL,
					  PRIMARY KEY (`acc_txn_id`)) ENGINE = InnoDB;';
        $this->db->query($table_query);
       }
	   
	public function add_account_bank($CompanyCode,$data){
	    $company_bank_tbl = $this->company_id.'_compbanknn_'.$this->session->get('ses_comp_fy_id'); 
		$acc_bank_accno   = $data['acc_bank_accno'];
		$acc_bankname     = $data['acc_bankname'];		
		$exists = $this->db->table($company_bank_tbl)->where('comp_code',$CompanyCode)->where('acc_bank_accno',$acc_bank_accno)->where('LOWER(acc_bankname)', strtolower(trim($acc_bankname)))->get()->getRowArray(); 
	    if(!$exists){
		  $this->db->table($company_bank_tbl)->insert($data);	
	      }	   
	   }
	   
	
	
	
	public function add_gstinmastr($hobogstinn_data, $hobogstdet_data) {		
		// Step 1: Insert into the main table 'hobogstinm'
		$this->db->table('hobogstinm')->insert($hobogstinn_data);		
		// Step 2: Get the ID of the row you just inserted
		$new_hobo_gstin_id = $this->db->insertID();		
		if ($new_hobo_gstin_id) {
			// Step 3: Add the new ID to the details array
			$hobogstdet_data['hobo_gstin_id'] = $new_hobo_gstin_id;
			
			// Step 4: Insert into the details table 'hobogstdet'
			$this->db->table('hobogstdet')->insert($hobogstdet_data);
			
			return $new_hobo_gstin_id; // Return the new ID on success
		}
		
		return false; // Return false on failure
	}
	
	
	public function update_gstinmastr($bo_id,$resdata){
	  $gstinmastr_tbl = $this->company_id.'_gstinmastr_'.$this->session->get('ses_comp_fy_id'); 
      
	  $response =  $this->db->table($gstinmastr_tbl)->where('bo_id',$bo_id)->get()->getRowArray(); 
	  if($response)
	    $this->db->table($gstinmastr_tbl)->where('comp_fy_id',$this->session->get('ses_comp_fy_id'))->where('bo_id',$bo_id)->update($resdata);
      else{ 
        $gst_insert_data = array(        "comp_id"            => $this->company_id,
										 "comp_fy_id"         => $this->session->get('ses_comp_fy_id'),
		                                 "bo_id"              => $bo_id,
				                         "comp_gstin"         => $resdata['comp_gstin'],
				                         "comp_gst_jurid_st"  => $resdata['comp_gst_jurid_st'],
										 "comp_gst_jurid_ct"  => $resdata['comp_gst_jurid_ct'],
										 "comp_gstin_type"    => $resdata['comp_gstin_type'],
										 "gstin_wefdate"      => $resdata['gstin_wefdate'],
										 "gstin_inactivedate" => $resdata['gstin_inactivedate'],
										 "gstin_legal_name"   => $resdata['gstin_legal_name'],
										 "gstin_trade_name"   => $resdata['gstin_trade_name'],
										 "gstin_state_code"   => $resdata['gstin_state_code'],
										 );  
 	    $this->db->table($gstinmastr_tbl)->insert($gst_insert_data);  
	  }
	} 
	
	
	public function update_gstin_info($gstin_id, $hobogstinn_data, $hobogstdet_data)
{
    // Start a database transaction
   

    // 1. Update the main 'hobogstinm' table
    if (!empty($hobogstinn_data)) {
        $this->db->table('hobogstinm')
                 ->where('hobo_gstin_id', $gstin_id)
                 ->update($hobogstinn_data);
    }

    // 2. Update the details 'hobogstdet' table
    if (!empty($hobogstdet_data)) {
        $this->db->table('hobogstdet')
                 ->where('hobo_gstin_id', $gstin_id)
                 ->update($hobogstdet_data);
				//echo $this->db->getlastquery(); 
    }

    // Complete the transaction
   

    

    return true; // Transaction succeeded
}
	public function inactive_gstin($bo_id,$gstin_id,$inactive_date){
	  $gstinmastr_tbl = $this->company_id.'_gstinmastr_'.$this->session->get('ses_comp_fy_id'); 
	  $inactive_date  = date('Y-m-d',strtotime($inactive_date));	  
	  $resdata = array("gstin_inactivedate"=>$inactive_date);
      $this->db->table($gstinmastr_tbl)->where('gstinmastr_id',$gstin_id)
	           ->where('bo_id',$bo_id)->update($resdata);
	}
	
	public function verify_gstin_vouchers($bo_id,$gstinid){
	 $gstinmastr_tbl =  $this->company_id.'_gstinmastr_'.$this->session->get('ses_comp_fy_id'); 	
	 $vhtxnconso_tbl =  $this->company_id.'_vhtxnconso_'.$this->session->get('ses_comp_fy_id'); 	
	 $gstin_response =  $this->db->table($gstinmastr_tbl)->where('bo_id',$bo_id)->where('gstinmastr_id',$gstinid)->get()->getRowArray(); 
	 if($gstin_response){
		$gstin_wefdate       = $gstin_response['gstin_wefdate'];
		$gstin_inactivedate  = $gstin_response['gstin_inactivedate'];
		if($gstin_inactivedate!='' && $gstin_inactivedate!='0000-00-00'){
		   $inactivedate = $gstin_inactivedate;				
		}else{
		  $inactivedate = date('Y-m-d');	
		}
		
		if($gstin_wefdate!='' && $gstin_wefdate!='0000-00-00'){
		   $wefdate = $gstin_wefdate;				
		}else{
		  $wefdate = date('Y-m-d');	
		}
		
	  $response = $this->db->table($vhtxnconso_tbl)
	              ->where('bo_id',$bo_id)
				  ->where('voucher_date >=',$wefdate)
				  ->where('voucher_date <=',$inactivedate)
				  ->get()->getNumRows();				 
	 if($response)
		 return array("status"=>false);
	    else{
		 $this->db->table($gstinmastr_tbl)
	              ->where('bo_id',$bo_id)
				  ->where('gstinmastr_id',$gstinid)->delete();
			  
				  
		 return array("status"=>true); 
	     }
	 }	 
	 return array("status"=>true); 
	}   
	
    public function add_account_contacts($CompanyCode,$data){
       
        $account_contact_tbl = $this->company_id.'_acctcontnn_'.$this->session->get('ses_comp_fy_id');
       
		$acc_cont_mobile = $data['acc_cont_mobile'];
        $acc_cont_name1  = $data['acc_cont_name1'];
		$exists = $this->db->table($account_contact_tbl)->where('comp_code',$CompanyCode)->where('acc_cont_mobile',$acc_cont_mobile)->where('LOWER(acc_cont_name1)', strtolower(trim($acc_cont_name1)))->get()->getRowArray(); 
	    if(!$exists){
		  $this->db->table($account_contact_tbl)->insert($data);	
	      }	   
	   }
   
   
  public function ajax_branch_list()
{
    $comp_id  = $this->session->get('ses_company_id');

    // Filters (kept but not used in this snippet)
    if (isset($_POST["pq_filter"])) {
        $filter_data = json_decode($_POST["pq_filter"], true);
        $pq_filters  = $filter_data['data'][0];
        $condition   = $pq_filters['condition'] ?? '';
        $search_text = strtolower($pq_filters['value']);
        $dataIndx    = $pq_filters['dataIndx'];
    } else {
        $search_text = '';
        $dataIndx    = '';
        $condition   = '';
    }

    // Lookup tables for state/country
    $stateRows = $this->aicountly_db
        ->table("aicountly_stateslist_univdb", false)
        ->select('state_id, state_name', false)
        ->get()
        ->getResultArray();
    $stateMap = [];
    foreach ($stateRows as $s) {
        $stateMap[$s['state_id']] = $s['state_name'];
    }

    $countryRows = $this->aicountly_db
        ->table("aicountly_countrylst_univdb", false)
        ->select('countryid, countryname', false)
        ->get()
        ->getResultArray();
    $countryMap = [];
    foreach ($countryRows as $c) {
        $countryMap[$c['countryid']] = $c['countryname'];
    }

    // Builder: left join so branches without address still appear
    $builder = $this->db->table("hobomaster h");
    $builder->select([
        'h.hobo_id',
        'h.cmp_id',
        'h.mark_ho',
        'h.hobo_name',
        'h.hobo_alias',
        'h.hobo_op_date',
        'h.hobo_cl_date',
        'a.hobo_addr1',
        'a.hobo_addr2',
        'a.hobo_city',
        'a.hobo_pin_zip',
        'a.hobo_state',   // assumed to be state_id
        'a.hobo_country', // assumed to be countryid
    ]);
    $builder->join("hoboaddrmt a", "h.hobo_id = a.hobo_id AND a.cmp_id = " . (int)$comp_id, 'left');
    $builder->where('h.cmp_id', $comp_id);

    $pq_curPage = isset($_POST["pq_curpage"]) ? (int)$_POST["pq_curpage"] : 1;
    $pq_rPP     = isset($_POST["pq_rpp"]) ? (int)$_POST["pq_rpp"] : 10;
    if ($pq_curPage < 1) $pq_curPage = 1;
    if ($pq_rPP < 1) $pq_rPP = 10;

    $countBuilder  = clone $builder;
    $total_Records = $countBuilder->countAllResults(false);

    $offset = ($pq_rPP * ($pq_curPage - 1));
    if ($offset > $total_Records && $total_Records > 0) {
        $pq_curPage = (int)ceil($total_Records / $pq_rPP);
        $offset = ($pq_rPP * ($pq_curPage - 1));
    }
    if ($offset < 0) $offset = 0;

    $builder->orderBy('h.hobo_name');
    $builder->limit($pq_rPP, $offset);
    $result = $builder->get()->getResultArray();

    $records = [];
    foreach ($result as $values) {
        $checkbox_html = '<input name="batches_ids[]" class="checkbox batches_row" data-id="' . $values['hobo_id'] . '" type="checkbox" value="' . $values['hobo_id'] . '">';

        $stateName   = '';
        if (!empty($values['hobo_state']) && isset($stateMap[$values['hobo_state']])) {
            $stateName = $stateMap[$values['hobo_state']];
        }

        $cityName = $values['hobo_city'] ?? '';

        $name = ucwords($values['hobo_name']);
        if ((int)$values['mark_ho'] === 1) {
            $name = '<strong>' . $name . ' (HO)</strong>';
        }

        $records[] = [
            'chkbx'         => $checkbox_html,
            'acc_id'        => $values['hobo_id'],
            'account_name'  => $name,
            'account_alias' => $values['hobo_alias'],
            'city_name'     => $cityName,
            'state_name'    => $stateName,
            'isedited'      => ($values['mark_ho'] == 1) ? 0 : 1
        ];
    }

    echo "{\"totalRecords\":" . $total_Records . ",\"curPage\":" . $pq_curPage . ",\"data\":" . json_encode($records) . "}";
}
	 
	 public function ajax_branch_gstins_list(){
	    	
	    $comp_id         = $this->session->get('ses_company_id');
	    $base_url        = base_url().'/'.getenv('AdminPath');
	    
	    if(isset($_POST["pq_filter"])){
	       $pq_filter     = $_POST["pq_filter"];
	       
	       $filter_data  = json_decode($_POST["pq_filter"],true);
	      
	    
	      $pq_filters   = $filter_data['data'][0];
	    
	       if(isset($pq_filters['condition']))
	      $condition   = $pq_filters['condition'];
	   else
		  $condition='';
	      $search_text = strtolower($pq_filters['value']);
	      $dataIndx    = $pq_filters['dataIndx'];  
	       
	    }
	    else{
	      $pq_filter     ='';
	      $search_text   ='';
	      $dataIndx      ='';
	      $condition='';
	    }
	    $gstinmastr_tbl = $this->company_id.'_gstinmastr_'.$this->session->get('ses_comp_fy_id'); 
	    $builder        = $this->db->table($gstinmastr_tbl); 
	   
        if(isset($_POST["pq_curpage"]) && isset($_POST["pq_rpp"]) )
            {
                $pq_curPage = (int)$_POST["pq_curpage"];
                $pq_rPP     = (int)$_POST["pq_rpp"];
            } 
        $builder->where('comp_fy_id', $this->session->get('ses_comp_fy_id'));
	    $builder->where('bo_id', $this->session->get('ses_boid'));
	 	$result = $builder->get()->getResultArray();
        
         $records = array(); 	
		$gstintypes_list = gstintypes_list();
        foreach($result as $values){  			
			$checkbox_html ='<input name="batches_ids[]" class="checkbox batches_row" data-id="'.$values['gstinmastr_id'].'" type="checkbox" value="'.$values['gstinmastr_id'].'">';
				$gstin_type="";
				if($values['comp_gstin_type']!=''){
				 $gstin_type = 	$gstintypes_list[$values['comp_gstin_type']];
				}
				$records[] = array(	
			          'chkbx'         => $checkbox_html,           
 			          'gstin'         => $values['comp_gstin'],
                      'gstin_type'    => $gstin_type,
					  'jurd_state'    => $values['comp_gst_jurid_st'],
					  'jurd_centre'   => $values['comp_gst_jurid_ct'],
                      'it_jurd'       => '',				                    
                      'state_code'    => $values['gstin_state_code'],
					  'wef_date'      => ($values['gstin_wefdate']!='')?date('Y-m-d',strtotime($values['gstin_wefdate'])):'',
					  'legal_name'    => $values['gstin_legal_name'],					                    
                      'trade_name'    => $values['gstin_trade_name']				  
 					  ); 
		           }	 
	
	    if($pq_curPage==0){$pq_curPage=1;}
    	 $offset = ($pq_rPP * ($pq_curPage - 1));
         $total_records = count($records);
        if($offset > $total_records){        
                $pq_curPage = ceil($total_records / $pq_rPP);
                $offset = ($pq_rPP * ($pq_curPage - 1));
            }            
	  $data = 	 array_slice($records, $offset, $pq_rPP);
	  if($records)
	    $totalrec = count($records);
	  else
	   $totalrec = 0;
       echo  "{\"totalRecords\":" .$totalrec . ",\"curPage\":" . $pq_curPage . ",\"data\":".json_encode($data)."}"; 
        
        
     } 
     public function get_account_group_name($id){
         $account_grp_tbl = $this->company_id.'_acctgroupn_'.$this->session->get('ses_comp_fy_id');
         $data = $this->db->table($account_grp_tbl)->select('acc_grp_name')->where('acc_grp_id', $id)->get()->getRowArray();
         return $data['acc_grp_name'];
     }
     
  public function add_group($data){
       $account_grp_tbl = $this->company_id.'_acctgroupn_'.$this->session->get('ses_comp_fy_id');
	  
	   $exists = $this->db->table( $account_grp_tbl)->where('LOWER(acc_grp_name)', strtolower(trim($data['acc_grp_name'])))->get()->getRowArray(); 
	    if($exists)
		 return "0";
	   else{
		  $this->db->table($account_grp_tbl)->insert($data);
		  $group_id = $this->db->insertID();
		  return $group_id;
	     }
      }   
   public function remove_groups($ids,$comp_id){
        $account_grp_tbl = $this->company_id.'_acctgroupn_'.$this->session->get('ses_comp_fy_id');
	
		$ids = explode(",",$ids);
        foreach($ids as $group_id){			
			$this->db->table($account_grp_tbl)->where('acc_grp_id',$group_id)->delete();
		 }
		return TRUE;
	 } 	
	 
	public function remove_single_groups($id){
        $account_grp_tbl = $this->company_id.'_acctgroupn_'.$this->session->get('ses_comp_fy_id');
	
		$this->db->table($account_grp_tbl)->where('acc_grp_id',$id)->delete();
		 
		return TRUE;
	 } 	
	 
	 
   public function update_group($update_data,$group_id){
        $account_grp_tbl = $this->company_id.'_acctgroupn_'.$this->session->get('ses_comp_fy_id');
	    $this->db->table($account_grp_tbl)->where('acc_grp_id',$group_id)->update($update_data);
		return true;	
   } 	
   
   function group_primary_dropdown(){		      
             $account_grp_tbl = $this->company_id.'_grpparentn_'.$this->session->get('ses_comp_fy_id');
				  
			$data =  $this->db->table($account_grp_tbl)->orderBy('acc_grp_parent')->where('	acc_grp_parent_id','14')->get()->getResultArray();
			$final_result = array();
			$final_result['']  = 'Choose';
			 if($data){
			   foreach($data as $row){
				  $final_result[$row['acc_grp_parent_id']] = ucwords($row['acc_grp_parent']);			   
					}
				}
		
		
	  return $final_result;	
     }

  function group_main_dropdown($group_id = 0){		      
             $account_grp_tbl = $this->company_id.'_acctgroupn_'.$this->session->get('ses_comp_fy_id');
				  
			$builder =  $this->db->table($account_grp_tbl);
			if($group_id != 0)
				$builder->where('acc_grp_id !=', $group_id);
            $builder->where('acc_grp_parent_id',14);
			$builder->orderBy('acc_grp_name');
			$data = $builder->get()->getResultArray();
			$final_result = array();
			$final_result['']  = 'Choose';
			 if($data){
			   foreach($data as $row){
				  $final_result[$row['acc_grp_id']] = ucwords($row['acc_grp_name']);			   
					}
				}
		
		
	  return $final_result;	
     }
	 
 function branch_group_main_dropdown($group_id = 0){		      
             $account_grp_tbl = $this->company_id.'_acctgroupn_'.$this->session->get('ses_comp_fy_id');
				  
			$builder =  $this->db->table($account_grp_tbl);
			if($group_id != 0)
				$builder->where('acc_grp_id !=', $group_id);
             $builder->where('acc_grp_parent_id',14);
			$builder->orderBy('acc_grp_name');
			$data = $builder->get()->getResultArray();
			$final_result = array();
			$final_result['']  = 'Choose';
			 if($data){
			   foreach($data as $row){
				  $final_result[$row['acc_grp_id']] = ucwords($row['acc_grp_name']);			   
					}
				}
		
		
	  return $final_result;	
     }

   function account_info($account_id){	 
       $builder= $this->db->table('hobomaster');
	   $builder->join('hoboaddrmt','hoboaddrmt.hobo_id=hobomaster.hobo_id','left');
	   $builder->where('hobomaster.hobo_id', $account_id);
	   $builder->where('hobomaster.cmp_id', $this->company_id);
	   $result =$builder->get()->getRowArray();  
       return 	$result;		  
    }
   
   function branch_gsttins_info($bo_id){
	 $gstinmastr_tbl = 'hobogstinm';  
	 $builder = $this->db->table($gstinmastr_tbl);
	 $builder->join('hobogstdet','hobogstdet.hobo_id=hobogstinm.hobo_id','left');
	 $builder->where('hobogstinm.hobo_id', $bo_id);
	 $builder->where('hobogstinm.cmp_id', $this->company_id);
	 $result = $builder->get()->getResultArray();
	 return $result;
    }  
 
 function get_tan_info($bo_id){
	 $tanmastern_tbl = 'hobotanmst';  
	 return $this->db->table($tanmastern_tbl)
	        ->where('hobo_id', $bo_id)
			 ->where('cmp_id', $this->company_id)
			->get()->getRowArray();
    } 
	
   function main_group_info($acc_grp_id){	 
      $account_grp_tbl = $this->company_id.'_acctgroupn_'.$this->session->get('ses_comp_fy_id'); 
  	  return $this->db->table($account_grp_tbl)->where('acc_grp_id', $acc_grp_id)->get()->getRowArray();   	   
   }
   function sub_group_info($acc_grp_id){	 
      $account_grp_tbl = $this->company_id.'_acctgroupn_'.$this->session->get('ses_comp_fy_id'); 
  	  return $this->db->table($account_grp_tbl)->where('under_acc_grp_id', $acc_grp_id)->get()->getResultArray();   	   
   }

   function check_group_restriction($acc_grp_id, $tag){	 
      $account_grp_tbl = $this->company_id.'_acctgroupn_'.$this->session->get('ses_comp_fy_id'); 
  	  return $this->db->table($account_grp_tbl)->where('acc_grp_id', $acc_grp_id)->where('restrictions', $tag)->get()->getRowArray();   	   
   }

   function group_parent_info($acc_grp_id){	 
      $account_grp_tbl = $this->company_id.'_grpparentn_'.$this->session->get('ses_comp_fy_id'); 
  	  return $this->db->table($account_grp_tbl)->where('acc_grp_parent_id', $acc_grp_id)->get()->getRowArray();   	   
   }

   function check_parent_restriction($acc_grp_parent_id, $tag){	 
      $account_grp_tbl = $this->company_id.'_grpparentn_'.$this->session->get('ses_comp_fy_id'); 
  	  return $this->db->table($account_grp_tbl)->where('acc_grp_parent_id', $acc_grp_parent_id)->where('restrictions', $tag)->get()->getRowArray();   	   
   }
   function get_parimary_groups($acc_grp_parent_id, $group_id = 0){	 
      $account_grp_tbl = $this->company_id.'_acctgroupn_'.$this->session->get('ses_comp_fy_id'); 
      $builder = $this->db->table($account_grp_tbl);
      $builder->where('acc_grp_primary', 'Y');
      $builder->where('acc_grp_parent_id', $acc_grp_parent_id);
      if($group_id != 0)
      	$builder->where('acc_grp_id !=', $group_id);

  	  return $builder->get()->getResultArray();   	   
   }

   
   function check_account_with_group($group_id)
   {
       $account_master_tbl = $this->company_id.'_acctmaster_'.$this->session->get('ses_comp_fy_id');  
	   $account_data = $this->db->table($account_master_tbl)->where('acc_grp_id',$group_id)->get()->getRowArray(); 
	    if(empty($account_data)){
	        return 0;
	    }
		return 1;
   }
   function check_bill_sundry_with_group($group_id)
   {
       $billsundry_tbl  = $this->company_id.'_billsundry_'.$this->session->get('ses_comp_fy_id');  
	   $account_data = $this->db->table($billsundry_tbl)->where('acc_grp_id',$group_id)->get()->getRowArray(); 
	    if(empty($account_data)){
	        return 0;
	    }
		return 1;
   }
   
   function check_account($account_name,$group_name)
   {
       $account_grp_tbl = $this->company_id.'_acctgroupn_'.$this->session->get('ses_comp_fy_id');
       
	   $group_data = $this->db->table( $account_grp_tbl)->where('comp_id',$this->company_id)->where('LOWER(acc_grp_name)', strtolower(trim($group_name)))->get()->getRowArray(); 
	    if(empty($group_data)){
	        return 0;
	    }
	   $group_id = $group_data['acc_grp_id'];
	   
       $account_master_tbl = $this->company_id.'_acctmaster_'.$this->session->get('ses_comp_fy_id');  
	   $account_data = $this->db->table($account_master_tbl)->where('acc_name', trim($account_name))->where('acc_grp_id',$group_id)->get()->getRowArray(); 
	    if(empty($account_data)){
	        return 0;
	    }
		return 1;
   }
   
}