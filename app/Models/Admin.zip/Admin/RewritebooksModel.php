<?php
namespace App\Models\Admin;
use CodeIgniter\Model;
use App\Models\Admin\TransactionModel;
use App\Libraries\externaldb;
use App\Libraries\ERPtables;
use App\Libraries\UUIDtables;

class RewritebooksModel extends Model	{
	
 public function __construct() {
       parent::__construct();        
		$this->externaldb    = new externaldb();	
		$this->TransactionModel  = new TransactionModel();	
		$this->session       = \Config\Services::session();
		$this->bo_id         = $this->session->get('ses_boid');
		$this->fy_id         = $this->session->get('ses_comp_fy_id');
		$this->company_id    = $this->session->get('ses_company_id');
    }

   public function NextFyExists(){
    $fy_id = $this->session->get('ses_comp_fy_id');
    $count = $this->db->table('cmpfymastr')
        ->where('is_imported', '1')
        ->where('cmp_id', $this->company_id)
        ->where('cmpfymastr_id >', $fy_id)
        ->countAllResults();
       return $count > 0;
     }
   
   function get_company_all_fy_list(){
		return $this->aicountly_db->table("aicountly_cmpfymastr_univdb")
		->where('comp_id',$this->company_id)->orderBy('fy_begndt')->get()->getResultArray();
	}
	
   public function get_account_details(){	     
    $builder = $this->db->table("acctmaster acct");
    $builder->join(
        "undercrsmt", 
        "undercrsmt.crs_mst_id = acct.acc_id 
         AND undercrsmt.crs_mst_type IN (1, 14) 
         AND undercrsmt.cmp_id = $this->company_id 
         AND undercrsmt.cmpfymastr_id = $this->fy_id", 
        'left'
    );
    $builder->select('acct.acc_id as id, acct.acc_name as name, undercrsmt.under_crs_mst_id as acc_grp_id, undercrsmt.crs_mst_parent_id as acc_grp_parent_id, acct.bsd_id');
    $builder->where("acct.cmp_id", $this->company_id);
    $builder->where("(undercrsmt.cmpfymastr_id = $this->fy_id)");
    $result = $builder->get()->getResultArray();
    return $result;
}
   
   public function truncate_reporting_tables($table_id){
	try{
	  $table = $this->company_id.$table_id.$this->session->get('ses_comp_fy_id');
	  $query = "TRUNCATE TABLE `".$table."`;";
	  $this->db->query($query);
	  return array('status'=>true,'message'=>'');
	}
	catch (\Exception $e) {
       return array('status'=>false,'message'=>$e->getMessage().'<br> Line No. '.$e->getLine());
	}			
   }

   public function get_bill_sundry_details(){
      
	  	$billsundry_tbl  = $this->company_id.'_billsundry_'.$this->session->get('ses_comp_fy_id');
	  	$builder  =  $this->db->table($billsundry_tbl);
	   $builder->select('bill_sundry_name as name, bill_sundry_id as id');
	   $result = $builder->get()->getResultArray();
		
		return $result;
   }

   public function get_bill_by_bill_details(){
      
   	$final = [];
   	$final[] = ['name' => 'Opening Balances', 'id' => 0];

	  	$bill_mst_tbl = $this->company_id.'_billmaster_'.$this->session->get('ses_comp_fy_id');
	  	$builder  =  $this->db->table($bill_mst_tbl);
	   $builder->select('bills_ref_name as name, bills_ref_id as id');
	   $builder->where('bo_id',$this->bo_id);
	   $result = $builder->get()->getResultArray();
	   foreach ($result as $key => $value) {
	   	$final[] = $value;
	   }
		
		return $final;
   }

   public function get_cost_center_details(){
      
	  	$cc_mst_tbl = $this->company_id.'_costctmstr_'.$this->session->get('ses_comp_fy_id');
	  	$builder  =  $this->db->table($cc_mst_tbl);
	   $builder->select('cc_name as name, cc_id as id');
	   $result = $builder->get()->getResultArray();
		
		return $result;
   }
   public function get_item_count(): int{
    // Adjust table/filters to match your schema (e.g., active items only)
    $row = $this->db->query("
        SELECT COUNT(*) AS cnt
        FROM itemmaster i
        WHERE i.cmp_id = ? 
    ", [$this->company_id])->getRowArray();

    return (int)($row['cnt'] ?? 0);
   }
   public function get_item_page(int $offset, int $limit): array
{
    // Only the columns needed for processing + UI errors
    return $this->db->query("
        SELECT i.itm_id AS id, i.itm_name AS name
        FROM itemmaster i
        WHERE i.cmp_id = ?
        ORDER BY i.itm_id
        LIMIT ? OFFSET ?
    ", [$this->company_id, $limit, $offset])->getResultArray();
}
   public function get_item_details($item_id=""){
	  $builder = $this->db->table("itemmaster itmst");
	  $builder->select('itmst.itm_id as id, itmst.itm_name as named');
	  $builder->where("itmst.cmp_id",$this->company_id);
	  $result = $builder->get()->getResultArray();
	
      if($item_id!=''){	 
	  $builder->where("item_id",$item_id);
	  }
	  $result = $builder->get()->getResultArray();		
	  return $result;
   }

   public function get_project_details(){
      
	  	$projectmst_tbl = $this->company_id.'_projectmst_'.$this->session->get('ses_comp_fy_id');
	  	$builder  =  $this->db->table($projectmst_tbl);
	   $builder->select('project_name as name, project_id as id');
	   $result = $builder->get()->getResultArray();
		
		return $result;
   }

   public function get_voucher_type_details(){
	    $fy_id = $this->session->get('ses_comp_fy_id');
		$voucher_tbl        = "{$this->company_id}_vhtxnconso_{$fy_id}";
		$voucher_type_tbl   = "{$this->company_id}_cmpvchtype_{$fy_id}";
		$voucher_series_tbl = "{$this->company_id}_cmpvchseri_{$fy_id}";
		$this->db->query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''));");
		
		$builder = $this->db->table("$voucher_tbl vt");
		$builder->select([
			"vtype.comp_vch_type AS name",
			"vtype.voucher_type_id AS id"
		]);
		$builder->join("$voucher_type_tbl vtype", "vtype.voucher_type_id = vt.voucher_type_id", 'inner');
		$builder->join("$voucher_series_tbl vseries", "vseries.comp_vch_series_id = vt.comp_vch_series_id", 'inner');
		$builder->where('vt.comp_id', $this->company_id);
		$builder->where('vt.bo_id', $this->bo_id);
		$builder->groupBy('vt.voucher_type_id');
		$builder->orderBy('vt.comp_vch_no');
		$result = $builder->get()->getResultArray();
	   
		
		return $result;
   }
   
   public function get_repbon_items_details($method_id,$item_id=''){
	 if(isset($_GET['from_date']))
		$from_date = $_GET['from_date'];
	  else
		 $from_date ='';
	 if(isset($_GET['to_date']))
		$to_date = $_GET['to_date'];
	  else
		 $to_date ='';
	
        $from_date      = date('Y-m-d',strtotime(validate_fy_from_date($from_date)));
        $to_date        = date('Y-m-d',strtotime(validate_fy_to_date($to_date)));
	    $itemrepbon_tbl = $this->company_id.'_itemrepbon_'.$this->session->get('ses_comp_fy_id');
	    $voucher_tbl    = $this->company_id.'_vhtxnconso_'.$this->session->get('ses_comp_fy_id');
		$this->db->query("SET sql_mode = ( SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', '') );");	    
		$builder = $this->db->table($itemrepbon_tbl);	
		$builder->select($itemrepbon_tbl.'.voucher_txn_id, item_id_unit_id');
		
		if($item_id)
		$builder->like( 'item_id_unit_id', $item_id . '_', 'after');     
		
		
		$builder->where($itemrepbon_tbl.'.bo_id', $this->bo_id);
		if($from_date!='')
		$builder->where('item_txn_date >=', $from_date);
		if($to_date!='')
		$builder->where('item_txn_date <=', $to_date);
	   
		$builder->groupBy(['item_id_unit_id']);
		$builder->orderBy('item_id_unit_id');		
		$result = $builder->get()->getResultArray();
		$info   = array(); 
		foreach($result as $row){ 			
		    $itmdntd = explode("_",$row['item_id_unit_id']);			
			$item = $this->TransactionModel->get_item_info($itmdntd[0]);
	    	$item_name = $item['item_name'];
	    	if($method_id==0)
	    	$item_default_val_method = $item['valmethod_id'];
	    	else
	       	$item_default_val_method =	$method_id;
			$item_unit_info = $this->TransactionModel->item_unit_info($itmdntd[1]);
			   
			if(isset($item_unit_info)){
    				$item_unit = $item_unit_info['item_unit'];
			}
			else{				
		    		$item_unit = 'No Unit';	
				}	 
			$voucher_no = $item_name.'('.$item_unit.')';
		    $info[]     = array("name"=>$voucher_no,"method_id"=>$item_default_val_method,"item_id_unit_id"=>$row["item_id_unit_id"]);
		}
	  return $info;	
  	  	  
   } 
   
   	public function empty_reporting_tables_data($item_id_unit_id,$item_id,$method_id){
	    $table1 = $this->company_id.'_itemrepall_'.$this->session->get('ses_comp_fy_id');
		$table2 = $this->company_id.'_itemrepmcn_'.$this->session->get('ses_comp_fy_id');
		$table3 = $this->company_id.'_itemrepgrp_'.$this->session->get('ses_comp_fy_id');
		$table4 = $this->company_id.'_itemrepcat_'.$this->session->get('ses_comp_fy_id');
		$table5 = $this->company_id.'_itemrepprj_'.$this->session->get('ses_comp_fy_id');
		$table6 = $this->company_id.'_itemrepbon_'.$this->session->get('ses_comp_fy_id');
		$table7 = $this->company_id.'_itemrepbat_'.$this->session->get('ses_comp_fy_id');
		$table8 = $this->company_id.'_buffercalc_'.$this->session->get('ses_comp_fy_id');
        $table9 = $this->company_id.'_buffrevlog_'.$this->session->get('ses_comp_fy_id');
        $itemtxnvaln_tbl  = $this->company_id.'_itemtxnval_'.$item_id.'_'.$this->session->get('ses_comp_fy_id');
  	  
		$this->db->table($table1)->where('voucher_txn_id >',0)->where('item_txn_id >',0)->where('item_id_unit_id',$item_id_unit_id)->where('method_id',$method_id)->delete();
		$this->db->table($table2)->where('voucher_txn_id >',0)->where('item_txn_id >',0)->where('item_id_unit_id',$item_id_unit_id)->where('method_id',$method_id)->delete();
		$this->db->table($table3)->where('voucher_txn_id >',0)->where('item_txn_id >',0)->where('item_id_unit_id',$item_id_unit_id)->where('method_id',$method_id)->delete();
		$this->db->table($table4)->where('voucher_txn_id >',0)->where('item_txn_id >',0)->where('item_id_unit_id',$item_id_unit_id)->where('method_id',$method_id)->delete();
		$this->db->table($table5)->where('voucher_txn_id >',0)->where('item_txn_id >',0)->where('item_id_unit_id',$item_id_unit_id)->where('method_id',$method_id)->delete();
		$this->db->table($table6)->where('voucher_txn_id >',0)->where('item_txn_id >',0)->where('item_id_unit_id',$item_id_unit_id)->where('method_id',$method_id)->delete();
		
		$this->db->table($table7)->where('voucher_txn_id >',0)->where('item_txn_id >',0)->where('item_id_unit_id',$item_id_unit_id)->where('method_id',$method_id)->delete();		
        $this->db->table($table8)->where('method_id',$method_id)->delete();
        $this->db->table($table9)->where('method_id',$method_id)->delete();
		$this->db->table($itemtxnvaln_tbl)->where('item_id',$item_id)->where('method_id',$method_id)->delete();
		 
   }
   
   public function get_voucher_items_valuation_list($voucher_txn_id,$method_id,$item_id_unit_id){
	 
	 if(isset($_GET['from_date']))
		$from_date = $_GET['from_date'];
	  else
		 $from_date ='';
	 if(isset($_GET['to_date']))
		$to_date = $_GET['to_date'];
	  else
		 $to_date ='';
	    
		      
        $from_date = date('Y-m-d',strtotime(validate_fy_from_date($from_date)));
        $to_date = date('Y-m-d',strtotime(validate_fy_to_date($to_date)));
	    $itemrepbon_tbl = $this->company_id.'_itemrepbon_'.$this->session->get('ses_comp_fy_id');
	    $voucher_tbl    = $this->company_id.'_vhtxnconso_'.$this->session->get('ses_comp_fy_id');
		$this->db->query("SET sql_mode = ( SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', '') );");
	    
		$builder = $this->db->table($itemrepbon_tbl);	
		$builder->select($itemrepbon_tbl.'.voucher_txn_id, item_id_unit_id');
		$builder->where($itemrepbon_tbl.'.item_id_unit_id', $item_id_unit_id);
		$builder->where($itemrepbon_tbl.'.bo_id', $this->bo_id);
		if($from_date!='')
		$builder->where('item_txn_date >=', $from_date);
		if($to_date!='')
		$builder->where('item_txn_date <=', $to_date);
	    $builder->where('voucher_txn_id >',0);
	    $builder->groupBy(['voucher_txn_id']);
		$builder->orderBy('item_txn_date');
		$builder->orderBy('voucher_txn_id');
		$result = $builder->get()->getResultArray();
		$info   = array(); 
		foreach($result as $row){ 
		      $item_id_unit_id = explode("_",$row['item_id_unit_id']);
		      $voucherconsinfo =  $this->TransactionModel->get_voucherconsinfo($row["voucher_txn_id"]);
		      if(isset($voucherconsinfo) && isset($item_id_unit_id[0])){
			  $info[]    = array("voucher_name"=>'Voucher No: '.$voucherconsinfo['comp_vch_no'],"method_id"=>$method_id,"itmiduntid"=>$item_id_unit_id[0],
		                        "container_id"=>$row['item_id_unit_id'], "voucher_txn_id"=>$row["voucher_txn_id"],"id"=>$row["voucher_txn_id"]);
			  }
		} 
	  return $info;	
  	  	  
   }
   
    public function get_voucher_items_details($method_id){	     
	   	if(isset($_GET['from_date']))
		$from_date = $_GET['from_date'];
	  else
		 $from_date ='';
	 if(isset($_GET['to_date']))
		$to_date = $_GET['to_date'];
	  else
		 $to_date ='';
	
      $from_date = date('Y-m-d',strtotime(validate_fy_from_date($from_date)));
      $to_date = date('Y-m-d',strtotime(validate_fy_to_date($to_date)));
	    $this->db->query("SET sql_mode = ( SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', '') );");
  	  	
		$voucher_tbl = $this->company_id.'_vhtxnconso_'.$this->session->get('ses_comp_fy_id');
		$voucher_type_tbl = $this->company_id.'_cmpvchtype_'.$this->session->get('ses_comp_fy_id');
		$voucher_series_tbl = $this->company_id.'_cmpvchseri_'.$this->session->get('ses_comp_fy_id');
		$comp_txn_tbl = $this->company_id.'_comptxnmst_'.$this->session->get('ses_comp_fy_id');
        $builder = $this->db->table($voucher_tbl);
		$builder->select($voucher_tbl.'.*');
		$builder->join($comp_txn_tbl, $comp_txn_tbl.'.voucher_txn_id ='.$voucher_tbl.'.voucher_txn_id');
		$builder->select('master_id, master_id_type, txn_id');
		$builder->join($voucher_type_tbl, $voucher_type_tbl.'.voucher_type_id ='.$voucher_tbl.'.voucher_type_id');
		$builder->select($voucher_type_tbl.'.comp_vch_type');
		$builder->join($voucher_series_tbl, $voucher_series_tbl.'.comp_vch_series_id  ='.$voucher_tbl.'.comp_vch_series_id');
		$builder->select($voucher_series_tbl.'.comp_vch_series');
		$builder->where($voucher_tbl.'.comp_id', $this->company_id);
		$builder->where($voucher_tbl.'.bo_id', $this->bo_id);
		$builder->where('master_id_type','itm');		
		if($from_date!='')
		$builder->where('voucher_date >=', $from_date);
		if($to_date!='')
		$builder->where('voucher_date <=', $to_date);
		$builder->where('voucher_tag !=', 'OPTIONL');
		$builder->groupBy(['voucher_txn_id', 'master_id']);
		$builder->orderBy('voucher_date');
		$builder->orderBy('voucher_txn_id');
		$result = $builder->get()->getResultArray();
		$info   = array(); 
		foreach($result as $row){ 
			$voucher_no   = $row['comp_vch_no'];
		   
		    $this->empty_reporting_tables($row["master_id"],$row["voucher_txn_id"],$method_id);		    
		    $info[]      = array("name"=>$voucher_no,"item_id"=>$row["master_id"],"method_id"=>$method_id,
		                         "voucher_txn_id"=>$row["voucher_txn_id"],"id"=>$row["voucher_txn_id"]);
		}
	  return $info;
   }
   public function empty_reporting_tables($item_id,$voucher_txn_id,$method_id){
	    $table1 = $this->company_id.'_itemrepall_'.$this->session->get('ses_comp_fy_id');
		$table2 = $this->company_id.'_itemrepmcn_'.$this->session->get('ses_comp_fy_id');
		$table3 = $this->company_id.'_itemrepgrp_'.$this->session->get('ses_comp_fy_id');
		$table4 = $this->company_id.'_itemrepcat_'.$this->session->get('ses_comp_fy_id');
		$table5 = $this->company_id.'_itemrepprj_'.$this->session->get('ses_comp_fy_id');
		$table6 = $this->company_id.'_itemrepbon_'.$this->session->get('ses_comp_fy_id');
		$table7 = $this->company_id.'_itemrepbat_'.$this->session->get('ses_comp_fy_id');
		$table8 = $this->company_id.'_buffercalc_'.$this->session->get('ses_comp_fy_id');
        $table9 = $this->company_id.'_buffrevlog_'.$this->session->get('ses_comp_fy_id');
        
  	  
		$this->db->table($table1)->where('method_id',$method_id)->delete();
		$this->db->table($table2)->where('method_id',$method_id)->delete();
		$this->db->table($table3)->where('method_id',$method_id)->delete();
		$this->db->table($table4)->where('method_id',$method_id)->delete();
		$this->db->table($table5)->where('method_id',$method_id)->delete();
		$this->db->table($table6)->where('method_id',$method_id)->delete();
		$this->db->table($table6)->where('method_id',$method_id)->where('voucher_txn_id >',0)->delete();
		
		$this->db->table($table7)->where('method_id',$method_id)->delete();		
        $this->db->table($table8)->where('method_id',$method_id)->delete();
        $this->db->table($table9)->where('method_id',$method_id)->delete();
        $itemtxnvaln_tbl  = $this->company_id.'_itemtxnval_'.$item_id.'_'.$this->session->get('ses_comp_fy_id');
		$this->db->table($itemtxnvaln_tbl)->where('item_id',$item_id)->where('method_id',$method_id)->delete();
		 
   }
   public function calculating_item_valuations($voucher_txn_id,$item_id,$method_id,$from_date,$to_date){
	  
	    $itemrepall_tbl   = $this->company_id.'_itemrepall_'.$this->session->get('ses_comp_fy_id');	
		$itemrepmcn_tbl   = $this->company_id.'_itemrepmcn_'.$this->session->get('ses_comp_fy_id');	
		$itemrepgrp_tbl   = $this->company_id.'_itemrepgrp_'.$this->session->get('ses_comp_fy_id');	
		$itemrepcat_tbl   = $this->company_id.'_itemrepcat_'.$this->session->get('ses_comp_fy_id');	
		$itemrepprj_tbl   = $this->company_id.'_itemrepprj_'.$this->session->get('ses_comp_fy_id');	
		$itemrepbon_tbl   = $this->company_id.'_itemrepbon_'.$this->session->get('ses_comp_fy_id');	
		$itemrepbat_tbl   = $this->company_id.'_itemrepbat_'.$this->session->get('ses_comp_fy_id');	
		
		
	    $item_info        = $this->TransactionModel->get_item_info($item_id); 
	    $item_default_method = $item_info['valmethod_id'];
			 
		      
	   $item_txn_tbl = $this->company_id.'_itemtxnnnn_'.$item_id.'_'.$this->session->get('ses_comp_fy_id');
	   $builder = $this->db->table($item_txn_tbl); 
	   $builder->where('item_id', $item_id);
	   $builder->where('voucher_txn_id', $voucher_txn_id);
	   $builder->where('item_txn_date >=', $from_date);
	   $builder->where('item_txn_date <=', $to_date);
	   $builder->where('bo_id', $this->bo_id);
	   $builder->orderBy('item_txn_date', 'asc');
	   $builder->orderBy('voucher_txn_id', 'asc');
	   $builder->orderBy('item_txn_id', 'asc');
	   $result = $builder->get()->getResultArray();	
		//$df = $this->db->getlastquery();
       //  SaveErrorLog($df);	   
	   if($result){
		   
		 foreach($result as $row){
			 $item_unit    = $row['item_unit'];
			 $mat_cent_id  = $row['mat_cent_id'];
			 $batch_id     = $row['batch_id'];
			 $item_txn_id  = $row['item_txn_id']; 
			  
			 
			 
			 $bal = $this->TransactionModel->get_item_op_bal($item_id,$item_unit,$mat_cent_id,$batch_id);
			 if($method_id==0){
				if($item_default_method==1)				
				 $this->TransactionModel->calculate_valuation_avg($item_id, $item_unit, $mat_cent_id, $batch_id,$bal,1,1,$voucher_txn_id,$item_txn_id);
			    else if($item_default_method==2)				
				 $this->TransactionModel->calculate_valuation_fifo($item_id, $item_unit, $mat_cent_id, $batch_id,$bal,2,2,$voucher_txn_id,$item_txn_id);
			    else if($item_default_method==3)				
				 $this->TransactionModel->calculate_valuation_lifo($item_id, $item_unit, $mat_cent_id, $batch_id,$bal,3,2,$voucher_txn_id,$item_txn_id);
			
			
			}
		 else if($method_id==1){
				$this->TransactionModel->calculate_valuation_avg($item_id, $item_unit, $mat_cent_id, $batch_id,$bal,1,1,$voucher_txn_id,$item_txn_id);
			}  
		else	 if($method_id==2){
				$this->TransactionModel->calculate_valuation_fifo($item_id, $item_unit, $mat_cent_id, $batch_id,$bal,2,1,$voucher_txn_id,$item_txn_id,0);
			} 
		else	 if($method_id==3){				
				$this->TransactionModel->calculate_valuation_lifo($item_id, $item_unit, $mat_cent_id, $batch_id,$bal,3,1,$voucher_txn_id,$item_txn_id);
			}
			
		  }  
	    }else{
			// SaveErrorLog("else part".$item_id.'---update_item_balances_only');
			$this->TransactionModel->update_item_balances_only($item_id);
		}	
		 
   }
   
   public function calculating_item_default_valuations($voucher_txn_id,$item_id,$item_default_val_method,$item_info){
	   
	    $voucherconsinfo = $this->TransactionModel->get_voucherconsinfo($voucher_txn_id);
	    // first check item default valuation method has valuation or not , if not then stop and show error
	   $itemrepbon_tbl  = $this->company_id.'_itemrepbon_'.$this->session->get('ses_comp_fy_id');	
	 
	   $itemtxnvaln_tbl  = $this->company_id.'_itemtxnval_'.$item_id.'_'.$this->session->get('ses_comp_fy_id');
  	   	  
	   $item_txn_tbl = $this->company_id.'_itemtxnnnn_'.$item_id.'_'.$this->session->get('ses_comp_fy_id');
	   $builder = $this->db->table($item_txn_tbl); 
	   $builder->where('item_id', $item_id);
	   $builder->where('voucher_txn_id', $voucher_txn_id);
	   $builder->where('bo_id', $this->bo_id);
	   $builder->orderBy('item_txn_date', 'asc');
	   $builder->orderBy('voucher_txn_id', 'asc');
	   $builder->orderBy('item_txn_id', 'asc');
	   $result = $builder->get()->getResultArray();
	   $status = 1;
	   if($result){
		 foreach($result as $row){			     
			 $item_unit       = $row['item_unit'];
			 $mat_cent_id     = $row['mat_cent_id'];
			 $batch_id        = $row['batch_id'];
			 $item_txn_id     = $row['item_txn_id'];
			 $voucher_txn_id  = $row['voucher_txn_id'];
			 $item_txn_qty    = $row['item_txn_qty'];	
			 
			 $bal = $this->TransactionModel->get_item_op_bal($item_id,$item_unit,$mat_cent_id,$batch_id);
			if($item_default_val_method==1){
				$this->TransactionModel->calculate_valuation_avg($item_id, $item_unit, $mat_cent_id, $batch_id,$bal,1,2,$voucher_txn_id,$item_txn_id);
			}  
			else if($item_default_val_method==2){
				$this->TransactionModel->calculate_valuation_fifo($item_id, $item_unit, $mat_cent_id, $batch_id,$bal,2,2,$voucher_txn_id,$item_txn_id);
			} 
			else if($item_default_val_method==3){				
				$this->TransactionModel->calculate_valuation_lifo($item_id, $item_unit, $mat_cent_id, $batch_id,$bal,3,2,$voucher_txn_id,$item_txn_id);
			}
			    $status=1;
		    } 
		if($status==1)
		return array('status'=>1,'voucher_txn_id'=>$voucher_txn_id,"item_id"=>$item_id,'name'=>$item_info['item_name']);		
	    else 
		return array('status'=>0,'voucher_txn_id'=>$voucher_txn_id,"item_id"=>$item_id,'name'=>$item_info['item_name']);		
	    }	
    }
	
   
   public function check_banking_vouchers($voucher_type_id)
   {
   	    $voucher_tbl = $this->company_id.'_vhtxnconso_'.$this->session->get('ses_comp_fy_id');
      	$builder     = $this->db->table($voucher_tbl); 
		$builder->where('voucher_type_id', $voucher_type_id);
		$builder->where('bo_id', $this->bo_id);
		$result = $builder->get()->getResultArray();
		$errors = [];
		foreach ($result as $key => $value) 
		{
			$status = 1;
			$flag = 0;

			try{
				$comp_txn_tbl = $this->company_id.'_comptxnmst_'.$this->session->get('ses_comp_fy_id');
				$builder = $this->db->table($comp_txn_tbl); 
				$builder->where('voucher_txn_id', $value['voucher_txn_id']);
				$builder->whereIn('master_id_type', ['acc','bsd','aco','bso']);
				$result2 = $builder->get()->getResultArray();

				$credit_total = 0;
				$debit_total = 0;
				
				foreach ($result2 as $key2 => $value2) {

					if($value2['master_id_type'] == 'acc')
					{
						$acc_txn_tbl = $this->company_id.'_accnttxnnn_'.$value2['master_id'].'_'.$this->session->get('ses_comp_fy_id');
						if ($this->db->tableExists($acc_txn_tbl)) {
						$builder = $this->db->table($acc_txn_tbl); 
						$builder->where('txn_id', $value2['txn_id']);
						$acc_txn = $builder->get()->getRowArray();
						if($acc_txn){
							if($acc_txn['acc_txn_drcr'] == 'c')
								$credit_total += parseAmount($acc_txn['acc_txn_amount']);
							else
								$debit_total += parseAmount($acc_txn['acc_txn_amount']);
						}
						else{
							$status = 0;
							$flag = 2;
						}
					}
					}
					
					if($value2['master_id_type'] == 'aco')
					{
						$table = $this->company_id.'_accttxnoth_'.$this->session->get('ses_comp_fy_id');
						if ($this->db->tableExists($table)) {
						$builder = $this->db->table($table);
		    			$builder->where('txn_id', $value2['txn_id']);
						$account = $builder->get()->getRowArray();
						if($account){
							if($account['acc_oth_txn_drcr'] == 'c')
							  $credit_total += parseAmount($account['acc_oth_txn_amount']);
							else
							  $debit_total += parseAmount($account['acc_oth_txn_amount']);
						}
						else{
								$status = 0;
								$flag = 3;
							}
					   }
					}

					if($value2['master_id_type'] == 'bsd')
					{
						$bsd_txn_tbl = $this->company_id.'_sundrytxnn_'.$value2['master_id'].'_'.$this->session->get('ses_comp_fy_id');
						if ($this->db->tableExists($bsd_txn_tbl)) {
						$builder = $this->db->table($bsd_txn_tbl); 
						$builder->where('txn_id', $value2['txn_id']);
						$acc_txn = $builder->get()->getRowArray();
						if($acc_txn){
							if($acc_txn['sundry_txn_drcr'] == 'c')
								$credit_total += parseAmount($acc_txn['sundry_txn_amount']);
							else
								$debit_total += parseAmount($acc_txn['sundry_txn_amount']);
						}
						else{
							$status = 0;
							$flag = 4;
						}
					}
					}
					if($value2['master_id_type'] == 'bso')
					{
						  $table = $this->company_id.'_accttxnoth_'.$this->session->get('ses_comp_fy_id');
                          if ($this->db->tableExists($table)) {						 
						  $builder = $this->db->table($table);
						  $builder->where('txn_id', $value2['txn_id']);
						  $account = $builder->get()->getRowArray();
						  if($account){
							 if($account['acc_oth_txn_drcr'] == 'c')
								  $credit_total += parseAmount($account['acc_oth_txn_amount']);
								else
								  $debit_total += parseAmount($account['acc_oth_txn_amount']);
								}
								else{
									$status = 0;
									$flag = 5;
								}
						  }
					}
				}
                 // check if diff is 0.01 then no error  otherthan show erro if greater than 0.01 paisa
                $ttdiff = abs(parseAmount($credit_total)-parseAmount($debit_total));			 
				if((parseAmount($credit_total) != parseAmount($debit_total) ) && $ttdiff >0.01){
					$status = 0;
					$flag = 6;
				}
			}
			catch (\Exception $e) {
				$status = 0;
				$flag = 1;
			}

			if($status == 0){
				$errors[] = [
					'voucher_txn_id' => $value['voucher_txn_id'],
					'comp_vch_no' => $value['comp_vch_no'],
					'voucher_date' => date('d-m-Y', strtotime($value['voucher_date'])),
					'flag' => $flag,
					'credit_total' => $credit_total,
					'debit_total' => $debit_total,
				];
			}
			
		}
		return $errors;
   }

   public function check_single_voucher($voucher_txn_id)
   {
   	$status = 1;
   	$flag = 'flag 0';

   	$voucher_tbl = $this->company_id.'_vhtxnconso_'.$this->session->get('ses_comp_fy_id');
   	$builder = $this->db->table($voucher_tbl); 
		$builder->where('voucher_txn_id', $voucher_txn_id);
		$result = $builder->get()->getRowArray();

		if($result)
		{
			try{
				$comp_txn_tbl = $this->company_id.'_comptxnmst_'.$this->session->get('ses_comp_fy_id');
				$builder = $this->db->table($comp_txn_tbl); 
				$builder->where('voucher_txn_id', $result['voucher_txn_id']);
				$builder->whereIn('master_id_type', ['acc','bsd','aco','bso']);
				$result2 = $builder->get()->getResultArray();
				
				$debit_total = 0;
				$credit_total = 0;
				foreach ($result2 as $key2 => $value2) {

					if($value2['master_id_type'] == 'acc')
					{
						$acc_txn_tbl = $this->company_id.'_accnttxnnn_'.$value2['master_id'].'_'.$this->session->get('ses_comp_fy_id');
						$builder = $this->db->table($acc_txn_tbl); 
						$builder->where('txn_id', $value2['txn_id']);
						$acc_txn = $builder->get()->getRowArray();
						if($acc_txn){
							if($acc_txn['acc_txn_drcr'] == 'c')
								$credit_total += parseAmount($acc_txn['acc_txn_amount']);
							else
								$debit_total += parseAmount($acc_txn['acc_txn_amount']);
						}
						else{
							$status = 0;
							$flag = 'flag 1';
						}
					}
					
					if($value2['master_id_type'] == 'aco')
					{
						$table = $this->company_id.'_accttxnoth_'.$this->session->get('ses_comp_fy_id');
						$builder = $this->db->table($table);
		    			$builder->where('txn_id', $value2['txn_id']);
		            $account = $builder->get()->getRowArray();
		            if($account){
		              	if($account['acc_oth_txn_drcr'] == 'c')
		                  $credit_total += parseAmount($account['acc_oth_txn_amount']);
		              	else
		                  $debit_total += parseAmount($account['acc_oth_txn_amount']);
	              	}
	              	else{
							$status = 0;
							$flag = 'flag 2';
						}
					}

					if($value2['master_id_type'] == 'bsd')
					{
						$bsd_txn_tbl = $this->company_id.'_sundrytxnn_'.$value2['master_id'].'_'.$this->session->get('ses_comp_fy_id');
						$builder = $this->db->table($bsd_txn_tbl); 
						$builder->where('txn_id', $value2['txn_id']);
						$acc_txn = $builder->get()->getRowArray();
						if($acc_txn){
							if($acc_txn['sundry_txn_drcr'] == 'c')
								$credit_total += parseAmount($acc_txn['sundry_txn_amount']);
							else
								$debit_total += parseAmount($acc_txn['sundry_txn_amount']);
						}
						else{
							$status = 0;
							$flag = 'flag 3';
						}
					}
					if($value2['master_id_type'] == 'bso')
					{
						$table = $this->company_id.'_accttxnoth_'.$this->session->get('ses_comp_fy_id');
                  $builder = $this->db->table($table);
        				$builder->where('txn_id', $value2['txn_id']);
                  $account = $builder->get()->getRowArray();
                  if($account){
                     if($account['acc_oth_txn_drcr'] == 'c')
		                  $credit_total += parseAmount($account['acc_oth_txn_amount']);
		              	else
		                  $debit_total += parseAmount($account['acc_oth_txn_amount']);
						}
						else{
							$status = 0;
							$flag = 'flag 4';
						}
					}
				}

				if(parseAmount($credit_total) != parseAmount($debit_total)){
					$status = 0;
					$flag = 'flag 5';
				}
			}
			catch (\Exception $e) {
			  $status = 0;
			  $flag = 'flag 6';
			}
		}
		else{
			$status = 2; //Voucher Deleted
			$flag = 'flag 7';
		}

		
			
		return $status;
   }
   function get_master_db_details()
   {        $default_db_name ='aicountlyin_erp0000001'; 
	        $current_db_info = $this->db->query('SELECT DATABASE() as db')->getRowArray();		
		    $current_db      = $current_db_info['db'];
			$list = [];
			$columns=array();	
			$default_comp_code ='erp0000001';
			$external_db    = $this->externaldb->single_company_db($default_comp_code);
			$tables         = $external_db->query('SHOW TABLES')->getResultArray();
			foreach ($tables as $key => $value) {
				$table_name = array_values($value)[0];
				if(str_contains($table_name, '_accnttxnnn_')  || str_contains($table_name, '_itemtxnnnn_') || str_contains($table_name, '_itemtxnval_')  || str_contains($table_name, '_sundrytxnn_') ) { 
				}else{
				  if(substr_count($table_name, '_') <= 2){
					 $builder =$external_db->table('INFORMATION_SCHEMA.COLUMNS');
					 $builder->select('COLUMN_NAME,ORDINAL_POSITION,DATA_TYPE,COLUMN_TYPE');
					 $builder->where('TABLE_SCHEMA', $default_db_name);
					 $builder->where('TABLE_NAME', $table_name);
					 $query = $builder->get();
					 $results = $query->getResultArray();
					 	
					 if($results){
						foreach($results as $row){
						//$columns[obfuscate_link($table_name)][] = array('colname'=>obfuscate_link($row['COLUMN_NAME']),'col_type'=>obfuscate_link($row['DATA_TYPE']))	;
					 	$columns[$table_name][] = array('colname'=>$row['COLUMN_NAME'],'col_type'=>$row['DATA_TYPE'],'col_position'=>$row['ORDINAL_POSITION']);
					 	
						} 
					 }
					 
					 $list[] = obfuscate_link($table_name);
				   }
				}
			}
		// echo "<pre>";print_r(array_values($list));exit;
		return array("list"=>$list,"columns"=>$columns,"dbenc"=>obfuscate_link($current_db));
   }
   
   
   
   function array_diff_recursive($array1, $array2) {
    $result = [];
    
    foreach ($array1 as $key => $value) {
        // If the key is not in the second array, or the value is different, add it to the result
        if (!array_key_exists($key, $array2)) {
            $result[$key] = $value;
        } else {
            // If both arrays have the same key, check if it's an array or value
            if (is_array($value) && is_array($array2[$key])) {
                // If both are arrays, recursively compare them
                $recursive_diff = $this->array_diff_recursive($value, $array2[$key]);
                if ($recursive_diff) {
                    $result[$key] = $recursive_diff;
                }
            } elseif ($value !== $array2[$key]) {
                // If the value is different, add it to the result
                $result[$key] = $value;
            }
        }
    }
    
    return $result;
  }
  private function compareArrays(array $defaultCols, array $otherCols): array {
    $in_default_not_other = [];
    $differences = [];

    // Loop over default table structure
    foreach ($defaultCols as $index => $defaultCol) {
        $defaultName = $defaultCol['COLUMN_NAME'];

        // Try to find matching column by name in otherCols
        $match = array_filter($otherCols, function ($col) use ($defaultName) {
            return $col['COLUMN_NAME'] === $defaultName;
        });

        if (empty($match)) {
            // Column not found in otherCols
            $in_default_not_other[$index] = $defaultCol;
        } else {
            $otherCol = reset($match);

            // Compare column properties
            $diffFields = [];
            foreach (['COLUMN_NAME', 'COLUMN_TYPE', 'IS_PRIMARY_KEY', 'IS_AUTO_INCREMENT'] as $key) {
                if ($defaultCol[$key] !== $otherCol[$key]) {
                    $diffFields[$key] = [$defaultCol[$key], $otherCol[$key]];
                }
            }

            if (!empty($diffFields)) {
                $differences[] = [
                    'column' => $defaultName,
                    'differences' => $diffFields,
                    'array1' => $defaultCol,
                    'array2' => $otherCol,
                ];
            }
        }
    }

    return [
        'in_array1_not_in_array2' => $in_default_not_other,
        'differences' => $differences
    ];
}
private function logQuery($query, $context = '') {
    $logText = "[" . date('Y-m-d H:i:s') . "] $context\n$query\n\n";
    file_put_contents(APPPATH . 'logs/query_log.txt', $logText, FILE_APPEND);
}
  
  function compareArraysoldee($array1, $array2) {
    $differences = [
        'in_array1_not_in_array2' => [],
       // 'in_array2_not_in_array1' => [],
        'differences' => []
    ];

    // Index arrays by COLUMN_NAME for easy comparison
    $array1Index = array_column($array1, null, 'COLUMN_NAME');
    $array2Index = array_column($array2, null, 'COLUMN_NAME');

    // Compare arrays
    foreach ($array1Index as $columnName => $columnData) {
        if (!isset($array2Index[$columnName])) {
            $differences['in_array1_not_in_array2'][$columnData['ORDINAL_POSITION']-1] = $columnData;
        } else {
            $array2Data = $array2Index[$columnName];
            // Check for differences in attributes
            if ($columnData['COLUMN_TYPE'] !== $array2Data['COLUMN_TYPE'] || 
                $columnData['IS_PRIMARY_KEY'] !== $array2Data['IS_PRIMARY_KEY'] || 
				$columnData['IS_AUTO_INCREMENT'] !== $array2Data['IS_AUTO_INCREMENT']) {
                $differences['differences'][] = [
                    'column' => $columnName,
                    'array1' => $columnData,
                    'array2' => $array2Data
                ];
            }
        }
    }

   /*  // Find columns in array2 but not in array1
    foreach ($array2Index as $columnName => $columnData) {
        if (!isset($array1Index[$columnName])) {
            $differences['in_array2_not_in_array1'][] = $columnData;
        }
    }
 */
    return $differences;
}

function verify_table_details($default_table_name, $current_db_name, $default_db_name) {
    $default_comp_code = 'erp0000001';
    $external_db = $this->externaldb->single_company_db($default_comp_code);

    $table_info = explode("_", $default_table_name);
    $actual_tblname = isset($table_info[2]) && !is_numeric($table_info[2])
        ? strtolower($table_info[1]) . '_' . strtolower($table_info[2])
        : strtolower($table_info[1]);

    // Get default company table structure
    $default_comp_tables = $this->get_table_structure($external_db, $default_table_name, $default_db_name);

    // Get current company tables matching structure
    $results = $this->get_table_structure($this->db, "%_$actual_tblname%", $current_db_name, true);

    $other_comp_tables = [];
    foreach ($results as $row) {
        $other_comp_tables[$row['TABLE_NAME']][] = [
            'COLUMN_NAME'       => $row['COLUMN_NAME'],
            'ORDINAL_POSITION'  => $row['ORDINAL_POSITION'],
            'COLUMN_TYPE'       => $row['COLUMN_TYPE'],
            'IS_PRIMARY_KEY'    => $row['IS_PRIMARY_KEY'],
            'IS_AUTO_INCREMENT' => $row['IS_AUTO_INCREMENT'],
        ];
    }

    $columns_mismatch = [];
    foreach ($other_comp_tables as $table_name => $cols) {
        $columns_mismatch[$table_name] = $this->compareArrays($default_comp_tables, $cols);
    }

    $status = 1;
    $errors = [];
    $queries_run = [];

    try {
        foreach ($columns_mismatch as $table => $column_diff) {
            // Add missing columns
            foreach ($column_diff['in_array1_not_in_array2'] ?? [] as $idx => $col) {
                if (!isset($other_comp_tables[$table][$idx])) {
                    $col_name = $default_comp_tables[$idx]['COLUMN_NAME'];
                    $col_type = strtoupper($default_comp_tables[$idx]['COLUMN_TYPE']);
                    $sql = "ALTER TABLE `$table` ADD COLUMN `$col_name` $col_type DEFAULT NULL;";
                    $this->db->query($sql);
                    SaveErrorLog("$table<br>$sql");
                    $queries_run[] = $sql;
                }
            }

            // Rename mismatched columns
            foreach ($column_diff['in_array1_not_in_array2'] ?? [] as $idx => $col) {
                if (isset($other_comp_tables[$table][$idx]) &&
                    $default_comp_tables[$idx]['COLUMN_NAME'] != $other_comp_tables[$table][$idx]['COLUMN_NAME']) {
                    $old_name = $other_comp_tables[$table][$idx]['COLUMN_NAME'];
                    $new_name = $default_comp_tables[$idx]['COLUMN_NAME'];
                    $col_type = strtoupper($default_comp_tables[$idx]['COLUMN_TYPE']);
                    $sql = "ALTER TABLE `$table` CHANGE `$old_name` `$new_name` $col_type DEFAULT NULL;";
                    $this->db->query($sql);
                    SaveErrorLog("$table<br>$sql");
                    $queries_run[] = $sql;
                }
            }

            // Handle primary key / auto-increment differences
            foreach ($column_diff['differences'] ?? [] as $diff) {
                $col_name = $diff['column'];
                $type = strtoupper($diff['array1']['COLUMN_TYPE']);

                if ($diff['array1']['IS_PRIMARY_KEY'] == 'PRIMARY KEY' && $diff['array2']['IS_PRIMARY_KEY'] == 'NO') {
                   try {
  				     $sql = "ALTER TABLE `$table` MODIFY COLUMN `$col_name` $type AUTO_INCREMENT PRIMARY KEY;";
                    $this->db->query($sql);
                    SaveErrorLog("$table<br>$sql");
                    $queries_run[] = $sql;
				   }catch (\Throwable $e) {
            SaveErrorLog("AUTO_INCREMENT error in `$table`: " . $e->getMessage());
        }
                }

                if ($diff['array1']['IS_AUTO_INCREMENT'] == 'YES' && $diff['array2']['IS_AUTO_INCREMENT'] == 'NO') {
                   try {
				    $sql = "ALTER TABLE `$table` MODIFY COLUMN `$col_name` $type AUTO_INCREMENT;";
                    $this->db->query($sql);
					$status = 1;
					$queries_run[] = $sql;
					  SaveErrorLog("$table<br>$sql");
				   }
				   catch (\Throwable $e) {
            SaveErrorLog("AUTO_INCREMENT error in `$table`: " . $e->getMessage());
        }
                   
                }

                if ($diff['array1']['IS_PRIMARY_KEY'] == 'NO' && $diff['array2']['IS_PRIMARY_KEY'] == 'PRIMARY KEY') {
					try {
				   $sql = "ALTER TABLE `$table` DROP PRIMARY KEY;";
                    $this->db->query($sql);
                    SaveErrorLog("$table<br>$sql");
                    $queries_run[] = $sql;
					}
				   catch (\Throwable $e) {
            SaveErrorLog("AUTO_INCREMENT error in `$table`: " . $e->getMessage());
        }
                }
            }
        }
    } catch (\Exception $e) {
        $errors[] = $e->getMessage();
        $status = 0;
    }

    return [
        'status' => $status,
        'message' => $errors,
        'queries' => $queries_run
    ];
}

private function get_table_structure($db, $table, $schema, $like = false) {
    $operator = $like ? 'LIKE' : '=';
    $sql = "SELECT c.TABLE_NAME, c.COLUMN_NAME, c.ORDINAL_POSITION, c.COLUMN_TYPE, 
                   IF(k.COLUMN_NAME IS NOT NULL, 'PRIMARY KEY', 'NO') AS IS_PRIMARY_KEY,
                   IF(c.EXTRA LIKE '%auto_increment%', 'YES', 'NO') AS IS_AUTO_INCREMENT
            FROM INFORMATION_SCHEMA.COLUMNS c
            LEFT JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE k
              ON c.TABLE_SCHEMA = k.TABLE_SCHEMA
             AND c.TABLE_NAME = k.TABLE_NAME
             AND c.COLUMN_NAME = k.COLUMN_NAME
             AND k.CONSTRAINT_NAME = 'PRIMARY'
            WHERE c.TABLE_SCHEMA = ?
              AND c.TABLE_NAME $operator ?
            ORDER BY c.ORDINAL_POSITION";
    return $db->query($sql, [$schema, $table])->getResultArray();
}

  function verify_table_details_oldee($default_table_name,$current_db_name,$default_db_name){
	 $default_comp_code ='erp0000001';
	 $external_db       = $this->externaldb->single_company_db($default_comp_code);
			
	 $table_name_info   = explode("_",$default_table_name);
	 if(isset($table_name_info[2]) && is_numeric($table_name_info[2])) 	
 	    $actual_tblname = strtolower($table_name_info[1]);
	 elseif(isset($table_name_info[2]) && !is_numeric($table_name_info[2])) 
	   $actual_tblname = strtolower($table_name_info[1]).'_'.strtolower($table_name_info[2]);	
	 else					
	    $actual_tblname = strtolower($table_name_info[1]);
	
	
	     $sql = "SELECT c.TABLE_NAME,c.COLUMN_NAME,c.ORDINAL_POSITION,c.COLUMN_TYPE, 
                IF(k.COLUMN_NAME IS NOT NULL, 'PRIMARY KEY', 'NO') AS IS_PRIMARY_KEY,
				IF(c.EXTRA LIKE '%auto_increment%', 'YES', 'NO') AS IS_AUTO_INCREMENT
			    FROM INFORMATION_SCHEMA.COLUMNS c
		  	    LEFT JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE k
				ON c.TABLE_SCHEMA = k.TABLE_SCHEMA
				AND c.TABLE_NAME = k.TABLE_NAME
				AND c.COLUMN_NAME = k.COLUMN_NAME
				AND k.CONSTRAINT_NAME = 'PRIMARY'
			    WHERE c.TABLE_SCHEMA = '$default_db_name'
			    AND c.TABLE_NAME ='".$default_table_name."'
				ORDER BY c.ORDINAL_POSITION;";
		$query = $external_db->query($sql);
		$default_comp_tables = $query->getResultArray();
		
		 
	    $sql = "SELECT c.TABLE_NAME,c.COLUMN_NAME,c.ORDINAL_POSITION,c.COLUMN_TYPE, 
                IF(k.COLUMN_NAME IS NOT NULL, 'PRIMARY KEY', 'NO') AS IS_PRIMARY_KEY,
				IF(c.EXTRA LIKE '%auto_increment%', 'YES', 'NO') AS IS_AUTO_INCREMENT
			    FROM INFORMATION_SCHEMA.COLUMNS c
		  	    LEFT JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE k
				ON c.TABLE_SCHEMA = k.TABLE_SCHEMA
				AND c.TABLE_NAME = k.TABLE_NAME
				AND c.COLUMN_NAME = k.COLUMN_NAME
				AND k.CONSTRAINT_NAME = 'PRIMARY'
			    WHERE c.TABLE_SCHEMA = '$current_db_name'
			    AND c.TABLE_NAME LIKE '%_".$actual_tblname."%'
				ORDER BY c.ORDINAL_POSITION;";
		$query   = $this->db->query($sql);
		$results = $query->getResultArray();
		$other_comp_tables=[];
		if($results){
			foreach($results as $rows){
				$other_comp_tables[$rows['TABLE_NAME']][]=array("COLUMN_NAME"=>$rows['COLUMN_NAME'],"ORDINAL_POSITION"=>$rows['ORDINAL_POSITION'],"COLUMN_TYPE"=>$rows['COLUMN_TYPE'],'IS_PRIMARY_KEY'=>$rows['IS_PRIMARY_KEY'],'IS_AUTO_INCREMENT'=>$rows['IS_AUTO_INCREMENT']);
			} 
		 }	
	
	
	
	$columns_in_table1_not_in_table2=array();
	if($other_comp_tables){
			foreach($other_comp_tables as $table_name => $table_cols){
			//echo '<pre>';
			//print_r($table_cols);
		
		  $columns_in_table1_not_in_table2[$table_name] = $this->compareArrays($default_comp_tables, $table_cols);
         
		  //$columns_in_table1_not_in_table2[$table_name] = $this->array_diff_recursive($default_comp_tables, $table_cols);
           //$columns_in_table2_not_in_table1[$default_table_name] = $this->array_diff_recursive($table_cols, $default_comp_tables);
		}
		
	}	
	 // echo '<pre>';
	//print_r($columns_in_table1_not_in_table2);
	
	
	//die(); 
	
	$errors=[];
	$status=1;	
	try{		
		$queryes=[];	
		if($columns_in_table1_not_in_table2){	
		    foreach($columns_in_table1_not_in_table2 as $tablename => $columns){
                if($tablename!='' && is_array($columns['in_array1_not_in_array2']) && count($columns['in_array1_not_in_array2']) >0){
				    
					foreach($columns['in_array1_not_in_array2'] as $position_id => $col_rows){	
					    		
					  if(isset($default_comp_tables[$position_id]['COLUMN_NAME']) && isset($default_comp_tables[$position_id]['ORDINAL_POSITION'])){				
							//$other_comp_db_colname = $default_comp_tables[$position_id]['COLUMN_NAME'];
					       // $other_comp_db_colpos  = $default_comp_tables[$position_id]['ORDINAL_POSITION'];
					 
					 
							if(!isset($other_comp_tables[$tablename][$position_id])){
							 $column_name = $default_comp_tables[$position_id]['COLUMN_NAME'];
							 $column_type = strtoupper($default_comp_tables[$position_id]['COLUMN_TYPE']);
							try{
							 // Add New Column at the last in current company db	
						 	$queryes ="ALTER TABLE `".$tablename."` ADD COLUMN `".$column_name."` ".$column_type." DEFAULT NULL;";
						   //echo '<br>';
							$this->db->query($queryes);     	    	 
							SaveErrorLog($tablename.'<br>'.$queryes);
							$status=1; 
							}catch (\Exception $e) {}							
							}
							else if($default_comp_tables[$position_id]['COLUMN_NAME']!=$other_comp_tables[$tablename][$position_id]['COLUMN_NAME']){
							$new_column_name = $default_comp_tables[$position_id]['COLUMN_NAME'];
							$old_column_name = $other_comp_tables[$tablename][$position_id]['COLUMN_NAME'];
							$column_type     = strtoupper($default_comp_tables[$position_id]['COLUMN_TYPE']);
							try{
							 $queryes="ALTER TABLE `".$tablename."` CHANGE `".$old_column_name."` `".$new_column_name."` ".$column_type." DEFAULT NULL;";
							//echo '<br>';
							SaveErrorLog($tablename.'<br>'.$queryes);
							$this->db->query($queryes);     	    	 
							$status=1;   
							}catch (\Exception $e) {}
					    }					   
				    }
			    } 
				
				
			   }
			   
			   if(isset($columns['differences']) && count($columns['differences']) >0){
						//check primary keys exists or not 
						
						foreach($columns['differences'] as $differencesid => $diff_rows){	
						   $column_name               = $diff_rows['column'];
						   $is_primary_set            = $diff_rows['array1']['IS_PRIMARY_KEY'];// PRIMARY KEY						    
						   $primary_exts_othertbl     = $diff_rows['array2']['IS_PRIMARY_KEY'];// PRIMARY KEY						   
						  
						   $is_autoincrmnt_set        = $diff_rows['array1']['IS_AUTO_INCREMENT'];// IS_AUTO_INCREMENT
						   $autoincrmnt_exts_othertbl = $diff_rows['array2']['IS_AUTO_INCREMENT'];// IS_AUTO_INCREMENT
						  
						   $column_type               = strtoupper($diff_rows['array1']['COLUMN_TYPE']);
						   if($primary_exts_othertbl=='NO' && $is_primary_set=='PRIMARY KEY'){							 
							   try{
								$queryes ="ALTER TABLE `".$tablename."` MODIFY COLUMN `".$column_name."` ".$column_type." AUTO_INCREMENT PRIMARY KEY;";   
								$this->db->query($queryes);
								SaveErrorLog($tablename.'<br>'.$queryes);
							    $status=1;    
							   }
							   catch (\Exception $e) {
								   SaveErrorLog($tablename.'<br>'.$e->getMessage());
							   }
						   }
						   if($autoincrmnt_exts_othertbl=='NO' && $is_autoincrmnt_set=='YES'){
							 
							   try{
								$queryes ="ALTER TABLE `".$tablename."` MODIFY COLUMN `".$column_name."` ".$column_type." AUTO_INCREMENT;";   
								$this->db->query($queryes);
								SaveErrorLog($tablename.'<br>'.$queryes);
							    $status=1;    
							   }
							   catch (\Exception $e) {
								   
								 SaveErrorLog($tablename.'<br>'.$e->getMessage());  
							   }
						   }
						   if($primary_exts_othertbl=='PRIMARY KEY' && $is_primary_set=='NO'){
							 
							   try{
								$queryes ="ALTER TABLE `".$tablename."` DROP PRIMARY KEY;"; 
								 $this->db->query($queryes);								
								SaveErrorLog($tablename.'<br>'.$queryes);
							    $status=1;    
							   }
							   catch (\Exception $e) {
								   SaveErrorLog($e->getMessage());
								   
							   }
						   }
						}
					}
			   
			   
			   
			   
			   
		  }
		}	
	
	}
	catch (\Exception $e) {			
			$errors[] = $e->getMessage();
		    $status=0;
	} 
	
   $response_result = array('status'=>$status,'message'=>$errors,'queryes'=>$queryes);	
   return $response_result;	
  }
 
  function verify_table_details_without_primarykey($default_table_name,$current_db_name,$default_db_name){
	 $default_comp_code ='erp0000001';
	 $external_db       = $this->externaldb->single_company_db($default_comp_code);
			
	 $table_name_info   = explode("_",$default_table_name);
	 if(isset($table_name_info[2]) && is_numeric($table_name_info[2])) 	
 	    $actual_tblname = strtolower($table_name_info[1]);
	 elseif(isset($table_name_info[2]) && !is_numeric($table_name_info[2])) 
	   $actual_tblname = strtolower($table_name_info[1]).'_'.strtolower($table_name_info[2]);	
	 else					
	    $actual_tblname = strtolower($table_name_info[1]);
	    $sql = "SELECT COLUMN_NAME,ORDINAL_POSITION,COLUMN_TYPE
						 FROM INFORMATION_SCHEMA.COLUMNS
						 WHERE TABLE_SCHEMA = '$default_db_name' AND TABLE_NAME LIKE '%_".$actual_tblname."%'";
		$query = $external_db->query($sql);
		$default_comp_tables = $query->getResultArray();
		
	    $sql = "SELECT TABLE_NAME,COLUMN_NAME,ORDINAL_POSITION,COLUMN_TYPE
						 FROM INFORMATION_SCHEMA.COLUMNS
						 WHERE TABLE_SCHEMA = '$current_db_name' AND TABLE_NAME LIKE '%_".$actual_tblname."%'";
		$query   = $this->db->query($sql);
		$results = $query->getResultArray();
		$other_comp_tables=[];
		if($results){
			foreach($results as $rows){
				$other_comp_tables[$rows['TABLE_NAME']][]=array("COLUMN_NAME"=>$rows['COLUMN_NAME'],"ORDINAL_POSITION"=>$rows['ORDINAL_POSITION'],"COLUMN_TYPE"=>$rows['COLUMN_TYPE']);
			} 
		 }	
	
	
	if($other_comp_tables){
		foreach($other_comp_tables as $table_name => $table_cols){
		   $columns_in_table1_not_in_table2[$table_name] = $this->array_diff_recursive($default_comp_tables, $table_cols);
           //$columns_in_table2_not_in_table1[$default_table_name] = $this->array_diff_recursive($table_cols, $default_comp_tables);
		}
		
	}
	$errors=[];
	$status=1;	
	try{		
		$queryes=[];	
		if($columns_in_table1_not_in_table2){	
		    foreach($columns_in_table1_not_in_table2 as $tablename => $columns){
                if($tablename!='' && is_array($columns) && count($columns) >0){
				    foreach($columns as $position_id => $col_rows){	
					    		
					  if(isset($default_comp_tables[$position_id]['COLUMN_NAME']) && isset($default_comp_tables[$position_id]['ORDINAL_POSITION'])){				
							$other_comp_db_colname = $default_comp_tables[$position_id]['COLUMN_NAME'];
					        $other_comp_db_colpos  = $default_comp_tables[$position_id]['ORDINAL_POSITION'];
					  
							if(!isset($other_comp_tables[$tablename][$position_id])){
							 $column_name = $default_comp_tables[$position_id]['COLUMN_NAME'];
							 $column_type = strtoupper($default_comp_tables[$position_id]['COLUMN_TYPE']);
							try{
							 // Add New Column at the last in current company db	
							$queryes ="ALTER TABLE `".$tablename."` ADD COLUMN `".$column_name."` ".$column_type." DEFAULT NULL;";
							$this->db->query("ALTER TABLE `".$tablename."` ADD COLUMN `".$column_name."` ".$column_type." DEFAULT NULL;");     	    	 
							SaveErrorLog($queryes);
							$status=1; 
							}catch (\Exception $e) {}							
							}
							else if($default_comp_tables[$position_id]['COLUMN_NAME']!=$other_comp_tables[$tablename][$position_id]['COLUMN_NAME']){
							$new_column_name = $default_comp_tables[$position_id]['COLUMN_NAME'];
							$old_column_name = $other_comp_tables[$tablename][$position_id]['COLUMN_NAME'];
							$column_type     = strtoupper($default_comp_tables[$position_id]['COLUMN_TYPE']);
							try{
							$queryes="ALTER TABLE `".$tablename."` CHANGE `".$old_column_name."` `".$new_column_name."` ".$column_type." DEFAULT NULL;";
							SaveErrorLog($queryes);
							$this->db->query("ALTER TABLE `".$tablename."` CHANGE `".$old_column_name."` `".$new_column_name."` ".$column_type." DEFAULT NULL;");     	    	 
							$status=1;   
							}catch (\Exception $e) {}
					    }					   
				    }
			    } 
			}
		  }
		}	
	
	}
	catch (\Exception $e) {			
			$errors[] = $e->getMessage();
		    $status=0;
	}  
	
   $response_result = array('status'=>$status,'message'=>$errors,'queryes'=>$queryes);	
   return $response_result;	
  }
   
   
   
   function verify_table_details11($default_table_name,$current_db_name,$default_db_name,$columns_info){
	  $table_name_info  = explode("_",$default_table_name);
	  $response_array   = array();
	  if(isset($table_name_info[0]) && isset($table_name_info[2])){
		  $actual_tblname = strtolower($table_name_info[1]);
		  
		$list = [];
		$create_tables=[];
		$tables_diff=[];
		$db_tables_list=[];
	    $tables = $this->db->query("SHOW TABLES LIKE '%%'")->getResultArray();
	    foreach ($tables as $key => $value) {
				$table_name = array_values($value)[0];
				if(str_contains($table_name, '_accnttxnnn_') || str_contains($table_name, '_acctmaster_') || str_contains($table_name, '_itemtxnnnn_') || str_contains($table_name, '_itemtxnval_') || str_contains($table_name, '_itemmaster_') || str_contains($table_name, '_sundrytxnn_') || str_contains($table_name, '_billsundry_')) { 
				}else{
				  if(substr_count($table_name, '_') <= 2){
					  $db_table_name_info = explode("_",$table_name);
                      if(isset($db_table_name_info[2]) && is_numeric($db_table_name_info[2])) 	
 					   $db_tblname = strtolower($db_table_name_info[1]);
					  elseif(isset($db_table_name_info[2]) && !is_numeric($db_table_name_info[2])) 
						 $db_tblname = strtolower($db_table_name_info[1]).'_'.strtolower($db_table_name_info[2]);	
						else					
					    $db_tblname = strtolower($db_table_name_info[1]);
					
					
					
					  $db_tables_list[$table_name]=$db_tblname;					  
				   }
				}
			}			
		
		if(!in_array(strtolower($actual_tblname),$db_tables_list)){
			$create_tables[]=$default_table_name;
		}
		if(in_array(strtolower($actual_tblname),$db_tables_list)){
            $other_table = array_search ($actual_tblname, $db_tables_list);					
			 $sQuery = "SELECT column_name,ordinal_position,data_type,column_type FROM
						(   SELECT column_name,ordinal_position,data_type,column_type,COUNT(1) rowcount
							FROM information_schema.columns
							WHERE
							(
								(table_schema='$default_db_name' AND table_name='$default_table_name') OR
								(table_schema='$current_db_name' AND table_name='$other_table')
							)
							AND table_name IN ('$default_table_name','$other_table')
							GROUP BY column_name,ordinal_position,data_type,column_type HAVING COUNT(1)=1
						) A; ";
								
		    $response = $this->db->query($sQuery);
			$res_array = $response->getResultArray();
			echo '<pre>';
			print_r($res_array);
			echo $this->db->getlastquery();
			/* $columnsarr = array();		
			if($response){				
				foreach($response as $rows){					
					$columnsarr = array("column_name"=>$rows['column_name'],"data_type"=>$rows['data_type']);
				    $tables_diff[$default_table_name][]=$columnsarr;
				  }
			   }
			else
			 $tables_diff[$default_table_name][]=''; */	
		 // $response_array = array('tablename'=>$default_table_name,"tables_diff"=>json_encode($response),"create_tables"=>$create_tables);			 
	  
		}	
		
	  }else
		  $response_array = array('tablename'=>$default_table_name,"tables_diff"=>[],"create_tables"=>[]);			 
	  
	  
	  
	  return $response_array;
	   
   }

   

	public function get_bbb_accounts($group_array){
	     
	   $account_master_tbl = $this->company_id.'_acctmaster_'.$this->session->get('ses_comp_fy_id');
	   $builder = $this->db->table($account_master_tbl); 
		$builder->select('acc_id as id, acc_name as name');
		$builder->whereIn('acc_grp_id', $group_array);
		$result = $builder->get()->getResultArray();
		
		return $result;
   }

   public function get_bbb_vouchers($account_id)
   {
   	$voucher_tbl = $this->company_id.'_vhtxnconso_'.$this->session->get('ses_comp_fy_id');
		$voucher_type_tbl = $this->company_id.'_cmpvchtype_'.$this->session->get('ses_comp_fy_id');
		$comp_txn_tbl = $this->company_id.'_comptxnmst_'.$this->session->get('ses_comp_fy_id');

	    
		$builder = $this->db->table($voucher_tbl);
		$builder->select($voucher_tbl.'.voucher_txn_id as id, CONCAT(comp_vch_type, " Voucher No. ", comp_vch_no) AS name, '.$voucher_tbl.'.voucher_type_id, DATE_FORMAT(voucher_date, "%d-%m-%Y") as voucher_date');
		$builder->join($voucher_type_tbl, $voucher_type_tbl.'.voucher_type_id ='.$voucher_tbl.'.voucher_type_id');
		$builder->join($comp_txn_tbl, $comp_txn_tbl.'.voucher_txn_id  ='.$voucher_tbl.'.voucher_txn_id');
		$builder->where($voucher_tbl.'.comp_id', $this->company_id);
		$builder->where('master_id', $account_id);
		$builder->where('master_id_type', "acc");
		$builder->orderBy('voucher_date');
		$builder->orderBy($voucher_tbl.'.voucher_txn_id');

		$list = $builder->get()->getResultArray();

		return $list;
   }

   public function verify_bbb_vouchers($account_id, $voucher_txn_id)
   {
   	$balance = 0;

   	$voucher_tbl = $this->company_id.'_vhtxnconso_'.$this->session->get('ses_comp_fy_id');
   	$builder = $this->db->table($voucher_tbl); 
		$builder->where('voucher_txn_id', $voucher_txn_id);
		$exists = $builder->get()->getRowArray();

		if(!$exists)
			return 2;

   	$acc_txn_tbl = $this->company_id.'_accnttxnnn_'.$account_id.'_'.$this->session->get('ses_comp_fy_id');
   	$builder = $this->db->table($acc_txn_tbl);
   	$builder->select('*');
   	$builder->where('acc_id', $account_id);
   	$builder->where('voucher_txn_id', $voucher_txn_id);
   	$result = $builder->get()->getResultArray();

   	foreach ($result as $key => $value) {
   		if($value['acc_txn_drcr'] == 'c')
   			$balance += -parseAmount($value['acc_txn_amount']);
   		if($value['acc_txn_drcr'] == 'd')
   			$balance += parseAmount($value['acc_txn_amount']);
   	}

   	$balance2 = 0;
   	$bill_txn_tbl = $this->company_id.'_billstxnnn_'.$this->session->get('ses_comp_fy_id');
   	$builder = $this->db->table($bill_txn_tbl);
   	$builder->select('*');
   	$builder->where('acc_id', $account_id);
   	$builder->where('voucher_txn_id', $voucher_txn_id);
   	$result2 = $builder->get()->getResultArray();

   	foreach ($result2 as $key2 => $value2) {
   		if($value2['bills_txn_drcr'] == 'C')
   			$balance2 += -parseAmount($value2['bills_txn_amt']);
   		if($value2['bills_txn_drcr'] == 'D')
   			$balance2 += parseAmount($value2['bills_txn_amt']);
   	}

   	if($balance != $balance2)
   		return 0;

   	return 1;
   }

   public function get_sub_group_ids($array){
    	
    	if(!empty($array)){

    		$tbl_name = $this->company_id.'_acctgroupn_'.$this->session->get('ses_comp_fy_id');
    		$data = $this->db->table($tbl_name)
    					->select('acc_grp_id')
    					->whereIn('under_main_grp_id', $array)
    					->get()->getResultArray();
    	
    	
	    	if($data){
	    		foreach($data as $key => $value) {
	    			array_push($array, $value['acc_grp_id']);
	    		}
	    	}
    	}
    	return $array;
   }

   public function get_bbb_groups()
   {
        
		$groups = [16,22];
		$array = $this->get_sub_group_ids($groups);
        
      return $array;
   }

   public function get_bbb_account()
   {
      $bbb_accounts = [];
		$bbb_groups = $this->get_bbb_groups();

		if($bbb_groups){

   		$acctmaster_tbl = $this->company_id.'_acctmaster_'.$this->session->get('ses_comp_fy_id');

			$result =  $this->db->table($acctmaster_tbl)
									  ->select('acc_id')
									  ->whereIn('acc_grp_id', $bbb_groups)
									  ->get()->getResultArray();

			$bbb_accounts = [];
			foreach ($result as $key => $value) {
				$bbb_accounts[] = $value['acc_id'];
			}

		}
        
      return $bbb_accounts;
   }


   public function update_bbb_opening_balance()
   {
   	$bbb_accounts = $this->get_bbb_account();

   	$accoppybal_tbl = $this->company_id.'_accoppybal_'.$this->session->get('ses_comp_fy_id');
   	$bill_mst_tbl = $this->company_id.'_billmaster_'.$this->session->get('ses_comp_fy_id');
   	$billsoppyn_tbl = $this->company_id.'_billsoppyn_'.$this->session->get('ses_comp_fy_id');

   	foreach ($bbb_accounts as $account_id) {
   		
   		$result = $this->db->table($accoppybal_tbl)
									  ->where('acc_id',$account_id)
									  ->where('bo_id',$this->bo_id)
									  ->get()->getRowArray();

			if($result){

				$acc_op_bal = floatval($result['acc_op_bal']);

				$result2 = $this->db->table($bill_mst_tbl)
								  	->where('acc_id', $account_id)
								  	->where('bo_id',$this->bo_id)
								  	->get()->getResultArray();

				$opening_balance = 0;				  	
				foreach ($result2 as $key2 => $value2) {
					$opening_balance += $this->TransactionModel->get_bills_op_bal($value2['bills_ref_id']);
				}

				$un_bills_ref_id = $this->TransactionModel->getUndefinedBillRefId($account_id);

				if($acc_op_bal >= $opening_balance){

					$diff = $acc_op_bal - $opening_balance;
					$billsoppyn = $this->db->table($billsoppyn_tbl)
								  	->where('bills_ref_id', $un_bills_ref_id)
								  	->get()->getRowArray();

					if($billsoppyn){
						$undefined_balance = $billsoppyn['bills_op_bal'] + $diff;

						$this->db->table($billsoppyn_tbl)
							  	->where('bills_ref_id', $un_bills_ref_id)
							  	->update(['bills_op_bal' => $undefined_balance]);
					}
					else{
						$op_data = [
							'bills_ref_id' 	=> $un_bills_ref_id,
							'bo_id' 				=> $this->bo_id,
							'bills_op_bal' 	=> $diff,
							'bills_py_bal' 	=> 0,
						];
						$this->db->table($billsoppyn_tbl)->insert($op_data);
					}
					
				}
				else{
					$billsoppyn = $this->db->table($billsoppyn_tbl)
								  	->where('bills_ref_id', $un_bills_ref_id)
								  	->get()->getRowArray();
					if($billsoppyn){
						$this->db->table($billsoppyn_tbl)
								  	->where('bills_ref_id', $un_bills_ref_id)
								  	->update(['bills_op_bal' => $acc_op_bal]);
					}
					else{
						$op_data = [
							'bills_ref_id' 	=> $un_bills_ref_id,
							'bo_id' 				=> $this->bo_id,
							'bills_op_bal' 	=> $acc_op_bal,
							'bills_py_bal' 	=> 0,
						];
						$this->db->table($billsoppyn_tbl)->insert($op_data);
					}
					

					$result3 = $this->db->table($bill_mst_tbl)
									  	->where('bills_ref_id !=', $un_bills_ref_id)
									  	->where('acc_id', $account_id)
									  	->get()->getResultArray();

					foreach ($result2 as $key3 => $value2) {
						$this->db->table($billsoppyn_tbl)
						  	->where('bills_ref_id', $value2['bills_ref_id'])
						  	->update(['bills_op_bal' => 0]);
					}
				}
			}
			else{
				$un_bills_ref_id = $this->TransactionModel->getUndefinedBillRefId($account_id);

				$this->db->table($billsoppyn_tbl)
						  	->where('bills_ref_id', $un_bills_ref_id)
						  	->update(['bills_op_bal' => 0]);
			}
   	}
   }
   

   public function check_account_txn_tables($acc_id)
   {
   	$error = false;

   	try{
   		$accnttxnnn_tbl = $this->company_id.'_accnttxnnn_'.$acc_id.'_'.$this->session->get('ses_comp_fy_id');
   		$builder = $this->db->table($accnttxnnn_tbl);
   		$result = $builder->get()->getRowArray();
   	}
   	catch (\Exception $e) {
			$error = true;
		}

		return $error;
   }

   public function check_bill_sundry_txn_tables($bsd_id)
   {
   	$error = false;

   	try{
   		$sundrytxnn_tbl = $this->company_id.'_sundrytxnn_'.$bsd_id.'_'.$this->session->get('ses_comp_fy_id');
   		$builder = $this->db->table($sundrytxnn_tbl);
   		$result = $builder->get()->getRowArray();
   	}
   	catch (\Exception $e) {
			$error = true;
		}

		return $error;
   }

   public function check_item_txn_tables($item_id)
   {
   	$error = false;
	

   	try{
   		$itemtxnnnn_tbl =  $this->company_id.'_itemtxnnnn_'.$item_id.'_'.$this->session->get('ses_comp_fy_id');
   		$builder = $this->db->table($itemtxnnnn_tbl);
   		$result = $builder->get()->getRowArray();
   	}
   	catch (\Exception $e) {
			$error = true;
		}

		try{
   		$itemtxnval_tbl  = $this->company_id.'_itemtxnval_'.$item_id.'_'.$this->session->get('ses_comp_fy_id');
   		$builder = $this->db->table($itemtxnval_tbl);
   		$result = $builder->get()->getRowArray();
   	}
   	catch (\Exception $e) {
			$error = true;
		}



		return $error;
   }

   public function rectify_account_txn_tables($acc_id)
   {
   	$errors = [];

   	$ERPtables = new ERPtables($this->company_id,$this->session->get('ses_comp_fy_id'));
		$errors = $ERPtables->account_txn_tables($acc_id);

		return $errors;
   }

   public function rectify_bill_sundry_txn_tables($bsd_id)
   {
   	$errors = [];

   	$ERPtables = new ERPtables($this->company_id,$this->session->get('ses_comp_fy_id'));
		$errors = $ERPtables->bill_sundry_txn_tables($bsd_id);

		return $errors;
   }

   public function rectify_item_txn_tables($item_id)
   {
   	$errors = [];

   	$ERPtables = new ERPtables($this->company_id,$this->session->get('ses_comp_fy_id'));
		$errors = $ERPtables->item_txn_tables($item_id);

		return $errors;
   }

  function reset_mapping()
  {
  	$uuid  = $this->session->get('comp_uuid');
  	$uuid_db = $this->externaldb->connect_uuid_db($uuid);

  	$table = $this->company_id.'_baseidgenrt';
  	$uuid_db->query('TRUNCATE TABLE `'.$table.'` ');

  	$table = $this->company_id.'_cofymstmap';
  	$uuid_db->query('TRUNCATE TABLE `'.$table.'` ');

  	$array = [
      ['type' => 'hobomaster', 'id' => 'bo_id', 'name' => 'bo_name'],
      ['type' => 'compcurrcy', 'id' => 'comp_currency_id', 'name' => 'curr_name'],
      ['type' => 'cmpvchseri', 'id' => 'comp_vch_series_id', 'name' => 'comp_vch_series'],

      ['type' => 'acctgroupn', 'id' => 'acc_grp_id', 'name' => 'acc_grp_name'],
      ['type' => 'acctmaster', 'id' => 'acc_id', 'name' => 'acc_name'],
      ['type' => 'billsundry', 'id' => 'bill_sundry_id', 'name' => 'bill_sundry_name'],
      ['type' => 'projectgrp', 'id' => 'project_grp_id', 'name' => 'project_grp_name'],
      ['type' => 'projectmst', 'id' => 'project_id', 'name' => 'project_name'],

      ['type' => 'itemgrpmst', 'id' => 'item_grp_id', 'name' => 'item_grp_name'],
      ['type' => 'itemcatmst', 'id' => 'icatgms_id', 'name' => 'item_cat'],
      ['type' => 'itemmaster', 'id' => 'item_id', 'name' => 'item_name'],
      ['type' => 'itmbatchmt', 'id' => 'batch_id', 'name' => 'batch_no'],
      ['type' => 'itmunitmst', 'id' => 'unit_id', 'name' => 'item_unit'],

      ['type' => 'mcgrpmstnn', 'id' => 'mc_grp_id', 'name' => 'mc_grp_name'],
      ['type' => 'mcmasternn', 'id' => 'mat_cent_id', 'name' => 'mat_cent_name'],
      ['type' => 'barcodemst', 'id' => 'barcode_id', 'name' => 'barcode'],
      ['type' => 'labelmastr', 'id' => 'label_id', 'name' => 'label_name'],

      ['type' => 'costctgrup', 'id' => 'cc_grp_id', 'name' => 'cc_grp_name'],
      ['type' => 'costctmstr', 'id' => 'cc_id', 'name' => 'cc_name'],
      ['type' => 'billmaster', 'id' => 'bills_ref_id', 'name' => 'bills_ref_name'],
      ['type' => 'billofmatn', 'id' => 'bom_id', 'name' => 'bom_name'],
      ['type' => 'prntconfig', 'id' => 'prntconfig_id', 'name' => 'prntconfig_id'],
    ];

   	$result = $this->aicountly_db->table("aicountly_cmpfymastr_univdb")
		    			->select('comp_fy_id')
		    			->where('comp_id', $this->company_id)
		    			->orderBy('comp_fy_id','asc')
		    			->get()->getResultArray();

		foreach($result as $key => $value){
			
			foreach ($array as $arr) {

				if(isset($result[$key-1])){

					$prev_comp_fy_id = $result[$key-1]['comp_fy_id'];

					$p_table = $this->company_id.'_'.$arr['type'].'_'.$prev_comp_fy_id;
					$table = $this->company_id.'_'.$arr['type'].'_'.$value['comp_fy_id'];

					$result2 = $this->db->table($table)
													->get()->getResultArray();

					foreach ($result2 as $key2 => $value2) {
						$id = $value2[$arr['id']];
						$name = $value2[$arr['name']];

						$name = strtolower($name);
						$name = trim($name);

						if($arr['type'] == 'acctmaster' || $arr['type'] == 'itemmaster'){
							$p_result2 = $this->db->table($p_table)
										->where('LOWER('.$arr['name'].')',$name)
										->get()->getRowArray();
						}
						else{
							$p_result2 = $this->db->table($p_table)
										->where($arr['id'],$id)
										->where('LOWER('.$arr['name'].')',$name)
										->get()->getRowArray();
						}
							
						if($p_result2){

							echo '<br>------'.$name.' - '.$p_result2[$arr['name']].'<br>';
							$UUIDtables = new UUIDtables($uuid,$this->company_id,$prev_comp_fy_id);

							$mst_base_id = $UUIDtables->mst_base_id($p_result2[$arr['id']],$arr['type'],$value['comp_fy_id'],$id);

							echo $arr['type'].'-- '.$name.'- '.$mst_base_id.' if<br>';
						}
						else{
							$UUIDtables = new UUIDtables($uuid,$this->company_id,$value['comp_fy_id']);

							$mst_base_id = $UUIDtables->mst_base_id($id,$arr['type']);

							echo $arr['type'].'-- '.$name.'- '.$mst_base_id.' else<br>';
						}


						$this->db->table($table)
										->where($arr['id'],$id)
										->update(['mst_base_id' => $mst_base_id]);
					}

				}
				else{

					$table = $this->company_id.'_'.$arr['type'].'_'.$value['comp_fy_id'];

					$result2 = $this->db->table($table)
													->get()->getResultArray();
					foreach ($result2 as $key2 => $value2) {

						$id = $value2[$arr['id']];
						$name = $value2[$arr['name']];
						
						$UUIDtables = new UUIDtables($uuid,$this->company_id,$value['comp_fy_id']);

						$mst_base_id = $UUIDtables->mst_base_id($id,$arr['type']);

						$this->db->table($table)
										->where($arr['id'],$id)
										->update(['mst_base_id' => $mst_base_id]);
					}

				}
				
			}
		}

  }
}