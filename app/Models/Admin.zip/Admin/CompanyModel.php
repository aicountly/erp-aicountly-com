<?php
namespace App\Models\Admin;

use CodeIgniter\Model;
use App\Libraries\externaldb;

class CompanyModel extends Model	{
    protected $session;
	protected $company_id;
	protected $comp_fy_id;
	protected $externaldb;
	protected $erp_db;
	protected $aicountly_db;
	
	public function __construct() {
		parent::__construct();
		$this->session      = \Config\Services::session();
		$this->company_id   = $this->session->get('ses_company_id');
		$this->comp_fy_id   = $this->session->get('ses_comp_fy_id');
		$this->externaldb   = new externaldb();
		$this->erp_db       = $this->externaldb->erp_db();
		$this->aicountly_db = $this->externaldb->aicountly_db();		
	}

	/****************************** FY CHANGE START **********************************/  


	function get_sticky_notes()
	{
		$notes = [
			[
				'primary' => 1,
				'heading' => 'Note 1',
				'details' => '',
				'color'		=> '#DBFFD2',
			],
			[
				'primary' => 2,
				'heading' => 'Note 2',
				'details' => '',
				'color'		=> '#DBF3FB',
			],
			[
				'primary' => 3,
				'heading' => 'Note 3',
				'details' => '',
				'color'		=> '#FFF8D7',
			],
			[
				'primary' => 4,
				'heading' => 'Note 4',
				'details' => '',
				'color'		=> '#FBE2D2',
			],
			[
				'primary' => 5,
				'heading' => 'Note 5',
				'details' => '',
				'color'		=> '#FFEAED',
			],
		];
		try{

		$compnotesn_tbl = $this->company_id.'_compnotesn_'.$this->session->get('ses_comp_fy_id');

		foreach ($notes as $key => $value) {

			$result = $this->db->table($compnotesn_tbl)
											->where('note_primary', $value['primary'])
											->get()->getRowArray();
			if($result){
				$notes[$key]['heading'] = $result['note_heading'];
				$notes[$key]['details'] = $result['note_details'];
			}
		}

		}
		catch(\Exception $e){

		}
		
		return $notes;
	}

	public function updateFYStatus($fy_id){
		if($fy_id>0){   
			$this->aicountly_db->table("aicountly_cmpfymastr_univdb")
			->where('comp_fy_id',$fy_id)
			->where('comp_id',$this->company_id)->update(array('is_imported'=>'1'));   
		}

	}
	public function GetTableName($company_id,$table_name,$fy_id){
		return $company_id.$table_name.$fy_id;  	   
	}

	public function GetAccountBalance($account_id){
		$final_data     = array(); 
		$current_fy_id  = $this->session->get('ses_comp_fy_id'); 
		$hobomaster_tbl = $this->company_id.'_hobomaster_'.$current_fy_id;
		$accoppybal_tbl = $this->company_id.'_accoppybal_'.$current_fy_id;
		$txn_tablename  = $this->company_id.'_accnttxnnn_'.$account_id.'_'.$current_fy_id;

		$bo_data = $this->db->table($hobomaster_tbl)
		->select('bo_id,comp_id')
		->where('comp_id', $this->company_id)
		->get()->getResultArray();
		if($bo_data){
			foreach($bo_data as $brow){
				$bo_id = $brow['bo_id'];

				$accoppybal_data = $this->db->table($accoppybal_tbl)
				->select('bo_id,acc_id,acc_op_bal')
				->where('acc_id', $account_id)
				->where('bo_id', $bo_id)
				->get()->getRowArray();


				$builder = $this->db->table($txn_tablename);
				$builder->where('comp_id',$this->company_id);
				$builder->where('acc_id',$account_id);
				$builder->where('bo_id',$bo_id);
				$builder->orderBy('acc_txn_date','DESC');	 
				$builder->orderBy('voucher_txn_id','DESC');	 
				$builder->orderBy('acc_txn_id','DESC');	 		  
				$builder->limit("1");
				$result = $builder->get()->getRowArray();
				if($result)
					$balance = $result['acc_bal'];
				else if($accoppybal_data)
					$balance= $accoppybal_data['acc_op_bal'];		
				else
					$balance=0;

				$final_data[]=array('acc_id'=>$account_id,'acc_py_bal'=>$balance,'acc_op_bal'=>$balance,'bo_id'=>$bo_id);			

			} 		  
		}						  
		return $final_data;				  
	}
	
	
	function get_fy_details($comp_fy_id,$comp_id){		
		$response =  $this->db->table('cmpfymastr')->where('cmpfymastr_id', $comp_fy_id)->where('cmp_id', $comp_id)->get()->getRowArray();   	   
	
		return $response;
	}

	public function GetBillSundryBalance($account_id){
		$final_data     = array(); 
		$current_fy_id  = $this->session->get('ses_comp_fy_id'); 
		$hobomaster_tbl = $this->company_id.'_hobomaster_'.$current_fy_id;
		$accoppybal_tbl = $this->company_id.'_bsdoppybal_'.$current_fy_id;
		$txn_tablename  = $this->company_id.'_sundrytxnn_'.$account_id.'_'.$current_fy_id;

		$bo_data = $this->db->table($hobomaster_tbl)
		->select('bo_id,comp_id')
		->where('comp_id', $this->company_id)
		->get()->getResultArray();
		if($bo_data){
			foreach($bo_data as $brow){
				$bo_id = $brow['bo_id'];

				$accoppybal_data = $this->db->table($accoppybal_tbl)
				->select('bo_id,bill_sundry_id,bsd_op_bal')
				->where('bill_sundry_id', $account_id)
				->where('bo_id', $bo_id)
				->get()->getRowArray();			 		  

				$builder = $this->db->table($txn_tablename);
				$builder->where('comp_id',$this->company_id);
				$builder->where('bill_sundry_id',$account_id);
				$builder->where('bo_id',$bo_id);
				$builder->orderBy('sundry_txn_date','DESC');	 
				$builder->orderBy('voucher_txn_id','DESC');	 
				$builder->orderBy('sundry_txn_id','DESC');	 		  
				$builder->limit("1");
				$result = $builder->get()->getRowArray();
				if($result)
					$balance = $result['bill_sundry_id'];
				else if($accoppybal_data)
					$balance= $accoppybal_data['bsd_op_bal'];		
				else
					$balance=0;

				$final_data[]=array('bill_sundry_id'=>$account_id,'bsd_op_bal'=>$balance,'bsd_py_bal'=>$balance,'bo_id'=>$bo_id);			

			} 		  
		}						  
		return $final_data;				  
	}

	function get_company_mc(){
		$comp_mtcnt_tbl = $this->company_id.'_mcmasternn_'.$this->session->get('ses_comp_fy_id');
		$data           = $this->db->table($comp_mtcnt_tbl)->where('comp_id', $this->company_id)->orderBy('mat_cent_name','ASC')->get()->getResultArray();
		$final_result   = array();
		if($data){
			foreach($data as $row){
              $name = '';//$this->enc_string->nc_string($row['mat_cent_name'],'de');	
              $final_result[] = [
              	'name' => ucwords($name),
              	'id'    => $row['mat_cent_id']
              ];
            }
          }
          return $final_result;	
        }

        public function GetItemUnits($item_id){
	  	// check item default unit
	 	// check item opening units
    	// check item txn units

        	$unit_result = [];
        	$list = [];

        	$itemtxnnnn_tbl =  $this->company_id.'_itemtxnnnn_'.$item_id.'_'.$this->session->get('ses_comp_fy_id');
        	$itmoppybal_tbl = $this->company_id.'_itmoppybal_'.$this->session->get('ses_comp_fy_id');
        	$itemmaster_tbl = $this->company_id.'_itemmaster_'.$this->session->get('ses_comp_fy_id');

        	$itemmaster = $this->db->table($itemmaster_tbl)->where('item_id', $item_id)->get()->getRowArray();
        	$unit_result[] = $itemmaster['item_unit'];

        	$builder = $this->db->table($itmoppybal_tbl);
        	$builder->select('item_unit');
        	$builder->where('item_id', $item_id);
        	$builder->groupBy('item_unit');
        	$result = $builder->get()->getResultArray();
        	if($result){
        		foreach ($result as $key => $value) {
        			if(!in_array($value['item_unit'], $unit_result)){
        				$unit_result[] = $value['item_unit'];
        			}
        		}
        	}

        	$builder = $this->db->table($itemtxnnnn_tbl);
        	$builder->select('item_unit');
        	$builder->where('item_id', $item_id);
        	$builder->groupBy('item_unit');
        	$result = $builder->get()->getResultArray();
        	if($result){
        		foreach ($result as $key => $value) {
        			if(!in_array($value['item_unit'], $unit_result)){
        				$unit_result[] = $value['item_unit'];
        			}
        		}
        	}

        	foreach ($unit_result as $unit_key => $unit_value) {

        		$unit = '';
			// $item_unit_info = $this->get_units_info($unit_value,$this->company_id);
			// if(isset($item_unit_info['item_unit']))
			//    $unit = $this->enc_string->nc_string($item_unit_info['item_unit'],'de');

        		$list[] = [
        			'unit_id' => $unit_value,
        			'unit_name' => $unit,
        		];

        	}

        	return $list;

        } 

        public function GetItemBalance($item_id){

        	$item_val_id_arr = [1,2,3];

        	$final_op_bal_result     = array();
        	$final_op_val_result     = array();

        	$current_fy_id  = $this->session->get('ses_comp_fy_id'); 
        	$hobomaster_tbl = $this->company_id.'_hobomaster_'.$current_fy_id;
        	$accoppybal_tbl = $this->company_id.'_itmoppybal_'.$current_fy_id;
        	$txn_tablename  = $this->company_id.'_itemtxnnnn_'.$item_id.'_'.$current_fy_id;
        	$itemtxnval_tbl  = $this->company_id.'_itemtxnval_'.$item_id.'_'.$current_fy_id;

        	$itmoppybal_tbl = $this->company_id.'_itmoppybal_'.$this->session->get('ses_comp_fy_id');
        	$itmoppyval_tbl = $this->company_id.'_itmoppyval_'.$this->session->get('ses_comp_fy_id');

        	$bo_data        = $this->db->table($hobomaster_tbl)
        	->select('bo_id,comp_id')
        	->where('comp_id', $this->company_id)
        	->get()->getResultArray();
        	if($bo_data){
        		foreach($bo_data as $brow1){
        			$bo_id = $brow1['bo_id'];
		   // mc loop
        			$company_all_mc = $this->get_company_mc();
        			if($company_all_mc){
        				foreach($company_all_mc as $brow2){

        					$mc_id = $brow2['id'];
					// all units loop
        					$all_item_units = $this->GetItemUnits($item_id);

        					foreach ($all_item_units as $brow3) {

        						$unit_id = $brow3['unit_id'];

        						$item_qty = 0;
        						$item_val_arr = [];
        						foreach ($item_val_id_arr as $item_val_id) {
        							$item_val_arr[$item_val_id] = 0;
        						}

        						$builder = $this->db->table($txn_tablename);
        						$builder->where('item_id', $item_id);
        						$builder->where('item_unit', $unit_id);
        						$builder->where('mat_cent_id', $mc_id);
        						$builder->where('batch_id', 0);
        						$builder->where('item_avail', 1);

        						$builder->where('bo_id', $bo_id);
        						$builder->orderBy('item_txn_date', 'desc');
        						$builder->orderBy('voucher_txn_id', 'desc');
        						$builder->orderBy('item_txn_id', 'desc');
        						$builder->limit(1);
        						$transaction = $builder->get()->getRowArray();
        						if($transaction){
        							$item_qty = floatval($transaction['item_bal_qty']);

        							foreach ($item_val_id_arr as $item_val_id) {

        								$builder = $this->db->table($itemtxnval_tbl);
        								$builder->where('item_id', $item_id);
        								$builder->where('item_txn_id', $transaction['item_txn_id']);
        								$builder->where('method_id', $item_val_id);
        								$itemtxnval = $builder->get()->getRowArray();
        								if($itemtxnval){
        									$item_val_arr[$item_val_id] = floatval($itemtxnval['item_value']);
        								}
        							}
        						}
        						else{
        							$builder = $this->db->table($itmoppybal_tbl); 
        							$builder->where('item_id', $item_id);
        							$builder->where('item_unit', $unit_id);
        							$builder->where('mat_cent_id', $mc_id);

        							$builder->where('bo_id', $bo_id);
        							$builder->where('batch_id', 0);
        							$itmoppybal = $builder->get()->getRowArray();
        							if($itmoppybal){
        								$item_qty = floatval($itmoppybal['op_bal_qty']);

        								foreach ($item_val_id_arr as $item_val_id) {

        									$builder = $this->db->table($itmoppyval_tbl); 
        									$builder->where('item_id', $item_id);
        									$builder->where('item_unit', $unit_id);
        									$builder->where('mat_cent_id', $mc_id);

        									$builder->where('bo_id', $bo_id);
        									$builder->where('batch_id', 0);
        									$builder->where('method_id', $item_val_id);
        									$itmoppyval = $builder->get()->getRowArray();

        									if($itmoppyval){
        										$item_val_arr[$item_val_id] = floatval($itmoppyval['op_bal_val']);
        									}
        								}
        							}
        						}

        						$final_op_bal_result[] = [
        							'item_id'				=> $item_id,
        							'comp_id' 			=> $this->company_id,
        							'item_unit' 		=> $unit_id,
        							'mat_cent_id'   => $mc_id,
        							'bo_id'					=> $bo_id,
        							'batch_id'			=> 0,
        							'op_bal_qty'		=> $item_qty,
        							'py_bal_qty'		=> $item_qty,
        						];

        						foreach ($item_val_arr as $item_val_id => $item_val) 
        						{
        							$final_op_val_result[] = [
        								'item_id'				=> $item_id,
        								'comp_id' 			=> $this->company_id,
        								'item_unit' 		=> $unit_id,
        								'mat_cent_id'   => $mc_id,
        								'bo_id'					=> $bo_id,
        								'batch_id'			=> 0,
        								'op_bal_val'		=> $item_val,
        								'py_bal_val'		=> $item_val,
        								'method_id'			=> $item_val_id,
        							];
        						}

        					}
        				}
        			}
        		}
        	}

        	return [
        		'final_op_bal_result'	=> 	$final_op_bal_result,
        		'final_op_val_result'	=>  $final_op_val_result,
        	];
        }						  



        public function CreateFYTable($old_tbl,$new_tbl){
        	try{
        		$this->db->query("DROP TABLE IF EXISTS `".$new_tbl."`;");   	
        		$this->db->query("CREATE TABLE `".$new_tbl."` LIKE `".$old_tbl."`;");
        		$this->db->query("INSERT INTO `".$new_tbl."` SELECT * FROM `".$old_tbl."`");
	//$this->db->query("CREATE TABLE `".$new_tbl."` AS SELECT * FROM `".$old_tbl."`;");
	// this command create data&structure only no primary key and indexing 
        	}
        	catch (\Exception $e) {
        		$status = 0;
        		$flag = 1;
        	}   
        }
        function GetDrpTableName($company_id,$new_tbl,$fy_id){
        	try{
        		$new_tbl = $company_id.$new_tbl.$fy_id;
        		$this->db->query("DROP TABLE IF EXISTS `".$new_tbl."`;"); 
        	}catch (\Exception $e) {
        		$status = 0;
        		$flag = 1;
        	}   
        }
        function DropAllFYTables($fy_id){
        	for($i=1;$i<=100;$i++){		
        		$this->db->query("DROP TABLE IF EXISTS `".$this->company_id.'_itemtxnnnn_'.$i.'_'.$fy_id."`;"); 		
        		$this->db->query("DROP TABLE IF EXISTS `".$this->company_id.'_accnttxnnn_'.$i.'_'.$fy_id."`;"); 	
        		$this->db->query("DROP TABLE IF EXISTS `".$this->company_id.'_sundrytxnn_'.$i.'_'.$fy_id."`;"); 	
        		$this->db->query("DROP TABLE IF EXISTS `".$this->company_id.'_itemtxnval_'.$i.'_'.$fy_id."`;"); 		

        	} 

        	$tanmastern_ntbl      = $this->GetDrpTableName($this->company_id,'_tanmastern_',$fy_id);
        	$gstinmastr_ntbl      = $this->GetDrpTableName($this->company_id,'_gstinmastr_',$fy_id);
        	$cmpprofsnl_ntbl      = $this->GetDrpTableName($this->company_id,'_cmpprofsnl_',$fy_id);
        	$cmpprofstf_ntbl      = $this->GetDrpTableName($this->company_id,'_cmpprofstf_',$fy_id);
        	$comp_txn_master_ntbl = $this->GetDrpTableName($this->company_id,'_comptxnmst_',$fy_id);                 		
        	$company_bank_ntbl    = $this->GetDrpTableName($this->company_id,'_compbanknn_',$fy_id);
        	$comp_accountant_ntbl = $this->GetDrpTableName($this->company_id,'_compatnnnn_',$fy_id);
        	$comp_auditor_ntbl    = $this->GetDrpTableName($this->company_id,'_cmpauditor_',$fy_id);
        	$comp_currency_ntbl   = $this->GetDrpTableName($this->company_id,'_compcurrcy_',$fy_id);
        	$forexrates_ntbl      = $this->GetDrpTableName($this->company_id,'_forexrates_',$fy_id);
        	$cmperplogs_ntbl      = $this->GetDrpTableName($this->company_id,'_cmperplogs_',$fy_id);
        	$hobomaster_ntbl      = $this->GetDrpTableName($this->company_id,'_hobomaster_',$fy_id); 
        	$vhtxntrail_ntbl  = $this->GetDrpTableName($this->company_id,'_vhtxntrail_',$fy_id);
        	$cmpvchseri_ntbl  = $this->GetDrpTableName($this->company_id,'_cmpvchseri_',$fy_id);
        	$vchseriesa_ntbl  = $this->GetDrpTableName($this->company_id,'_vchseriesa_',$fy_id);
        	$vchseriesm_ntbl  = $this->GetDrpTableName($this->company_id,'_vchseriesm_',$fy_id);
        	$cmpvchtype_ntbl  = $this->GetDrpTableName($this->company_id,'_cmpvchtype_',$fy_id);
        	$vchsubtype_ntbl  = $this->GetDrpTableName($this->company_id,'_vchsubtype_',$fy_id);
        	$long_narrn_ntbl  = $this->GetDrpTableName($this->company_id,'_long_narrn_',$fy_id);
        	$short_narr_ntbl  = $this->GetDrpTableName($this->company_id,'_short_narr_',$fy_id);		
        	$vhtxnconso_ntbl  = $this->GetDrpTableName($this->company_id,'_vhtxnconso_',$fy_id);
        	$acctcontnn_ntbl  = $this->GetDrpTableName($this->company_id,'_acctcontnn_',$fy_id);
        	$acctgroupn_ntbl  = $this->GetDrpTableName($this->company_id,'_acctgroupn_',$fy_id);
        	$grpparentn_ntbl  = $this->GetDrpTableName($this->company_id,'_grpparentn_',$fy_id);
        	$acctmaster_ntbl  = $this->GetDrpTableName($this->company_id,'_acctmaster_',$fy_id);
        	$mcgrpmstnn_ntbl  = $this->GetDrpTableName($this->company_id,'_mcgrpmstnn_',$fy_id);
        	$mcmasternn_ntbl  = $this->GetDrpTableName($this->company_id,'_mcmasternn_',$fy_id);
        	$mcstoremst_ntbl  = $this->GetDrpTableName($this->company_id,'_mcstoremst_',$fy_id);
        	$billsundry_ntbl  = $this->GetDrpTableName($this->company_id,'_billsundry_',$fy_id);
        	$billofmatn_ntbl  = $this->GetDrpTableName($this->company_id,'_billofmatn_',$fy_id);
        	$bominputnn_ntbl  = $this->GetDrpTableName($this->company_id,'_bominputnn_',$fy_id);
        	$bomoutputn_ntbl  = $this->GetDrpTableName($this->company_id,'_bomoutputn_',$fy_id);
        	$bomaddcost_ntbl  = $this->GetDrpTableName($this->company_id,'_bomaddcost_',$fy_id);
        	$billmaster_ntbl  = $this->GetDrpTableName($this->company_id,'_billmaster_',$fy_id);
        	$costctmstr_ntbl  = $this->GetDrpTableName($this->company_id,'_costctmstr_',$fy_id);
        	$costctgrup_ntbl  = $this->GetDrpTableName($this->company_id,'_costctgrup_',$fy_id);		
        	$itemcatmst_ntbl = $this->GetDrpTableName($this->company_id,'_itemcatmst_',$fy_id);
        	$itmgrpprnt_ntbl = $this->GetDrpTableName($this->company_id,'_itmgrpprnt_',$fy_id); 
        	$itemgrpmst_ntbl = $this->GetDrpTableName($this->company_id,'_itemgrpmst_',$fy_id);
        	$itemmaster_ntbl = $this->GetDrpTableName($this->company_id,'_itemmaster_',$fy_id);
        	$itmunitmst_ntbl = $this->GetDrpTableName($this->company_id,'_itmunitmst_',$fy_id);			
        	$itmparamtr_ntbl = $this->GetDrpTableName($this->company_id,'_itmparamtr_',$fy_id);		
        	$paramtrval_ntbl = $this->GetDrpTableName($this->company_id,'_paramtrval_',$fy_id);
        	$itmaltunit_ntbl = $this->GetDrpTableName($this->company_id,'_itmaltunit_',$fy_id);		
        	$itemdimens_ntbl = $this->GetDrpTableName($this->company_id,'_itemdimens_',$fy_id);
        	$itmbatchmt_ntbl = $this->GetDrpTableName($this->company_id,'_itmbatchmt_',$fy_id);
        	$itmtagging_ntbl = $this->GetDrpTableName($this->company_id,'_itmtagging_',$fy_id);
        	$labelmastr_ntbl = $this->GetDrpTableName($this->company_id,'_labelmastr_',$fy_id);
        	$labeldescn_ntbl = $this->GetDrpTableName($this->company_id,'_labeldescn_',$fy_id);
        	$itemlabeln_ntbl = $this->GetDrpTableName($this->company_id,'_itemlabeln_',$fy_id); 
        	$pckglistnn_ntbl = $this->GetDrpTableName($this->company_id,'_pckglistnn_',$fy_id);
        	$pckqtylist_ntbl = $this->GetDrpTableName($this->company_id,'_pckqtylist_',$fy_id); 
        	$pcklistbeg_ntbl = $this->GetDrpTableName($this->company_id,'_pcklistbeg_',$fy_id);
        	$pcklistext_ntbl = $this->GetDrpTableName($this->company_id,'_pcklistext_',$fy_id);		
        	$itemtrackn_ntbl = $this->GetDrpTableName($this->company_id,'_itemtrackn_',$fy_id);		
        	$pcklistmst_ntbl = $this->GetDrpTableName($this->company_id,'_pcklistmst_',$fy_id);
        	$listpacked_ntbl = $this->GetDrpTableName($this->company_id,'_listpacked_',$fy_id);
        	$pcklistqty_ntbl = $this->GetDrpTableName($this->company_id,'_pcklistqty_',$fy_id);
        	$listcumast_ntbl = $this->GetDrpTableName($this->company_id,'_listcumast_',$fy_id);
        	$cupackingn_ntbl = $this->GetDrpTableName($this->company_id,'_cupackingn_',$fy_id);
        	$leveltrack_ntbl = $this->GetDrpTableName($this->company_id,'_leveltrack_',$fy_id);
        	$barcodemst_ntbl = $this->GetDrpTableName($this->company_id,'_barcodemst_',$fy_id);
        	$itemtxnoth_tbl  = $this->GetDrpTableName($this->company_id,'_itemtxnoth_',$fy_id);
        	$itemcrsref_tbl  = $this->GetDrpTableName($this->company_id,'_itemcrsref_',$fy_id);
        	$itmoppyval_tbl  = $this->GetDrpTableName($this->company_id,'_itmoppyval_',$fy_id);
        	$itmoppybal_tbl  = $this->GetDrpTableName($this->company_id,'_itmoppybal_',$fy_id);
        	$accttxnoth_tbl = $this->GetDrpTableName($this->company_id,'_accttxnoth_',$fy_id); 
        	$acctcrsref_tbl = $this->GetDrpTableName($this->company_id,'_acctcrsref_',$fy_id);		
        	$accoppybal_tbl = $this->GetDrpTableName($this->company_id,'_accoppybal_',$fy_id); 

        	$bsdoppybal_tbl = $this->GetDrpTableName($this->company_id,'_bsdoppybal_',$fy_id); 
        	$itemtrackn_tbl = $this->GetDrpTableName($this->company_id,'_itemtrackn_',$fy_id); 
        	$itemtrackn_tbl = $this->GetDrpTableName($this->company_id,'_cmpvchseri_',$fy_id); 
        	$itemtrackn_tbl = $this->GetDrpTableName($this->company_id,'_cmpvchtype_',$fy_id); 
        	$itemtrackn_tbl = $this->GetDrpTableName($this->company_id,'_compcurrcy_',$fy_id); 
        	$itemtrackn_tbl = $this->GetDrpTableName($this->company_id,'_comptxnmst_',$fy_id); 
        	$itemtrackn_tbl = $this->GetDrpTableName($this->company_id,'_billstxnnn_',$fy_id); 
        	$itemtrackn_tbl = $this->GetDrpTableName($this->company_id,'_costcttxnn_',$fy_id); 
        	$itemtrackn_tbl = $this->GetDrpTableName($this->company_id,'_prntconfig_',$fy_id); 
        	$itemtrackn_tbl = $this->GetDrpTableName($this->company_id,'_prntdesign_',$fy_id);		
        	$taxcatmstn_tbl = $this->GetDrpTableName($this->company_id,'_taxcatmstn_',$fy_id); 
        	$itemvalmst_tbl = $this->GetDrpTableName($this->company_id,'_itemvalmst_',$fy_id);

        }


        public function create_company_default_tables($fy_id){
        	$current_fy_id       = $this->session->get('ses_comp_fy_id');
	   //New Tables With New FY ID
        	$tanmastern_ntbl      = $this->GetTableName($this->company_id,'_tanmastern_',$fy_id);
        	$gstinmastr_ntbl      = $this->GetTableName($this->company_id,'_gstinmastr_',$fy_id);
        	$cmpprofsnl_ntbl      = $this->GetTableName($this->company_id,'_cmpprofsnl_',$fy_id);
        	$cmpprofstf_ntbl      = $this->GetTableName($this->company_id,'_cmpprofstf_',$fy_id);

        	$company_bank_ntbl    = $this->GetTableName($this->company_id,'_compbanknn_',$fy_id);
        	$comp_accountant_ntbl = $this->GetTableName($this->company_id,'_compatnnnn_',$fy_id);
        	$comp_auditor_ntbl    = $this->GetTableName($this->company_id,'_cmpauditor_',$fy_id);


        	$comp_txn_master_ntbl = $this->GetTableName($this->company_id,'_comptxnmst_',$fy_id);
        	$comp_currency_ntbl   = $this->GetTableName($this->company_id,'_compcurrcy_',$fy_id);
        	$forexrates_ntbl      = $this->GetTableName($this->company_id,'_forexrates_',$fy_id);
        	$cmperplogs_ntbl      = $this->GetTableName($this->company_id,'_cmperplogs_',$fy_id);
        	$hobomaster_ntbl      = $this->GetTableName($this->company_id,'_hobomaster_',$fy_id);
        	$prntconfig_ntbl      = $this->GetTableName($this->company_id,'_prntconfig_',$fy_id);
        	$prntdesign_ntbl      = $this->GetTableName($this->company_id,'_prntdesign_',$fy_id);

        	$cmpgtcscat_ntbl      = $this->GetTableName($this->company_id,'_cmpgtcscat_',$fy_id);
        	$cmpgstcatn_ntbl      = $this->GetTableName($this->company_id,'_cmpgstcatn_',$fy_id);
        	$cmptaxcatm_ntbl      = $this->GetTableName($this->company_id,'_cmptaxcatm_',$fy_id);
        	$cmpgwhtcat_ntbl      = $this->GetTableName($this->company_id,'_cmpgwhtcat_',$fy_id);
        	$cmpitcscat_ntbl      = $this->GetTableName($this->company_id,'_cmpitcscat_',$fy_id);
        	$cmpiwhtcat_ntbl      = $this->GetTableName($this->company_id,'_cmpiwhtcat_',$fy_id);

		//Old Tables With Curret FY ID
        	$tanmastern_otbl      = $this->GetTableName($this->company_id,'_tanmastern_',$current_fy_id);
        	$gstinmastr_otbl      = $this->GetTableName($this->company_id,'_gstinmastr_',$current_fy_id);
        	$cmpprofsnl_otbl      = $this->GetTableName($this->company_id,'_cmpprofsnl_',$current_fy_id);
        	$cmpprofstf_otbl      = $this->GetTableName($this->company_id,'_cmpprofstf_',$current_fy_id);
        	$comp_txn_master_otbl = $this->GetTableName($this->company_id,'_comptxnmst_',$current_fy_id);                 		
        	$company_bank_otbl    = $this->GetTableName($this->company_id,'_compbanknn_',$current_fy_id);
        	$comp_accountant_otbl = $this->GetTableName($this->company_id,'_compatnnnn_',$current_fy_id);
        	$comp_auditor_otbl    = $this->GetTableName($this->company_id,'_cmpauditor_',$current_fy_id);
        	$comp_currency_otbl   = $this->GetTableName($this->company_id,'_compcurrcy_',$current_fy_id);
        	$forexrates_otbl      = $this->GetTableName($this->company_id,'_forexrates_',$current_fy_id);
        	$cmperplogs_otbl      = $this->GetTableName($this->company_id,'_cmperplogs_',$current_fy_id);
        	$hobomaster_otbl      = $this->GetTableName($this->company_id,'_hobomaster_',$current_fy_id);
        	$prntconfig_otbl      = $this->GetTableName($this->company_id,'_prntconfig_',$current_fy_id);
        	$prntdesign_otbl      = $this->GetTableName($this->company_id,'_prntdesign_',$current_fy_id);

        	$cmpgtcscat_otbl      = $this->GetTableName($this->company_id,'_cmpgtcscat_',$current_fy_id);
        	$cmpgstcatn_otbl      = $this->GetTableName($this->company_id,'_cmpgstcatn_',$current_fy_id);
        	$cmptaxcatm_otbl      = $this->GetTableName($this->company_id,'_cmptaxcatm_',$current_fy_id);
        	$cmpgwhtcat_otbl      = $this->GetTableName($this->company_id,'_cmpgwhtcat_',$current_fy_id);
        	$cmpitcscat_otbl      = $this->GetTableName($this->company_id,'_cmpitcscat_',$current_fy_id);
        	$cmpiwhtcat_otbl      = $this->GetTableName($this->company_id,'_cmpiwhtcat_',$current_fy_id);

        	$status = 1;
        	$flag = 0;
        	try{
        		$this->CreateFYTable($tanmastern_otbl,$tanmastern_ntbl);
        		$this->CreateFYTable($gstinmastr_otbl,$gstinmastr_ntbl);
        		$this->CreateFYTable($cmpprofsnl_otbl,$cmpprofsnl_ntbl);
        		$this->CreateFYTable($cmpprofstf_otbl,$cmpprofstf_ntbl);
        		$this->CreateFYTable($comp_txn_master_otbl,$comp_txn_master_ntbl);
        		$this->CreateFYTable($company_bank_otbl,$company_bank_ntbl);
        		$this->CreateFYTable($comp_accountant_otbl,$comp_accountant_ntbl);
        		$this->CreateFYTable($comp_auditor_otbl,$comp_auditor_ntbl);
        		$this->CreateFYTable($comp_currency_otbl,$comp_currency_ntbl);
        		$this->CreateFYTable($forexrates_otbl,$forexrates_ntbl);
        		$this->CreateFYTable($cmperplogs_otbl,$cmperplogs_ntbl);
        		$this->CreateFYTable($hobomaster_otbl,$hobomaster_ntbl);
        		$this->CreateFYTable($prntconfig_otbl,$prntconfig_ntbl);
        		$this->CreateFYTable($prntdesign_otbl,$prntdesign_ntbl);		
        		$this->CreateFYTable($cmpgtcscat_otbl,$cmpgtcscat_ntbl);
        		$this->CreateFYTable($cmpgstcatn_otbl,$cmpgstcatn_ntbl);
        		$this->CreateFYTable($cmptaxcatm_otbl,$cmptaxcatm_ntbl);
        		$this->CreateFYTable($cmpgwhtcat_otbl,$cmpgwhtcat_ntbl);
        		$this->CreateFYTable($cmpitcscat_otbl,$cmpitcscat_ntbl);
        		$this->CreateFYTable($cmpiwhtcat_otbl,$cmpiwhtcat_ntbl);


        		$this->db->query('INSERT INTO `'.$prntconfig_ntbl.'`  (`prntconfig_id`, `comp_id`, `vch_series_id`, `usr_config_id`) VALUES ('.$this->company_id.',13,17);');
$this->db->query("INSERT INTO `".$prntdesign_ntbl."` 
	(`prntconfig_id`, `erpprevaln_label_id`, `prntconfig_style`) VALUES
	(1,	6,	'font-weight: bold; font-family: Verdana; font-size: 12px;'),
	(1,	7,	'font-weight: bold; font-family: Verdana; font-size: 12px;'),
	(1,	8,	'text-align: center; padding: 0px; margin: 0px; font-family: Verdana; text-decoration: underline; font-weight: bold; font-size: 12px;'),
	(1,	9,	'line-height: 42px; padding: 0px; margin: 0px; text-align: center; font-weight: bold; font-family: Verdana; font-size: 16px;'),
	(1,	10,	'font-family: Verdana; font-size: 12px;'),
	(1,	11,	'font-family: Verdana; font-size: 12px;'),
	(1,	12,	'font-family: Verdana; font-size: 12px;'),
	(1,	13,	'width: 150px; float: left; font-family: Verdana; font-size: 12px;'),
	(1,	14,	'width: 150px; float: left; font-family: Verdana; font-size: 12px;'),
	(1,	15,	'width: 150px; float: left; font-family: Verdana; font-size: 12px;'),
	(1,	16,	'width: 150px; float: left; font-family: Verdana; font-size: 12px;'),
	(1,	17,	'padding-left: 29px; font-family: Verdana; font-size: 12px;'),
	(1,	18,	'padding-left: 8px; font-family: Verdana; font-size: 12px;'),
	(1,	19,	'text-align: right; font-family: Verdana; font-size: 14px;'),
	(1,	20,	'font-family: Verdana; font-size: 14px; font-weight: bold;'),
	(1,	26,	'padding-left: 10px; font-weight: bold; font-family: Verdana; font-size: 12px;'),
	(1,	27,	'padding-left: 10px; font-weight: bold; font-family: Verdana; font-size: 12px;'),
	(1,	28,	'padding-left: 18px; font-family: Verdana; font-size: 12px;'),
	(1,	29,	'padding-left: 18px; font-family: Verdana; font-size: 12px;'),
	(1,	30,	'font-family: Verdana; font-size: 12px;'),
	(1,	31,	'font-family: Verdana; font-size: 12px;'),
	(1,	32,	'font-family: Verdana; font-size: 12px;'),
	(1,	33,	'font-family: Verdana; font-size: 12px;'),
	(1,	34,	'text-align: center; padding: 0px 0px 8px; line-height: 20px; margin: 0px; font-family: Verdana; font-size: 12px;'),
	(1,	36,	'padding: 6px 0px; font-family: Verdana; font-size: 14px;'),
	(1,	37,	'font-family: Verdana; font-size: 12px;');");

$this->db->query('INSERT INTO `'.$prntconfig_ntbl.'`  (`prntconfig_id`, `comp_id`, `vch_series_id`, `usr_config_id`) VALUES ('.$this->company_id.',13,18);');
$this->db->query("INSERT INTO `".$prntdesign_ntbl."` 
	(`prntconfig_id`, `erpprevaln_label_id`, `prntconfig_style`) VALUES
	(2,	6,	'font-family: Verdana; font-size: 12px;'),
	(2,	26,	'padding-left: 10px; font-family: Verdana; font-size: 12px;'),
	(2,	7,	'font-family: Verdana; font-size: 12px;'),
	(2,	27,	'padding-left: 10px; font-family: Verdana; font-size: 12px;'),
	(2,	8,	'font-family: Verdana; font-size: 24px; text-decoration: underline;'),
	(2,	9,	'margin-top: 15px; line-height: 42px; font-family: Verdana; font-size: 14px;'),
	(2,	34,	'font-family: Verdana; font-size: 12px;'),
	(2,	28,	'font-family: Verdana; font-size: 12px; font-weight: bold;'),
	(2,	11,	'font-family: Verdana; font-size: 12px;'),
	(2,	29,	'padding-left: 12px; font-family: Verdana; font-size: 12px;'),
	(2,	12,	'border-right: 1px solid rgb(0, 0, 0); padding: 6px; width: 56%; font-family: Verdana; font-size: 12px;'),
	(2,	30,	'border-right: 1px solid rgb(0, 0, 0); padding: 6px; width: 56%; font-family: Verdana; font-size: 12px;'),
	(2,	13,	'undefined'),
	(2,	31,	'undefined'),
	(2,	14,	'border-right: 1px solid rgb(0, 0, 0); padding: 6px; width: 24%; font-family: Verdana; font-size: 12px;'),
	(2,	32,	'border-right: 1px solid rgb(0, 0, 0); padding: 6px; width: 24%; font-family: Verdana; font-size: 12px;'),
	(2,	15,	'undefined'),
	(2,	33,	'undefined'),
	(2,	16,	'padding: 6px; text-align: right; width: 20%; font-family: Verdana; font-size: 12px;'),
	(2,	37,	'padding: 6px; text-align: right; width: 20%; font-family: Verdana; font-size: 12px;'),
	(2,	17,	'padding-left: 29px; font-family: Verdana; font-size: 12px;'),
	(2,	18,	'padding-left: 8px; font-family: Verdana; font-size: 12px;'),
	(2,	19,	'text-align: right; font-family: Verdana; font-size: 14px;'),
	(2,	36,	'font-family: Verdana; font-size: 14px;'),
	(2,	20,	'font-family: Verdana; font-size: 12px;'),
	(2,	24,	'font-family: Verdana; font-size: 12px;'),
	(2,	25,	'font-family: Verdana; font-size: 12px;');");	
}
catch (\Exception $e) {
	$status = 0;
	$flag = 1;
}
}

function FetchCompUUId(){
	$response = $this->aicountly_db->table('aicountly_compidgenr_univdb')->select('uuid')->where('comp_id',$this->company_id)->get()->getRowArray();
	return $response['uuid'];
}

public function CompFYAndMappingMaster($master_ntbl,$master_otbl,$master_type,$new_fy_id,$last_fy_info){
	$uuid         = $this->FetchCompUUId();	 
	$table_columns  =  $this->db->query("SHOW COLUMNS FROM `".$master_otbl."`;")->getResultArray();   

	$ext_uuid_db  = $this->externaldb->connect_uuid_db($uuid);	  
	$this->db->query("CREATE TABLE IF NOT EXISTS `".$master_ntbl."` LIKE `".$master_otbl."`;");	  

	/************ save master data in cofymstmap table user wise like **********/
	/************** aicountlyin_uuid_2 with new FY id and master id   **********/
	$builder        =  $this->db->table($master_otbl); 	  
	$master_res     =  $builder->get()->getResultArray();	 
	if($master_res){
		foreach($master_res as $mrow){
			  if($master_type=='act') //Account Master
			  $last_mst_fy_id  = $mrow['acc_id'];
			   if($master_type=='acg') //Account Group Master
			   $last_mst_fy_id  = $mrow['acc_grp_id'];
			  if($master_type=='cst') //Cost Center Master
			  $last_mst_fy_id  = $mrow['cc_id'];
			  if($master_type=='ccg') //Cost Center Group Master
			  $last_mst_fy_id  = $mrow['cc_grp_id'];	
			  if($master_type=='bsd') //Bill Subdry Master
			  $last_mst_fy_id  = $mrow['bill_sundry_id'];		
			  if($master_type=='bsd') //Bill Subdry Master
			  $last_mst_fy_id  = $mrow['bill_sundry_id'];			
			  if($master_type=='itm') //Item Master
			  $last_mst_fy_id  = $mrow['item_id'];	
			  if($master_type=='itg') //Item Group Master
			  $last_mst_fy_id  = $mrow['item_grp_id'];
			  if($master_type=='itu') //Item Unit Master
			  $last_mst_fy_id  = $mrow['unit_id'];		
			  if($master_type=='itc') //Item Category Master
			  $last_mst_fy_id  = $mrow['icatgms_id'];				
			  if($master_type=='mcm') //Material Center Master
			  $last_mst_fy_id  = $mrow['mat_cent_id'];	
			  if($master_type=='mcg') //Material Center Group
			  $last_mst_fy_id  = $mrow['mc_grp_id'];
			  if($master_type=='mcs') //Material Center Store
			  $last_mst_fy_id  = $mrow['mc_store_id'];	
			  if($master_type=='brc') //Barcode Master
			  $last_mst_fy_id  = $mrow['barcode_id']; 		


			  $builder3 = $ext_uuid_db->table('cofymstmap'); 
			  $builder3->where('comp_id', $this->company_id);
			  $builder3->where('comp_fy_id', $last_fy_info['comp_fy_id']);
			  $builder3->where('mst_type', $master_type);
			  $builder3->where('mst_fy_id', $last_mst_fy_id);
			  $ext_uuid_res = $builder3->get()->getRowArray();				
			  if($ext_uuid_res){
			  	$mst_base_id     = $ext_uuid_res['mst_base_id'];
			  	$table_col_val   = '';				

			  	foreach($table_columns as $key => $table_field){
			  		if(!isset($mrow[trim($table_field['Field'])]))
			  			$tblfield = 0;
			  		else 
			  			$tblfield =  $mrow[trim($table_field['Field'])];					 
			  		$table_col_val .='`'.trim($table_field['Field']).'`="'.trim($tblfield).'",';

			  	}
				//echo $mst_base_id.'=> '.$table_col_val;
				//echo '<br>';
			  	if($table_col_val){
			  		$table_col_val = rtrim($table_col_val,",");

			  		$this->db->query("INSERT INTO `".$master_ntbl."` SET ".$table_col_val);
				//echo $this->db->GetLastQuery();
				//echo '<br>';
			  		$new_mst_fy_id    = $this->db->insertID();				
			  		$cofymstmap_data  = array('comp_id'=>$this->company_id,'comp_fy_id'=>$new_fy_id,
			  			'mst_type'=>$master_type,'mst_base_id'=>$mst_base_id,
			  			'mst_fy_id'=>$new_mst_fy_id
			  		);
			  		$ext_uuid_db->table('cofymstmap')->insert($cofymstmap_data);
			  	}	

				}//else
					//echo 'no mst base id found ->'.$last_fy_info['comp_fy_id'].'--'.$last_mst_fy_id.'<br>';
				
			}
		}

	}
	public function create_voucher_tables($fy_id){
		$current_fy_id       = $this->session->get('ses_comp_fy_id');
	   //New Tables With New FY ID
		$vhtxntrail_ntbl  = $this->GetTableName($this->company_id,'_vhtxntrail_',$fy_id);
		$cmpvchseri_ntbl  = $this->GetTableName($this->company_id,'_cmpvchseri_',$fy_id);
		$vchseriesa_ntbl  = $this->GetTableName($this->company_id,'_vchseriesa_',$fy_id);
		$vchseriesm_ntbl  = $this->GetTableName($this->company_id,'_vchseriesm_',$fy_id);
		$cmpvchtype_ntbl  = $this->GetTableName($this->company_id,'_cmpvchtype_',$fy_id);
		$vchsubtype_ntbl  = $this->GetTableName($this->company_id,'_vchsubtype_',$fy_id);
		$long_narrn_ntbl  = $this->GetTableName($this->company_id,'_long_narrn_',$fy_id);
		$short_narr_ntbl  = $this->GetTableName($this->company_id,'_short_narr_',$fy_id);		
		$vhtxnconso_ntbl  = $this->GetTableName($this->company_id,'_vhtxnconso_',$fy_id);
		
	//Old Tables With Current FY ID
		$vhtxntrail_otbl  = $this->GetTableName($this->company_id,'_vhtxntrail_',$current_fy_id);
		$cmpvchseri_otbl  = $this->GetTableName($this->company_id,'_cmpvchseri_',$current_fy_id);
		$vchseriesa_otbl  = $this->GetTableName($this->company_id,'_vchseriesa_',$current_fy_id);
		$vchseriesm_otbl  = $this->GetTableName($this->company_id,'_vchseriesm_',$current_fy_id);
		$cmpvchtype_otbl  = $this->GetTableName($this->company_id,'_cmpvchtype_',$current_fy_id);
		$vchsubtype_otbl  = $this->GetTableName($this->company_id,'_vchsubtype_',$current_fy_id);
		$long_narrn_otbl  = $this->GetTableName($this->company_id,'_long_narrn_',$current_fy_id);
		$short_narr_otbl  = $this->GetTableName($this->company_id,'_short_narr_',$current_fy_id);	
		$vhtxnconso_otbl  = $this->GetTableName($this->company_id,'_vhtxnconso_',$current_fy_id);
		
		$status = 1;
		$flag = 0;
		try{
			$this->CreateFYTable($vhtxntrail_otbl,$vhtxntrail_ntbl);
			$this->CreateFYTable($cmpvchseri_otbl,$cmpvchseri_ntbl);
			$this->CreateFYTable($vchseriesa_otbl,$vchseriesa_ntbl);
			$this->CreateFYTable($vchseriesm_otbl,$vchseriesm_ntbl);
			$this->CreateFYTable($cmpvchtype_otbl,$cmpvchtype_ntbl);
			$this->CreateFYTable($vchsubtype_otbl,$vchsubtype_ntbl);
			$this->CreateFYTable($long_narrn_otbl,$long_narrn_ntbl);
			$this->CreateFYTable($short_narr_otbl,$short_narr_ntbl);
			$this->CreateFYTable($vhtxnconso_otbl,$vhtxnconso_ntbl);
		}
		catch (\Exception $e) {
			$status = 0;
			$flag = 1;
			SaveErrorLog($e->getMessage());
		}
	}

	public function create_account_master_tables($fy_id){
	    // get last FY id 
		$last_fy_info =$this->aicountly_db->table('aicountly_cmpfymastr_univdb')->select('comp_fy_id')->where('is_imported', '1')
		->where('comp_id', $this->company_id)->where('comp_fy_id <',$fy_id)
		->orderBy('comp_fy_id','DESC')->LIMIT(1)->get()->getRowArray();
		
		$current_fy_id       = $this->session->get('ses_comp_fy_id');
		//New Tables With New FY ID
		$acctcontnn_ntbl  = $this->GetTableName($this->company_id,'_acctcontnn_',$fy_id);
		$acctgroupn_ntbl  = $this->GetTableName($this->company_id,'_acctgroupn_',$fy_id);
		$grpparentn_ntbl  = $this->GetTableName($this->company_id,'_grpparentn_',$fy_id);
		$acctmaster_ntbl  = $this->GetTableName($this->company_id,'_acctmaster_',$fy_id);
		$acctaddmst_ntbl  = $this->GetTableName($this->company_id,'_acctaddmst_',$fy_id);
		$acctaxmstn_ntbl  = $this->GetTableName($this->company_id,'_acctaxmstn_',$fy_id);
		
		
	  //Old Tables With Current FY ID
		$acctcontnn_otbl  = $this->GetTableName($this->company_id,'_acctcontnn_',$current_fy_id);
		$acctgroupn_otbl  = $this->GetTableName($this->company_id,'_acctgroupn_',$current_fy_id);
		$grpparentn_otbl  = $this->GetTableName($this->company_id,'_grpparentn_',$current_fy_id);
		$acctmaster_otbl  = $this->GetTableName($this->company_id,'_acctmaster_',$current_fy_id);
		$acctaddmst_otbl  = $this->GetTableName($this->company_id,'_acctaddmst_',$current_fy_id);
		$acctaxmstn_otbl  = $this->GetTableName($this->company_id,'_acctaxmstn_',$current_fy_id);

		$status = 1;
		$flag = 0;

		$this->CreateFYTable($acctcontnn_otbl,$acctcontnn_ntbl);		
		$this->CreateFYTable($grpparentn_otbl,$grpparentn_ntbl);
		
		$this->CreateFYTable($acctaddmst_otbl,$acctaddmst_ntbl);
		$this->CreateFYTable($acctaxmstn_otbl,$acctaxmstn_ntbl);		
		
		
		$this->CompFYAndMappingMaster($acctmaster_ntbl,$acctmaster_otbl,'act',$fy_id,$last_fy_info);
		
		$this->CompFYAndMappingMaster($acctgroupn_ntbl,$acctgroupn_otbl,'acg',$fy_id,$last_fy_info);
		
		$accttxnoth_tbl = $this->company_id.'_accttxnoth_'.$fy_id; 
		$acctcrsref_tbl = $this->company_id.'_acctcrsref_'.$fy_id;		
		$accoppybal_tbl = $this->company_id.'_accoppybal_'.$fy_id;

		$this->db->query("DROP TABLE IF EXISTS `".$accttxnoth_tbl."`;");
		$this->db->query("DROP TABLE IF EXISTS `".$acctcrsref_tbl."`;");		
		$this->db->query("DROP TABLE IF EXISTS `".$accoppybal_tbl."`;");	

		$this->db->query("CREATE TABLE IF NOT EXISTS  `".$accttxnoth_tbl."` (
			`acc_oth_txn_id` BIGINT NOT NULL AUTO_INCREMENT ,
			`comp_id` BIGINT NOT NULL , `acc_oth_txn_date` DATE NOT NULL , 
			`acc_oth_txn_amount` DECIMAL(18,2) NOT NULL , `acc_oth_txn_drcr` VARCHAR(5) NOT NULL ,
			`voucher_type_id` BIGINT NOT NULL ,
			`comp_vch_series_no` VARCHAR(100) NOT NULL , `acc_id` BIGINT NOT NULL ,
			`voucher_txn_id` BIGINT NOT NULL , `acc_oth_txn_status` VARCHAR(10) NOT NULL ,
			`bo_id` BIGINT DEFAULT 1 ,`txn_id` BIGINT NOT NULL, `acc_oth_txn_duedate` DATE NOT NULL , `acc_oth_txn_tag` VARCHAR(100) NOT NULL , 
			PRIMARY KEY (`acc_oth_txn_id`)) ENGINE = InnoDB;");       

		$this->db->query("CREATE TABLE IF NOT EXISTS `".$acctcrsref_tbl."`(
			`acct_txn_id` BIGINT NOT NULL , `comp_id` BIGINT NOT NULL ,
			`acct_crs_id_type` varchar(40) DEFAULT NULL,
			`txn_id` BIGINT NOT NULL , `voucher_txn_id` BIGINT NOT NULL ,
			`bo_id` BIGINT DEFAULT 1 , `acc_cross_ref_type` VARCHAR(20) NOT NULL ,
			`acc_cross_ref_data` VARCHAR(200) NOT NULL , `acc_cross_logdate` DATE NOT NULL ) ENGINE = InnoDB;"); 
		
		$this->db->query("CREATE TABLE IF NOT EXISTS `".$accoppybal_tbl."` (
			`acc_id` BIGINT,
			`acc_op_bal` DECIMAL(18,2),
			`acc_py_bal` DECIMAL(18,2),
			`bo_id` BIGINT DEFAULT 1,
			KEY `accoppybal indexing` (`acc_id`) USING BTREE
		) ENGINE=MyISAM;");	
        // Create Account Txn Table		
		$all_acounts = $this->db->table($this->company_id.'_acctmaster_'.$fy_id)->select('acc_id,acc_grp_id,acc_grp_parent_id')->get()->getResultArray(); 
		if($all_acounts){
			foreach($all_acounts as $acrow){
				$account_id = $acrow['acc_id'];
				$acc_grp_id = $acrow['acc_grp_id'];
				
				if($acc_grp_id >0){
					// NO NEED TO C/F THE BALANCES OF ACCOUNTS UNDER THE PNL PARENT ONLY BALANCE SHEET PARENTS. 
					
					$grp_parent_info   = $this->db->table($this->company_id.'_acctgroupn_'.$current_fy_id)->select('acc_grp_parent_id')->where('acc_grp_id',$acc_grp_id)->get()->getRowArray();
					$acc_grp_parent_id = $grp_parent_info['acc_grp_parent_id'];
					
				}
				else{
					$acc_grp_parent_id = $acrow['acc_grp_parent_id'];
				}
				
				//Get Account Opening Balance Or Last Balance
				$account_balances = $this->GetAccountBalance($account_id);
				if($account_balances){
					foreach($account_balances as $brow){						
						if(in_array($acc_grp_parent_id,array('1','2','3','4','5'))){	
							$opdata = array("acc_id"=>$brow['acc_id'],"acc_op_bal"=>$brow['acc_op_bal'],
								"acc_py_bal"=>$brow['acc_py_bal'],"bo_id"=>$brow['bo_id']);	
						}
						else
							$opdata = array("acc_id"=>$brow['acc_id'],"acc_op_bal"=>0,"acc_py_bal"=>0,"bo_id"=>$brow['bo_id']);		

						$this->db->table($accoppybal_tbl)->insert($opdata);
					}
					
				}

				$txn_tablename = $this->company_id.'_accnttxnnn_'.$account_id.'_'.$fy_id;
				$this->db->query("DROP TABLE IF EXISTS `".$txn_tablename."`;");
				$table_query ='CREATE TABLE IF NOT EXISTS `'.$txn_tablename.'` (`acc_txn_id` bigint NOT NULL AUTO_INCREMENT , `comp_id` BIGINT(10) NOT NULL ,`acc_txn_date` DATE  NULL , `acc_txn_amount` DECIMAL(18,2)  NULL ,`acc_txn_drcr` VARCHAR(10)  NULL , `comp_vch_series_no` VARCHAR(100) NULL,`acc_id` BIGINT(10) NOT NULL ,`txn_id` BIGINT(10) NOT NULL, `voucher_type_id` BIGINT(10) NOT NULL , `acc_bal` DECIMAL(18,2) NULL,`voucher_txn_id` BIGINT(10) NULL, `bo_id` BIGINT DEFAULT 1,`posted_on` DATETIME NOT NULL,
				PRIMARY KEY (`acc_txn_id`)) ENGINE = InnoDB;';
				$this->db->query($table_query);

			}
		}	
		

	}

	public function create_mccenter_master_tables($fy_id){
	  // get last FY id 
		$last_fy_info =$this->aicountly_db->table('aicountly_cmpfymastr_univdb')->select('comp_fy_id')->where('is_imported', '1')
		->where('comp_id', $this->company_id)->where('comp_fy_id !=',$fy_id)
		->orderBy('comp_fy_id','DESC')->LIMIT(1)->get()->getRowArray();


		$current_fy_id       = $this->session->get('ses_comp_fy_id');
		//New Tables With New FY ID
		$mcgrpmstnn_ntbl  = $this->GetTableName($this->company_id,'_mcgrpmstnn_',$fy_id);
		$mcmasternn_ntbl  = $this->GetTableName($this->company_id,'_mcmasternn_',$fy_id);
		$mcstoremst_ntbl  = $this->GetTableName($this->company_id,'_mcstoremst_',$fy_id);
		
		
	  //Old Tables With Current FY ID
		$mcgrpmstnn_otbl  = $this->GetTableName($this->company_id,'_mcgrpmstnn_',$current_fy_id);
		$mcmasternn_otbl  = $this->GetTableName($this->company_id,'_mcmasternn_',$current_fy_id);
		$mcstoremst_otbl  = $this->GetTableName($this->company_id,'_mcstoremst_',$current_fy_id);
		
		
		$status = 1;
		$flag = 0;
		try{		
		//$this->CreateFYTable($mcgrpmstnn_otbl,$mcgrpmstnn_ntbl);
		//$this->CreateFYTable($mcmasternn_otbl,$mcmasternn_ntbl);
		//$this->CreateFYTable($mcstoremst_otbl,$mcstoremst_ntbl);
			$this->CompFYAndMappingMaster($mcgrpmstnn_ntbl,$mcgrpmstnn_otbl,'mcg',$fy_id,$last_fy_info);
			$this->CompFYAndMappingMaster($mcmasternn_ntbl,$mcmasternn_otbl,'mcm',$fy_id,$last_fy_info);
			$this->CompFYAndMappingMaster($mcstoremst_ntbl,$mcstoremst_otbl,'mcs',$fy_id,$last_fy_info);
		}
		catch (\Exception $e) {
			$status = 0;
			$flag = 1;
			SaveErrorLog($e->getMessage());
		}
	}


	public function create_bsd_master_tables($fy_id){
	  // get last FY id 
		$last_fy_info =$this->aicountly_db->table('aicountly_cmpfymastr_univdb')->select('comp_fy_id')->where('is_imported', '1')
		->where('comp_id', $this->company_id)->where('comp_fy_id !=',$fy_id)
		->orderBy('comp_fy_id','DESC')->LIMIT(1)->get()->getRowArray();


		$current_fy_id       = $this->session->get('ses_comp_fy_id');
		//New Tables With New FY ID
		$billsundry_ntbl  = $this->GetTableName($this->company_id,'_billsundry_',$fy_id);		
		$bdstaxmstn_ntbl  = $this->GetTableName($this->company_id,'_bdstaxmstn_',$fy_id);
		
		//Old Tables With Current FY ID
		$billsundry_otbl  = $this->GetTableName($this->company_id,'_billsundry_',$current_fy_id);
		$bdstaxmstn_otbl  = $this->GetTableName($this->company_id,'_bdstaxmstn_',$current_fy_id);
		
		
		
		
		
		
		$bsdoppybal_tbl  = $this->company_id.'_bsdoppybal_'.$fy_id; 	
		$status = 1;
		$flag = 0;
		try{
			$this->CreateFYTable($bdstaxmstn_otbl,$bdstaxmstn_ntbl);
			$this->CompFYAndMappingMaster($billsundry_ntbl,$billsundry_otbl,'bsd',$fy_id,$last_fy_info);

			$this->db->query("DROP TABLE IF EXISTS `".$bsdoppybal_tbl."`;");		
			$this->db->query("CREATE TABLE IF NOT EXISTS `".$bsdoppybal_tbl."` (
				`bill_sundry_id` BIGINT,
				`bsd_op_bal` DECIMAL(18,2),
				`bsd_py_bal` DECIMAL(18,2),
				`bo_id` BIGINT DEFAULT 1,
				KEY `bsdoppybal indexing` (`bill_sundry_id`) USING BTREE
			) ENGINE=MyISAM;"); 
		// Create BSD TXN Table		
			$all_acounts = $this->db->table($this->company_id.'_billsundry_'.$fy_id)->select('bill_sundry_id,acc_grp_id,acc_grp_parent_id')->get()->getResultArray(); 
			if($all_acounts){
				foreach($all_acounts as $acrow){
					$bill_sundry_id  = $acrow['bill_sundry_id'];
					$txn_tablename = $this->company_id.'_sundrytxnn_'.$bill_sundry_id.'_'.$fy_id;                  				
					$this->db->query("DROP TABLE IF EXISTS `".$txn_tablename."`;");
					$table_query ='CREATE TABLE IF NOT EXISTS `'.$txn_tablename.'` (
					`sundry_txn_id` bigint NOT NULL AUTO_INCREMENT,
					`comp_id` bigint NOT NULL,
					`sundry_txn_date` date DEFAULT NULL,
					`sundry_txn_amount` decimal(18,2) DEFAULT NULL,
					`sundry_txn_drcr` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
					`sundry_txn_narr` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
					`comp_vch_name` varchar(50) DEFAULT NULL,
					`comp_vch_series_no` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
					`bill_sundry_id` bigint DEFAULT NULL,
					`sundry_bal` decimal(18,2) DEFAULT NULL,
					`voucher_txn_id` bigint DEFAULT NULL,
					`voucher_type_id` bigint DEFAULT NULL,
					`txn_id` bigint DEFAULT NULL,
					`sundry_tag_rate` decimal(18,2) DEFAULT NULL,
					`bo_id` BIGINT DEFAULT 1 ,
					PRIMARY KEY (`sundry_txn_id`)
				) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;';
				$this->db->query($table_query);		

				
				$acc_grp_id		 = $acrow['acc_grp_id'];
				
				if($acc_grp_id >0){
					// NO NEED TO C/F THE BALANCES OF BILL SUNDRY UNDER THE PNL PARENT ONLY BALANCE SHEET PARENTS. 
					$grp_parent_info   = $this->db->table($this->company_id.'_acctgroupn_'.$current_fy_id)->select('acc_grp_parent_id')->where('acc_grp_id',$acc_grp_id)->get()->getRowArray();
					$acc_grp_parent_id = $grp_parent_info['acc_grp_parent_id'];
				}
				else{
					$acc_grp_parent_id = $acrow['acc_grp_parent_id'];
				}
				
				//Get Account Opening Balance Or Last Balance
				$bsd_account_balances = $this->GetBillSundryBalance($bill_sundry_id);
				if($bsd_account_balances){
					foreach($bsd_account_balances as $brow){
						if(in_array($acc_grp_parent_id,array('1','2','3','4','5'))){	
							$opdata = array("bill_sundry_id"=>$brow['bill_sundry_id'],"bsd_op_bal"=>$brow['bsd_op_bal'],
								"bsd_py_bal"=>$brow['bsd_py_bal'],"bo_id"=>$brow['bo_id']);	
						}else{
							$opdata = array("bill_sundry_id"=>$brow['bill_sundry_id'],"bsd_op_bal"=>0,"bsd_py_bal"=>0,"bo_id"=>$brow['bo_id']);		
						}
						$this->db->table($bsdoppybal_tbl)->insert($opdata);
					}
				}
				
				

			}
		}
		
	}
	catch (\Exception $e) {
		$status = 0;
		$flag = 1;
		SaveErrorLog($e->getMessage());
	}
}

public function create_billmaterial_master_tables($fy_id){
	$current_fy_id       = $this->session->get('ses_comp_fy_id');
		//New Tables With New FY ID
	$billofmatn_ntbl  = $this->GetTableName($this->company_id,'_billofmatn_',$fy_id);
	$bominputnn_ntbl  = $this->GetTableName($this->company_id,'_bominputnn_',$fy_id);
	$bomoutputn_ntbl  = $this->GetTableName($this->company_id,'_bomoutputn_',$fy_id);
	$bomaddcost_ntbl  = $this->GetTableName($this->company_id,'_bomaddcost_',$fy_id);
		//Old Tables With Current FY ID
	$billofmatn_otbl  = $this->GetTableName($this->company_id,'_billofmatn_',$current_fy_id);
	$bominputnn_otbl  = $this->GetTableName($this->company_id,'_bominputnn_',$current_fy_id);
	$bomoutputn_otbl  = $this->GetTableName($this->company_id,'_bomoutputn_',$current_fy_id);
	$bomaddcost_otbl  = $this->GetTableName($this->company_id,'_bomaddcost_',$current_fy_id);

	$status = 1;
	$flag = 0;
	try{
		$this->CreateFYTable($billofmatn_otbl,$billofmatn_ntbl);
		$this->CreateFYTable($bominputnn_otbl,$bominputnn_ntbl);
		$this->CreateFYTable($bomoutputn_otbl,$bomoutputn_ntbl);
		$this->CreateFYTable($bomaddcost_otbl,$bomaddcost_ntbl);			
	}
	catch (\Exception $e) {
		$status = 0;
		$flag = 1;
		SaveErrorLog($e->getMessage());
	}
}

function bill_by_bill_fyclosing_balance($bills_ref_id)
{   
	$bill_master_tbl = $this->company_id.'_billmaster_'.$this->session->get('ses_comp_fy_id');
	$bill_txn_tbl = $this->company_id.'_billstxnnn_'.$this->session->get('ses_comp_fy_id');

	$builder = $this->db->table($bill_master_tbl);
	$builder->where('bills_ref_id', $bills_ref_id);
	$result = $builder->get()->getResultArray();

	$final = [];

	foreach($result as $key => $value)
	{
		$bills_ref_id = $value['bills_ref_id'];
		$bill_op_bal = $value['bill_op_bal'];

		$builder = $this->db->table($bill_txn_tbl); 
		$builder->select('bills_txn_bal');
		$builder->where('bills_ref_id', $value['bills_ref_id']);
		$builder->orderBy('bills_txn_date', 'desc');
		$builder->orderBy('bills_txn_id', 'desc');
		$builder->limit(1);
		$bill_txn = $builder->get()->getRowArray();

		if($bill_txn){
			$bill_op_bal = floatval($bill_txn['bills_txn_bal']);
		}
		$final[] = [
			'bills_ref_id'     =>   $bills_ref_id,
			'bill_op_bal'      =>   $bill_op_bal,

		];
	}

	return $final;
}

public function create_bbb_master_tables($fy_id){
	$current_fy_id       = $this->session->get('ses_comp_fy_id');
		//New Tables With New FY ID
	$billmaster_ntbl  = $this->GetTableName($this->company_id,'_billmaster_',$fy_id);
		//Old Tables With Current FY ID
	$billmaster_otbl  = $this->GetTableName($this->company_id,'_billmaster_',$current_fy_id);

	$billstxnnn_tbl = $this->company_id.'_billstxnnn_'.$fy_id; 

	$status = 1;
	$flag = 0;
	try{
		$this->CreateFYTable($billmaster_otbl,$billmaster_ntbl);
		$billmaster_tbl = $this->company_id.'_billmaster_'.$fy_id;			
		$all_acounts    = $this->db->table($billmaster_tbl)->get()->getResultArray(); 
		if($all_acounts){
			foreach($all_acounts as $acrow){
				$bills_ref_id = $acrow['bills_ref_id'];
						//Get billmaster Opening Balance Or Last Balance
				$account_balances = $this->bill_by_bill_fyclosing_balance($bills_ref_id);
				if($account_balances){
					foreach($account_balances as $brow){						
						$opdata = array("bill_op_bal"=>$brow['bill_op_bal']);								   
						$this->db->table($billmaster_tbl)->where('bills_ref_id',$brow['bills_ref_id'])->update($opdata);
					}

				}		

			}
		}	
		
		$this->db->query("DROP TABLE IF EXISTS `".$billstxnnn_tbl."`;");		
		$this->db->query("CREATE TABLE IF NOT EXISTS `".$billstxnnn_tbl."` (`bills_txn_id` BIGINT NOT NULL AUTO_INCREMENT , `bills_ref_id` BIGINT NOT NULL ,
			`comp_id` BIGINT NOT NULL , `acc_id` BIGINT NOT NULL , `voucher_txn_id` BIGINT NOT NULL , `voucher_type_id` BIGINT NOT NULL ,
			`comp_vch_series_id` BIGINT NOT NULL , `bills_txn_date` DATE NOT NULL , `bills_txn_drcr` VARCHAR(255) NOT NULL , `bills_txn_amt` DECIMAL(18,2) NOT NULL
			, `bills_txn_bal` DECIMAL(18,2) NOT NULL ,`bo_id` BIGINT DEFAULT 1 , PRIMARY KEY (`bills_txn_id`)) ENGINE = InnoDB;"); 
	}
	catch (\Exception $e) {
		$status = 0;
		$flag = 1;
		SaveErrorLog($e->getMessage());
	}
} 

function cost_center_fyclosing_balance($cc_id)
{
	$cc_mst_tbl = $this->company_id.'_costctmstr_'.$this->session->get('ses_comp_fy_id');
	$cc_txn_tbl = $this->company_id.'_costcttxnn_'.$this->session->get('ses_comp_fy_id');

	$builder = $this->db->table($cc_mst_tbl);
	$builder->where('comp_id', $this->company_id);
	$builder->where('cc_id', $cc_id);
	$result = $builder->get()->getResultArray();

	$final = [];
	if($result)
	{
		foreach($result as $key => $value)
		{
			$cc_id = $value['cc_id'];
			$cc_op_bal = $value['cc_op_bal'];
			$cc_op_drcr = $value['cc_op_drcr'];

			$builder = $this->db->table($cc_txn_tbl);
			$builder->select('cc_txn_bal');
			$builder->where('cc_id', $value['cc_id']);
			$builder->orderBy('cc_txn_date', 'desc');
			$builder->orderBy('cc_txn_id', 'desc');
			$builder->limit(1);
			$cc_txn = $builder->get()->getRowArray();
			if($cc_txn)
			{
				$closing_balance = $cc_txn['cc_txn_bal'];
				if($closing_balance >= 0){
					$cc_op_bal = floatval($cc_txn['cc_txn_bal']);
					$cc_op_drcr = 'dr';
				}
				if($closing_balance < 0){
					$cc_op_bal = floatval(abs($cc_txn['cc_txn_bal']));
					$cc_op_drcr = 'cr';
				}
			}
			else{

			}

			$final[] = [
				'cc_id'            	=> $cc_id,
				'cc_op_bal'   			=> $cc_op_bal,
				'cc_op_drcr'   		=> $cc_op_drcr,
			]; 
		}

	}

	return $final;
}

public function create_cc_master_tables($fy_id){
	  // get last FY id 
	$last_fy_info =$this->aicountly_db->table('aicountly_cmpfymastr_univdb')->select('comp_fy_id')->where('is_imported', '1')
	->where('comp_id', $this->company_id)->where('comp_fy_id !=',$fy_id)
	->orderBy('comp_fy_id','DESC')->LIMIT(1)->get()->getRowArray();

	$current_fy_id       = $this->session->get('ses_comp_fy_id');
		//New Tables With New FY ID
	$costctmstr_ntbl  = $this->GetTableName($this->company_id,'_costctmstr_',$fy_id);
	$costctgrup_ntbl  = $this->GetTableName($this->company_id,'_costctgrup_',$fy_id);

		//Old Tables With Current FY ID
	$costctmstr_otbl  = $this->GetTableName($this->company_id,'_costctmstr_',$current_fy_id);
	$costctgrup_otbl  = $this->GetTableName($this->company_id,'_costctgrup_',$current_fy_id);

	$status = 1;
	$flag   = 0;
	try{

		$this->CompFYAndMappingMaster($costctmstr_ntbl,$costctmstr_otbl,'cst',$fy_id,$last_fy_info);
		$this->CompFYAndMappingMaster($costctgrup_ntbl,$costctgrup_otbl,'ccg',$fy_id,$last_fy_info);

		$costctmstr_tbl = $this->company_id.'_costctmstr_'.$fy_id;	
		$all_acounts    = $this->db->table($this->company_id.'_costctmstr_'.$fy_id)->get()->getResultArray(); 
		if($all_acounts){
			foreach($all_acounts as $acrow){
				$cc_id = $acrow['cc_id'];
						//Get Cost Center Opening Balance Or Last Balance
				$account_balances = $this->cost_center_fyclosing_balance($cc_id);
				if($account_balances){
					foreach($account_balances as $brow){						
						$opdata = array("cc_op_bal"=>$brow['cc_op_bal'],"cc_op_drcr"=>$brow['cc_op_drcr']);								   
						$this->db->table($costctmstr_tbl)->where('cc_id',$brow['cc_id'])->update($opdata);
					}

				}		

			}
		}				

		$costcttxnn_ntbl  = $this->GetTableName($this->company_id,'_costcttxnn_',$fy_id);
		$this->db->query("DROP TABLE IF EXISTS `".$costcttxnn_ntbl."`;");
		$this->db->query("CREATE TABLE IF NOT EXISTS `".$costcttxnn_ntbl."` (`cc_txn_id` BIGINT NOT NULL AUTO_INCREMENT , `cc_id` BIGINT NOT NULL , `comp_id` BIGINT NOT NULL , `acc_id` BIGINT NOT NULL ,bo_id BIGINT NOT NULL DEFAULT '1', 
			`voucher_txn_id` BIGINT NOT NULL , `voucher_type_id` BIGINT NOT NULL , `comp_vch_series_id` BIGINT NOT NULL , `cc_txn_date` DATE NOT NULL , 
			`cc_txn_drcr` VARCHAR(10) NOT NULL , `cc_txn_amt` DECIMAL(18,2) NOT NULL , `cc_txn_bal` DECIMAL(18,2) NOT NULL , PRIMARY KEY (`cc_txn_id`))
			ENGINE = InnoDB;");	
	}
	catch(\Exception $e){
		$status = 0;
		$flag = 1;
		SaveErrorLog($e->getMessage());
	}
} 

public function create_item_master_tables($fy_id){
	  // get last FY id 
	$last_fy_info =$this->aicountly_db->table('aicountly_cmpfymastr_univdb')->select('comp_fy_id')->where('is_imported', '1')
	->where('comp_id', $this->company_id)->where('comp_fy_id !=',$fy_id)
	->orderBy('comp_fy_id','DESC')->LIMIT(1)->get()->getRowArray();

	$current_fy_id  = $this->session->get('ses_comp_fy_id');
		//New Tables With New FY ID
	$itemcatmst_ntbl = $this->GetTableName($this->company_id,'_itemcatmst_',$fy_id);
	$itmgrpprnt_ntbl = $this->GetTableName($this->company_id,'_itmgrpprnt_',$fy_id); 
	$itemgrpmst_ntbl = $this->GetTableName($this->company_id,'_itemgrpmst_',$fy_id);
	$itemmaster_ntbl = $this->GetTableName($this->company_id,'_itemmaster_',$fy_id);
	$itmunitmst_ntbl = $this->GetTableName($this->company_id,'_itmunitmst_',$fy_id);			
	$itmparamtr_ntbl = $this->GetTableName($this->company_id,'_itmparamtr_',$fy_id);		
	$paramtrval_ntbl = $this->GetTableName($this->company_id,'_paramtrval_',$fy_id);
	$itmaltunit_ntbl = $this->GetTableName($this->company_id,'_itmaltunit_',$fy_id);		
	$itemdimens_ntbl = $this->GetTableName($this->company_id,'_itemdimens_',$fy_id);
	$itmbatchmt_ntbl = $this->GetTableName($this->company_id,'_itmbatchmt_',$fy_id);
	$itmtagging_ntbl = $this->GetTableName($this->company_id,'_itmtagging_',$fy_id);
	$labelmastr_ntbl = $this->GetTableName($this->company_id,'_labelmastr_',$fy_id);
	$labeldescn_ntbl = $this->GetTableName($this->company_id,'_labeldescn_',$fy_id);
	$itemlabeln_ntbl = $this->GetTableName($this->company_id,'_itemlabeln_',$fy_id); 
	$pckglistnn_ntbl = $this->GetTableName($this->company_id,'_pckglistnn_',$fy_id);
	$pckqtylist_ntbl = $this->GetTableName($this->company_id,'_pckqtylist_',$fy_id); 
	$pcklistbeg_ntbl = $this->GetTableName($this->company_id,'_pcklistbeg_',$fy_id);
	$pcklistext_ntbl = $this->GetTableName($this->company_id,'_pcklistext_',$fy_id);		
	$itemtrackn_ntbl = $this->GetTableName($this->company_id,'_itemtrackn_',$fy_id);		
	$pcklistmst_ntbl = $this->GetTableName($this->company_id,'_pcklistmst_',$fy_id);
	$listpacked_ntbl = $this->GetTableName($this->company_id,'_listpacked_',$fy_id);
	$pcklistqty_ntbl = $this->GetTableName($this->company_id,'_pcklistqty_',$fy_id);
	$listcumast_ntbl = $this->GetTableName($this->company_id,'_listcumast_',$fy_id);
	$cupackingn_ntbl = $this->GetTableName($this->company_id,'_cupackingn_',$fy_id);
	$leveltrack_ntbl = $this->GetTableName($this->company_id,'_leveltrack_',$fy_id);
	$barcodemst_ntbl = $this->GetTableName($this->company_id,'_barcodemst_',$fy_id);
	$iteminfonn_ntbl = $this->GetTableName($this->company_id,'_iteminfonn_',$fy_id);

	$taxcatmstn_ntbl = $this->GetTableName($this->company_id,'_taxcatmstn_',$fy_id); 
	$itemvalmst_ntbl = $this->GetTableName($this->company_id,'_itemvalmst_',$fy_id);

	$itemtaxmst_ntbl = $this->GetTableName($this->company_id,'_itemtaxmst_',$fy_id);




		//Old Tables With Current FY ID
	$itemcatmst_otbl = $this->GetTableName($this->company_id,'_itemcatmst_',$current_fy_id);
	$itmgrpprnt_otbl = $this->GetTableName($this->company_id,'_itmgrpprnt_',$current_fy_id); 
	$itemgrpmst_otbl = $this->GetTableName($this->company_id,'_itemgrpmst_',$current_fy_id);
	$itemmaster_otbl = $this->GetTableName($this->company_id,'_itemmaster_',$current_fy_id);
	$itmunitmst_otbl = $this->GetTableName($this->company_id,'_itmunitmst_',$current_fy_id);			
	$itmparamtr_otbl = $this->GetTableName($this->company_id,'_itmparamtr_',$current_fy_id);		
	$paramtrval_otbl = $this->GetTableName($this->company_id,'_paramtrval_',$current_fy_id);
	$itmaltunit_otbl = $this->GetTableName($this->company_id,'_itmaltunit_',$current_fy_id);		
	$itemdimens_otbl = $this->GetTableName($this->company_id,'_itemdimens_',$current_fy_id);
	$itmbatchmt_otbl = $this->GetTableName($this->company_id,'_itmbatchmt_',$current_fy_id);
	$itmtagging_otbl = $this->GetTableName($this->company_id,'_itmtagging_',$current_fy_id);
	$labelmastr_otbl = $this->GetTableName($this->company_id,'_labelmastr_',$current_fy_id);
	$labeldescn_otbl = $this->GetTableName($this->company_id,'_labeldescn_',$current_fy_id);
	$itemlabeln_otbl = $this->GetTableName($this->company_id,'_itemlabeln_',$current_fy_id); 
	$pckglistnn_otbl = $this->GetTableName($this->company_id,'_pckglistnn_',$current_fy_id);
	$pckqtylist_otbl = $this->GetTableName($this->company_id,'_pckqtylist_',$current_fy_id); 
	$pcklistbeg_otbl = $this->GetTableName($this->company_id,'_pcklistbeg_',$current_fy_id);
	$pcklistext_otbl = $this->GetTableName($this->company_id,'_pcklistext_',$current_fy_id);		
	$itemtrackn_otbl = $this->GetTableName($this->company_id,'_itemtrackn_',$current_fy_id);		
	$pcklistmst_otbl = $this->GetTableName($this->company_id,'_pcklistmst_',$current_fy_id);
	$listpacked_otbl = $this->GetTableName($this->company_id,'_listpacked_',$current_fy_id);
	$pcklistqty_otbl = $this->GetTableName($this->company_id,'_pcklistqty_',$current_fy_id);
	$listcumast_otbl = $this->GetTableName($this->company_id,'_listcumast_',$current_fy_id);
	$cupackingn_otbl = $this->GetTableName($this->company_id,'_cupackingn_',$current_fy_id);
	$leveltrack_otbl = $this->GetTableName($this->company_id,'_leveltrack_',$current_fy_id);
	$barcodemst_otbl = $this->GetTableName($this->company_id,'_barcodemst_',$current_fy_id);
	$iteminfonn_otbl = $this->GetTableName($this->company_id,'_iteminfonn_',$current_fy_id);		
	$taxcatmstn_otbl = $this->GetTableName($this->company_id,'_taxcatmstn_',$current_fy_id); 
	$itemvalmst_otbl = $this->GetTableName($this->company_id,'_itemvalmst_',$current_fy_id);
	$itemtaxmst_otbl = $this->GetTableName($this->company_id,'_itemtaxmst_',$current_fy_id);


	$itemtxnoth_tbl  = $this->company_id.'_itemtxnoth_'.$fy_id;
	$itemcrsref_tbl  = $this->company_id.'_itemcrsref_'.$fy_id;
	$itmoppyval_tbl  = $this->company_id.'_itmoppyval_'.$fy_id;
	$itmoppybal_tbl  = $this->company_id.'_itmoppybal_'.$fy_id;

	$status = 1;
	$flag = 0;
	try{
		   // $this->CreateFYTable($itemcatmst_otbl,$itemcatmst_ntbl);
		$this->CompFYAndMappingMaster($itemcatmst_ntbl,$itemcatmst_otbl,'itc',$fy_id,$last_fy_info);
	}catch (\Exception $e) {			
		SaveErrorLog($e->getMessage().' \n itemcatmst_ntbl 1069');

	} 
	try{
		$this->CreateFYTable($itmgrpprnt_otbl,$itmgrpprnt_ntbl);
		$this->CreateFYTable($itemtaxmst_otbl,$itemtaxmst_ntbl);
	}catch (\Exception $e) {			
		SaveErrorLog($e->getMessage().'\n itmgrpprnt_otbl 1075');

	}
	try{			
		$this->CompFYAndMappingMaster($itemgrpmst_ntbl,$itemgrpmst_otbl,'itg',$fy_id,$last_fy_info);
		   //$this->CreateFYTable($itemgrpmst_otbl,$itemgrpmst_ntbl);
	}catch (\Exception $e) {			
		SaveErrorLog($e->getMessage().'\n itemgrpmst_ntbl 1082');

	}
	try{
		$this->CompFYAndMappingMaster($itemmaster_ntbl,$itemmaster_otbl,'itm',$fy_id,$last_fy_info);
		   //$this->CreateFYTable($itemmaster_otbl,$itemmaster_ntbl);
	}catch (\Exception $e) {			
		SaveErrorLog($e->getMessage().'\n itemmaster_ntbl 1089');

	}
	try{
		$this->CompFYAndMappingMaster($itmunitmst_ntbl,$itmunitmst_otbl,'itu',$fy_id,$last_fy_info);
		   //$this->CreateFYTable($itmunitmst_otbl,$itmunitmst_ntbl);
	}catch (\Exception $e) {			
		SaveErrorLog($e->getMessage().'\n itmunitmst_ntbl 1096');

	}

	try{
		$this->CompFYAndMappingMaster($barcodemst_ntbl,$barcodemst_otbl,'brc',$fy_id,$last_fy_info);

	}catch (\Exception $e) {			
		SaveErrorLog($e->getMessage().'\n barcodemst_otbl 1104');

	}


	$this->CreateFYTable($itmparamtr_otbl,$itmparamtr_ntbl);			
	$this->CreateFYTable($paramtrval_otbl,$paramtrval_ntbl);
	$this->CreateFYTable($itmaltunit_otbl,$itmaltunit_ntbl);
	$this->CreateFYTable($itemdimens_otbl,$itemdimens_ntbl);			
	$this->CreateFYTable($itmbatchmt_otbl,$itmbatchmt_ntbl);
	$this->CreateFYTable($itmtagging_otbl,$itmtagging_ntbl);
	$this->CreateFYTable($labelmastr_otbl,$labelmastr_ntbl);			
	$this->CreateFYTable($labeldescn_otbl,$labeldescn_ntbl);
	$this->CreateFYTable($itemlabeln_otbl,$itemlabeln_ntbl);
	$this->CreateFYTable($pckglistnn_otbl,$pckglistnn_ntbl);			
	$this->CreateFYTable($pckqtylist_otbl,$pckqtylist_ntbl);
	$this->CreateFYTable($pcklistbeg_otbl,$pcklistbeg_ntbl);
	$this->CreateFYTable($pcklistext_otbl,$pcklistext_ntbl);			
	$this->CreateFYTable($itemtrackn_otbl,$itemtrackn_ntbl);
	$this->CreateFYTable($pcklistmst_otbl,$pcklistmst_ntbl);
	$this->CreateFYTable($listpacked_otbl,$listpacked_ntbl);			
	$this->CreateFYTable($pcklistqty_otbl,$pcklistqty_ntbl);
	$this->CreateFYTable($listcumast_otbl,$listcumast_ntbl);
	$this->CreateFYTable($cupackingn_otbl,$cupackingn_ntbl);			
	$this->CreateFYTable($leveltrack_otbl,$leveltrack_ntbl);
	$this->CreateFYTable($iteminfonn_otbl,$iteminfonn_ntbl);
	$this->CreateFYTable($taxcatmstn_otbl,$taxcatmstn_ntbl);
	$this->CreateFYTable($itemvalmst_otbl,$itemvalmst_ntbl);


	$this->db->query("DROP TABLE IF EXISTS `".$itemtxnoth_tbl."`;");
	$this->db->query("DROP TABLE IF EXISTS `".$itemcrsref_tbl."`;");		
	$this->db->query("DROP TABLE IF EXISTS `".$itmoppyval_tbl."`;");	
	$this->db->query("DROP TABLE IF EXISTS `".$itmoppybal_tbl."`;");		

	$this->db->query("CREATE TABLE IF NOT EXISTS `".$itemtxnoth_tbl."`(
		`item_oth_txn_id` BIGINT NOT NULL AUTO_INCREMENT , `comp_id` BIGINT NOT NULL ,
		`item_oth_txn_date` DATE NOT NULL , `item_oth_txn_amount` DECIMAL(18,2) NOT NULL ,
		`item_oth_txn_drcr` VARCHAR(10) NOT NULL , `item_oth_txn_qty` VARCHAR(20) NOT NULL ,
		`comp_vch_series_no` VARCHAR(50) NOT NULL ,
		`item_id` BIGINT NOT NULL ,`item_unit` INT NOT NULL , `voucher_txn_id` BIGINT NOT NULL ,
		`bo_id` BIGINT DEFAULT 1 , `txn_id` BIGINT NOT NULL , `mat_cent_id` BIGINT NOT NULL , 
		`voucher_type_id` BIGINT NOT NULL , `item_oth_txn_tag` VARCHAR(50) NOT NULL,
		`batch_id` BIGINT NOT NULL DEFAULT '0',
		PRIMARY KEY (`item_oth_txn_id`) ) ENGINE = InnoDB;"); 

	$this->db->query("CREATE TABLE IF NOT EXISTS `".$itemcrsref_tbl."`(
		`itm_crs_id` BIGINT NOT NULL ,`itm_crs_id_type` varchar(100) DEFAULT NULL, `comp_id` BIGINT NOT NULL ,`item_id` bigint NOT NULL,
		`txn_id` BIGINT NOT NULL , `voucher_txn_id` BIGINT NOT NULL ,
		`bo_id` BIGINT DEFAULT 1 , `item_cross_ref_type` VARCHAR(20) NOT NULL ,
		`item_cross_ref_data` VARCHAR(100) NOT NULL , `item_cross_logdate` DATE NOT NULL ) ENGINE = InnoDB;"); 

	$this->db->query("CREATE TABLE IF NOT EXISTS `".$itmoppyval_tbl."` (
		`item_id` BIGINT NOT NULL ,  `comp_id` BIGINT NOT NULL , 								 
		`item_unit` BIGINT NOT NULL ,`op_bal_val` DECIMAL(18,2) ,`py_bal_val` DECIMAL(18,2),
		`method_id` INT(1)	,`mat_cent_id` BIGINT DEFAULT 0,`bo_id` BIGINT DEFAULT 1,`batch_id` BIGINT DEFAULT 0,	
		INDEX `short opvv indexing` (`item_id`, `item_unit`,`comp_id`,`method_id`)) ENGINE = InnoDB;"); 


	$this->db->query("CREATE TABLE IF NOT EXISTS `".$itmoppybal_tbl."` (
		`item_id` BIGINT,
		`comp_id` BIGINT,
		`item_unit` INT(10),
		`op_bal_qty` VARCHAR(100),
		`py_bal_qty` VARCHAR(100),
		`mat_cent_id` BIGINT DEFAULT 0,
		`bo_id` BIGINT DEFAULT 1,
		`batch_id` BIGINT NOT NULL DEFAULT '0',								
		KEY `itmoppybal` (`item_id`,`comp_id`,`item_unit`,`op_bal_qty`) USING BTREE
	) ENGINE=MyISAM;"); 

	 // Create Item TXN Table		
	$all_acounts = $this->db->table($this->company_id.'_itemmaster_'.$fy_id)->select('item_id')->get()->getResultArray(); 
	if($all_acounts){
		foreach($all_acounts as $acrow){
			$item_id = $acrow['item_id'];

			try{
				$item_txn_tablename   = $this->company_id.'_itemtxnnnn_'.$item_id.'_'.$fy_id;
				$itemtxnval_tablename = $this->company_id.'_itemtxnval_'.$item_id.'_'.$fy_id;				
				$table_query1 ='CREATE TABLE IF NOT EXISTS `'.$item_txn_tablename.'` (
				`item_txn_id` BIGINT AUTO_INCREMENT,
				`comp_id` BIGINT,
				`item_txn_date` DATE,
				`item_txn_amount` DECIMAL(18,2),
				`item_txn_drcr` VARCHAR(5),
				`item_txn_qty` DECIMAL(18,4) NOT NULL,
				`item_id` BIGINT,
				`itemtxnbal_id` BIGINT,
				`voucher_txn_id` BIGINT,
				`bo_id` BIGINT DEFAULT 1,
				`txn_id` BIGINT,
				`mat_cent_id` BIGINT,
				`voucher_type_id` INT(5),
				`batch_id` BIGINT NOT NULL,
				`tagging_id` BIGINT,
				`item_unit` INT NOT NULL,
				`item_bal_qty` DECIMAL(18,4) NOT NULL,
				`item_avail` INT NOT NULL DEFAULT "1",
				KEY `itemtxnnnn index` (`comp_id`, `item_id`, `voucher_txn_id`, `txn_id`, `mat_cent_id`, `voucher_type_id`, `batch_id`) USING BTREE,PRIMARY KEY (`item_txn_id`) ) ENGINE=InnoDB;';
				$this->db->query($table_query1);
				
				
				$table_query2 ='CREATE TABLE IF NOT EXISTS `'.$itemtxnval_tablename.'` (`valuation_id` BIGINT NOT NULL AUTO_INCREMENT, `item_id` BIGINT NOT NULL, `unit_id` BIGINT NOT NULL, `mat_cent_id` BIGINT NOT NULL,`item_txn_id` BIGINT NOT NULL,`voucher_txn_id` BIGINT NOT NULL,`voucher_date` DATE NULL,`method_id` INT(5) NOT NULL,`item_value` DECIMAL(18,4) NOT NULL,`profit` DECIMAL(18,8) NOT NULL, PRIMARY KEY (`valuation_id`)) ENGINE=MyISAM;';
				$this->db->query($table_query2);
			}catch (\Exception $e) {			
				SaveErrorLog($e->getMessage().'\n _itemtxnnnn_,_itemtxnval_ 1237');
				
			}
				//Get Item Opening Balance Or Last Balance
			try{
				$item_balances = $this->GetItemBalance($item_id);
				if($item_balances){
					if(isset($item_balances['final_op_bal_result'])){
						foreach($item_balances['final_op_bal_result'] as $itmr){
							$opdata = array("item_id"=>$itmr['item_id'],"comp_id"=>$itmr['comp_id'],
								"item_unit"=>$itmr['item_unit'],"mat_cent_id"=>$itmr['mat_cent_id'],
								"bo_id"=>$itmr['bo_id'],"batch_id"=>$itmr['batch_id'],
								"op_bal_qty"=>$itmr['op_bal_qty'],"py_bal_qty"=>$itmr['py_bal_qty']);	
							$this->db->table($itmoppybal_tbl)->insert($opdata);						
						}
					}
					if(isset($item_balances['final_op_val_result'])){
						foreach($item_balances['final_op_val_result'] as $itmrv){
							$opvdata = array("item_id"=>$itmrv['item_id'],"comp_id"=>$itmrv['comp_id'],
								"item_unit"=>$itmrv['item_unit'],"mat_cent_id"=>$itmrv['mat_cent_id'],
								"bo_id"=>$itmrv['bo_id'],"batch_id"=>$itmrv['batch_id'],
								"op_bal_val"=>$itmrv['op_bal_val'],"py_bal_val"=>$itmrv['py_bal_val'],
								"method_id"=>$itmrv['method_id']);	
							$this->db->table($itmoppyval_tbl)->insert($opvdata);						
						}
					}
				}
			}
			catch (\Exception $e) {			
				SaveErrorLog($e->getMessage().'\n GetItemBalance 1205');
				
			}

		}
	}
} 

/****************************** FY CHANGE END **********************************/

 public function save_comp_tax($tax_update_data){
	$comptaxmst_tbl = 'aicountly_comptaxmst_univdb';
	$exists = $this->aicountly_db->table($comptaxmst_tbl)->where('comp_id',$this->company_id)->get()->getRowArray();		
	if($exists)
		$this->aicountly_db->table($comptaxmst_tbl)->where('comp_id',$this->company_id)->update($tax_update_data);		  
	else
		$this->aicountly_db->table($comptaxmst_tbl)->insert($tax_update_data);
 } 

 function get_company_address_info($company_id,$comp_addr_type){	 
	return $this->db->table('cmpaddrmst')->where('cmp_addr_type', $comp_addr_type)->where('cmp_id', $company_id)->get()->getRowArray();   	   
 }

 function get_other_info($company_id){	 
	return $this->db->table('cmpmstdetn')->where('cmp_id', $company_id)->get()->getRowArray();   	   
 }

  public function update_company_address($company_id, $data)
{
    $db = $this->db;
    $db->transStart();

    // ---------- Registered Office (addr_type = 1)
    $ro = [
        'cmp_addr1'   => $data['ro_add1'] ?? null,
        'cmp_addr2'   => $data['ro_add2'] ?? null,
        'cmp_city'    => $data['ro_city'] ?? null,
        'cmp_state'   => (int)$data['ro_state'] ?? 0,
        'cmp_pin_zip' => $data['ro_pin'] ?? null,
        'cmp_country' => (int)$data['ro_country'] ?? 0,
        'cmp_id'      => $company_id,
        'cmp_addr_type' => 1,
    ];

    $existsRo = $db->table('cmpaddrmst')
        ->where('cmp_id', $company_id)
        ->where('cmp_addr_type', 1)
        ->countAllResults();

    if ($existsRo) {
        $db->table('cmpaddrmst')
           ->where('cmp_id', $company_id)
           ->where('cmp_addr_type', 1)
           ->update($ro);
    } else {
        $db->table('cmpaddrmst')->insert($ro);
    }

    // ---------- Corporate Office (addr_type = 2)
    $co = [
        'cmp_addr1'   => $data['co_add1'] ?? null,
        'cmp_addr2'   => $data['co_add2'] ?? null,
        'cmp_city'    => $data['co_city'] ?? null,
        'cmp_state'   => (int)$data['co_state'] ?? 0,
        'cmp_pin_zip' => $data['co_pin'] ?? null,
        'cmp_country' => (int)$data['co_country'] ?? 0,
        'cmp_id'      => $company_id,
        'cmp_addr_type' => 2,
    ];

    $existsCo = $db->table('cmpaddrmst')
        ->where('cmp_id', $company_id)
        ->where('cmp_addr_type', 2)
        ->countAllResults();

    if ($existsCo) {
        $db->table('cmpaddrmst')
           ->where('cmp_id', $company_id)
           ->where('cmp_addr_type', 2)
           ->update($co);
    } else {
        $db->table('cmpaddrmst')->insert($co);
    }

    // ---------- FY master update
    $db->table('cmpfymastr')
       ->where('cmp_id', $company_id)
       ->update(['def_val_method' => $data['def_val_method'] ?? null]);

    $db->transComplete();
    return $db->transStatus();
} 

   public function update_company($company_id,$update_data){
	$this->db->table('cmpmastern')->where('cmp_id',$company_id)->update($update_data);		
	return TRUE;		
	}
	
	public function update_company_details($company_id,$data){
	$response = $this->db->table('cmpmstdetn')->where('cmp_id',$company_id)->get()->getRowArray();	
	
	if($response)	
    	$this->db->table('cmpmstdetn')->where('cmp_id',$company_id)->update($data);		
    else{
	  $insert_data = array("cmp_id"=>$company_id,"cmp_tel"=>$data["cmp_tel"],"cmp_mobile"=>$data["cmp_mobile"],"cmp_wa_mobile"=>$data["cmp_wa_mobile"],"cmp_email"=>$data["cmp_email"],
	                      "cmp_industry"=>$data["cmp_industry"],"cmp_work_nature"=>$data["cmp_work_nature"]
						  );	
	  $this->db->table('cmpmstdetn')->insert($insert_data);			
	}	   	
	return TRUE;		
	}

	function get_info($comp_id){	 
		$response   =  $this->db->table('cmpmastern')->where('cmp_id', $comp_id)->get()->getRowArray();   	   
		$cmpfymastr =  $this->db->table('cmpfymastr')->where('cmp_id', $comp_id)->get()->getRowArray();   	   
	    if($cmpfymastr)
			$response['def_val_method']= $cmpfymastr['def_val_method'];
		else
			$response['def_val_method'] = 1;
		
		 return $response;
	} 

	

	function saveDocument($data)
	{
		$this->aicountly_db->table('aicountly_aicdocidgr_univdb')
												->insert($data);

		return $this->aicountly_db->insertID();
	}

	function updateCompanyMaster($comp_id,$data)
	{
		$this->db->table('cmpmstdetn')
												->where('cmp_id', $comp_id)
												->update($data);

	}

	function getCompLogo($comp_id)
	{
		$file = [];
		$comp = $this->db->table('cmpmstdetn')
												->select('cmp_logo')
												->where('cmp_id', $comp_id)
												->get()->getRowArray();

		if(!empty($comp['cmp_logo'])){
			$doc_id = $comp['cmp_logo'];

			$doc = $this->aicountly_db->table('aicountly_aicdocidgr_univdb')
										->where('doc_id', $doc_id)
										->get()->getRowArray();
			if($doc){
				$file['name'] = $doc['doc_name'];
				$file['ext'] = $doc['doc_file_ext'];
			}
		}

		return $file;
	}

}